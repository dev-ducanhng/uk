<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <meta
    name="Keywords"
    content="KU BET là trang cá cược uy tín hàng đầu châu á, vận hành theo tôn chỉ khách hàng là thượng đế,KU BET là trang cá cược uy tín và an toàn được người chơi châu á tin tưởng lựa chọn,KU BET,KU casino,cá cược,cá độ,cá độ bóng đá,Nhà cái KU,web cá độ,cá cược thể thao,số đề,bóng đá,lô đề,casino,casino người thật,Casino trực tuyến,Sòng bài trực tuyến,Bắn cá" />
  <meta
    name="Description"
    content="KU BET là trang cá cược uy tín hàng đầu châu á, vận hành theo tôn chỉ khách hàng là thượng đế,KU BET là trang cá cược uy tín và an toàn được người chơi châu á tin tưởng lựa chọn,KU BET,KU casino,cá cược,cá độ,cá độ bóng đá,Nhà cái KU,web cá độ,cá cược thể thao,số đề,bóng đá,lô đề,casino,casino người thật,Casino trực tuyến,Sòng bài trực tuyến,Bắn cá" />
  <meta
    name="author"
    content="KU BET,KU casino,cá cược,cá độ,cá độ bóng đá,Nhà cái KU,web cá độ,cá cược thể thao,số đề,bóng đá,lô đề,casino,casino người thật,Casino trực tuyến,Sòng bài trực tuyến,Bắn cá" />
  <meta
    name="COPYRIGHT"
    content="KU BET,KU casino,cá cược,cá độ,cá độ bóng đá,Nhà cái KU,web cá độ,cá cược thể thao,số đề,bóng đá,lô đề,casino,casino người thật,Casino trực tuyến,Sòng bài trực tuyến,Bắn cá" />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="/" />
  <meta
    property="og:image"
    content="/assets/SharedAppLogo.png?t=1547829075289460736" />
  <meta
    property="og:title"
    content="Thương hiệu Casino chuyên nghiệp số 1 Châu Á, [đối tác chính thức của Laliga trong 5 giải đấu lớn] cùng các trò chơi giải trí (Thể Thao, Casino, E-Sports, Xổ Số)" />
  <meta
    property="og:description"
    content="Casino có người đẹp chơi cùng, Thể thao tỉ lệ cao nhất, Xổ số cách chơi đa dạng, Trò chơi điện tử cực đã ! Đặc sắc vô cùng, Kính mời trải nghiệm !" />
  <meta
    name="weibo:webpage:title"
    content="Thương hiệu Casino chuyên nghiệp số 1 Châu Á, [đối tác chính thức của Laliga trong 5 giải đấu lớn] cùng các trò chơi giải trí (Thể Thao, Casino, E-Sports, Xổ Số)" />
  <meta
    name="weibo:webpage:description"
    content="Casino có người đẹp chơi cùng, Thể thao tỉ lệ cao nhất, Xổ số cách chơi đa dạng, Trò chơi điện tử cực đã ! Đặc sắc vô cùng, Kính mời trải nghiệm !" />
  <meta
    itemprop="name"
    content="Thương hiệu Casino chuyên nghiệp số 1 Châu Á, [đối tác chính thức của Laliga trong 5 giải đấu lớn] cùng các trò chơi giải trí (Thể Thao, Casino, E-Sports, Xổ Số)" />
  <meta
    name="description"
    itemprop="description"
    content="Casino có người đẹp chơi cùng, Thể thao tỉ lệ cao nhất, Xổ số cách chơi đa dạng, Trò chơi điện tử cực đã ! Đặc sắc vô cùng, Kính mời trải nghiệm !" />
  <link rel="manifest" href="/manifest.json" />
  <title>
    Thương hiệu Casino chuyên nghiệp số 1 Châu Á, [đối tác chính thức của
    Laliga trong 5 giải đấu lớn] cùng các trò chơi giải trí (Thể Thao, Casino,
    E-Sports, Xổ Số)
  </title>
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script defer="defer" src="/static/js/main.9abb08d2.js"></script>
  <script src="{{ asset('js/main.9abb08d2.js') }}"></script>
  <script src="{{ asset('js/recapcha.js') }}" async defer></script>

  <!-- <script defer="defer" src="/static/js/881.eb58a5b3.chunk.js"></script> -->
  <!-- <link href="/static/css/main.be51b521.css" rel="stylesheet" /> -->
  <link href="{{ asset('css/main.css') }}" rel="stylesheet">
  <link href="{{ asset('css/style.css') }}" rel="stylesheet">
  <link href="{{ asset('css/629.67ebee62.chunk.css') }}" rel="stylesheet">
  <link href="{{ asset('css/385ebc265cfchunk.css') }}" rel="stylesheet">
  <link href="{{ asset('css/881.469709fe.chunk.css') }}" rel="stylesheet">
  <link href="{{ asset('css/recapcha.css') }}" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <!-- <script src="https://www.google.com/recaptcha/api.js" async defer></script> -->

  <style>
    .swal2-popup.swal2-toast {
      box-sizing: border-box;
      grid-column: 1/4 !important;
      grid-row: 1/4 !important;
      grid-template-columns: min-content auto min-content;
      padding: 1em;
      overflow-y: hidden;
      background: #fff;
      box-shadow: 0 0 1px rgba(0, 0, 0, 0.075), 0 1px 2px rgba(0, 0, 0, 0.075),
        1px 2px 4px rgba(0, 0, 0, 0.075), 1px 3px 8px rgba(0, 0, 0, 0.075),
        2px 4px 16px rgba(0, 0, 0, 0.075);
      pointer-events: all;
    }

    .swal2-popup.swal2-toast>* {
      grid-column: 2;
    }

    .swal2-popup.swal2-toast .swal2-title {
      margin: 0.5em 1em;
      padding: 0;
      font-size: 1em;
      text-align: initial;
    }

    .swal2-popup.swal2-toast .swal2-loading {
      justify-content: center;
    }

    .swal2-popup.swal2-toast .swal2-input {
      height: 2em;
      margin: 0.5em;
      font-size: 1em;
    }

    .swal2-popup.swal2-toast .swal2-validation-message {
      font-size: 1em;
    }

    .swal2-popup.swal2-toast .swal2-footer {
      margin: 0.5em 0 0;
      padding: 0.5em 0 0;
      font-size: 0.8em;
    }

    .swal2-popup.swal2-toast .swal2-close {
      grid-column: 3/3;
      grid-row: 1/99;
      align-self: center;
      width: 0.8em;
      height: 0.8em;
      margin: 0;
      font-size: 2em;
    }

    .swal2-popup.swal2-toast .swal2-html-container {
      margin: 0.5em 1em;
      padding: 0;
      overflow: initial;
      font-size: 1em;
      text-align: initial;
    }

    .swal2-popup.swal2-toast .swal2-html-container:empty {
      padding: 0;
    }

    .swal2-popup.swal2-toast .swal2-loader {
      grid-column: 1;
      grid-row: 1/99;
      align-self: center;
      width: 2em;
      height: 2em;
      margin: 0.25em;
    }

    .swal2-popup.swal2-toast .swal2-icon {
      grid-column: 1;
      grid-row: 1/99;
      align-self: center;
      width: 2em;
      min-width: 2em;
      height: 2em;
      margin: 0 0.5em 0 0;
    }

    .swal2-popup.swal2-toast .swal2-icon .swal2-icon-content {
      display: flex;
      align-items: center;
      font-size: 1.8em;
      font-weight: bold;
    }

    .swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring {
      width: 2em;
      height: 2em;
    }

    .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^="swal2-x-mark-line"] {
      top: 0.875em;
      width: 1.375em;
    }

    .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^="swal2-x-mark-line"][class$="left"] {
      left: 0.3125em;
    }

    .swal2-popup.swal2-toast .swal2-icon.swal2-error [class^="swal2-x-mark-line"][class$="right"] {
      right: 0.3125em;
    }

    .swal2-popup.swal2-toast .swal2-actions {
      justify-content: flex-start;
      height: auto;
      margin: 0;
      margin-top: 0.5em;
      padding: 0 0.5em;
    }

    .swal2-popup.swal2-toast .swal2-styled {
      margin: 0.25em 0.5em;
      padding: 0.4em 0.6em;
      font-size: 1em;
    }

    .swal2-popup.swal2-toast .swal2-success {
      border-color: #a5dc86;
    }

    .swal2-popup.swal2-toast .swal2-success [class^="swal2-success-circular-line"] {
      position: absolute;
      width: 1.6em;
      height: 3em;
      border-radius: 50%;
    }

    .swal2-popup.swal2-toast .swal2-success [class^="swal2-success-circular-line"][class$="left"] {
      top: -0.8em;
      left: -0.5em;
      transform: rotate(-45deg);
      transform-origin: 2em 2em;
      border-radius: 4em 0 0 4em;
    }

    .swal2-popup.swal2-toast .swal2-success [class^="swal2-success-circular-line"][class$="right"] {
      top: -0.25em;
      left: 0.9375em;
      transform-origin: 0 1.5em;
      border-radius: 0 4em 4em 0;
    }

    .swal2-popup.swal2-toast .swal2-success .swal2-success-ring {
      width: 2em;
      height: 2em;
    }

    .swal2-popup.swal2-toast .swal2-success .swal2-success-fix {
      top: 0;
      left: 0.4375em;
      width: 0.4375em;
      height: 2.6875em;
    }

    .swal2-popup.swal2-toast .swal2-success [class^="swal2-success-line"] {
      height: 0.3125em;
    }

    .swal2-popup.swal2-toast .swal2-success [class^="swal2-success-line"][class$="tip"] {
      top: 1.125em;
      left: 0.1875em;
      width: 0.75em;
    }

    .swal2-popup.swal2-toast .swal2-success [class^="swal2-success-line"][class$="long"] {
      top: 0.9375em;
      right: 0.1875em;
      width: 1.375em;
    }

    .swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip {
      animation: swal2-toast-animate-success-line-tip 0.75s;
    }

    .swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long {
      animation: swal2-toast-animate-success-line-long 0.75s;
    }

    .swal2-popup.swal2-toast.swal2-show {
      animation: swal2-toast-show 0.5s;
    }

    .swal2-popup.swal2-toast.swal2-hide {
      animation: swal2-toast-hide 0.1s forwards;
    }

    div:where(.swal2-container) {
      display: grid;
      position: fixed;
      z-index: 1060;
      inset: 0;
      box-sizing: border-box;
      grid-template-areas: "top-start     top            top-end" "center-start  center         center-end" "bottom-start  bottom-center  bottom-end";
      grid-template-rows: minmax(min-content, auto) minmax(min-content, auto) minmax(min-content,
          auto);
      height: 100%;
      padding: 0.625em;
      overflow-x: hidden;
      transition: background-color 0.1s;
      -webkit-overflow-scrolling: touch;
    }

    div:where(.swal2-container).swal2-backdrop-show,
    div:where(.swal2-container).swal2-noanimation {
      background: rgba(0, 0, 0, 0.4);
    }

    div:where(.swal2-container).swal2-backdrop-hide {
      background: rgba(0, 0, 0, 0) !important;
    }

    div:where(.swal2-container).swal2-top-start,
    div:where(.swal2-container).swal2-center-start,
    div:where(.swal2-container).swal2-bottom-start {
      grid-template-columns: minmax(0, 1fr) auto auto;
    }

    div:where(.swal2-container).swal2-top,
    div:where(.swal2-container).swal2-center,
    div:where(.swal2-container).swal2-bottom {
      grid-template-columns: auto minmax(0, 1fr) auto;
    }

    div:where(.swal2-container).swal2-top-end,
    div:where(.swal2-container).swal2-center-end,
    div:where(.swal2-container).swal2-bottom-end {
      grid-template-columns: auto auto minmax(0, 1fr);
    }

    div:where(.swal2-container).swal2-top-start>.swal2-popup {
      align-self: start;
    }

    div:where(.swal2-container).swal2-top>.swal2-popup {
      grid-column: 2;
      place-self: start center;
    }

    div:where(.swal2-container).swal2-top-end>.swal2-popup,
    div:where(.swal2-container).swal2-top-right>.swal2-popup {
      grid-column: 3;
      place-self: start end;
    }

    div:where(.swal2-container).swal2-center-start>.swal2-popup,
    div:where(.swal2-container).swal2-center-left>.swal2-popup {
      grid-row: 2;
      align-self: center;
    }

    div:where(.swal2-container).swal2-center>.swal2-popup {
      grid-column: 2;
      grid-row: 2;
      place-self: center center;
    }

    div:where(.swal2-container).swal2-center-end>.swal2-popup,
    div:where(.swal2-container).swal2-center-right>.swal2-popup {
      grid-column: 3;
      grid-row: 2;
      place-self: center end;
    }

    div:where(.swal2-container).swal2-bottom-start>.swal2-popup,
    div:where(.swal2-container).swal2-bottom-left>.swal2-popup {
      grid-column: 1;
      grid-row: 3;
      align-self: end;
    }

    div:where(.swal2-container).swal2-bottom>.swal2-popup {
      grid-column: 2;
      grid-row: 3;
      place-self: end center;
    }

    div:where(.swal2-container).swal2-bottom-end>.swal2-popup,
    div:where(.swal2-container).swal2-bottom-right>.swal2-popup {
      grid-column: 3;
      grid-row: 3;
      place-self: end end;
    }

    div:where(.swal2-container).swal2-grow-row>.swal2-popup,
    div:where(.swal2-container).swal2-grow-fullscreen>.swal2-popup {
      grid-column: 1/4;
      width: 100%;
    }

    div:where(.swal2-container).swal2-grow-column>.swal2-popup,
    div:where(.swal2-container).swal2-grow-fullscreen>.swal2-popup {
      grid-row: 1/4;
      align-self: stretch;
    }

    div:where(.swal2-container).swal2-no-transition {
      transition: none !important;
    }

    div:where(.swal2-container) div:where(.swal2-popup) {
      display: none;
      position: relative;
      box-sizing: border-box;
      grid-template-columns: minmax(0, 100%);
      width: 32em;
      max-width: 100%;
      padding: 0 0 1.25em;
      border: none;
      border-radius: 5px;
      background: #fff;
      color: #545454;
      font-family: inherit;
      font-size: 1rem;
    }

    div:where(.swal2-container) div:where(.swal2-popup):focus {
      outline: none;
    }

    div:where(.swal2-container) div:where(.swal2-popup).swal2-loading {
      overflow-y: hidden;
    }

    div:where(.swal2-container) h2:where(.swal2-title) {
      position: relative;
      max-width: 100%;
      margin: 0;
      padding: 0.8em 1em 0;
      color: inherit;
      font-size: 1.875em;
      font-weight: 600;
      text-align: center;
      text-transform: none;
      word-wrap: break-word;
    }

    div:where(.swal2-container) div:where(.swal2-actions) {
      display: flex;
      z-index: 1;
      box-sizing: border-box;
      flex-wrap: wrap;
      align-items: center;
      justify-content: center;
      width: auto;
      margin: 1.25em auto 0;
      padding: 0;
    }

    div:where(.swal2-container) div:where(.swal2-actions):not(.swal2-loading) .swal2-styled[disabled] {
      opacity: 0.4;
    }

    div:where(.swal2-container) div:where(.swal2-actions):not(.swal2-loading) .swal2-styled:hover {
      background-image: linear-gradient(rgba(0, 0, 0, 0.1),
          rgba(0, 0, 0, 0.1));
    }

    div:where(.swal2-container) div:where(.swal2-actions):not(.swal2-loading) .swal2-styled:active {
      background-image: linear-gradient(rgba(0, 0, 0, 0.2),
          rgba(0, 0, 0, 0.2));
    }

    div:where(.swal2-container) div:where(.swal2-loader) {
      display: none;
      align-items: center;
      justify-content: center;
      width: 2.2em;
      height: 2.2em;
      margin: 0 1.875em;
      animation: swal2-rotate-loading 1.5s linear 0s infinite normal;
      border-width: 0.25em;
      border-style: solid;
      border-radius: 100%;
      border-color: #2778c4 rgba(0, 0, 0, 0) #2778c4 rgba(0, 0, 0, 0);
    }

    div:where(.swal2-container) button:where(.swal2-styled) {
      margin: 0.3125em;
      padding: 0.625em 1.1em;
      transition: box-shadow 0.1s;
      box-shadow: 0 0 0 3px rgba(0, 0, 0, 0);
      font-weight: 500;
    }

    div:where(.swal2-container) button:where(.swal2-styled):not([disabled]) {
      cursor: pointer;
    }

    div:where(.swal2-container) button:where(.swal2-styled).swal2-confirm {
      border: 0;
      border-radius: 0.25em;
      background: initial;
      background-color: #7066e0;
      color: #fff;
      font-size: 1em;
    }

    div:where(.swal2-container) button:where(.swal2-styled).swal2-confirm:focus {
      box-shadow: 0 0 0 3px rgba(112, 102, 224, 0.5);
    }

    div:where(.swal2-container) button:where(.swal2-styled).swal2-deny {
      border: 0;
      border-radius: 0.25em;
      background: initial;
      background-color: #dc3741;
      color: #fff;
      font-size: 1em;
    }

    div:where(.swal2-container) button:where(.swal2-styled).swal2-deny:focus {
      box-shadow: 0 0 0 3px rgba(220, 55, 65, 0.5);
    }

    div:where(.swal2-container) button:where(.swal2-styled).swal2-cancel {
      border: 0;
      border-radius: 0.25em;
      background: initial;
      background-color: #6e7881;
      color: #fff;
      font-size: 1em;
    }

    div:where(.swal2-container) button:where(.swal2-styled).swal2-cancel:focus {
      box-shadow: 0 0 0 3px rgba(110, 120, 129, 0.5);
    }

    div:where(.swal2-container) button:where(.swal2-styled).swal2-default-outline:focus {
      box-shadow: 0 0 0 3px rgba(100, 150, 200, 0.5);
    }

    div:where(.swal2-container) button:where(.swal2-styled):focus {
      outline: none;
    }

    div:where(.swal2-container) button:where(.swal2-styled)::-moz-focus-inner {
      border: 0;
    }

    div:where(.swal2-container) div:where(.swal2-footer) {
      margin: 1em 0 0;
      padding: 1em 1em 0;
      border-top: 1px solid #eee;
      color: inherit;
      font-size: 1em;
      text-align: center;
    }

    div:where(.swal2-container) .swal2-timer-progress-bar-container {
      position: absolute;
      right: 0;
      bottom: 0;
      left: 0;
      grid-column: auto !important;
      overflow: hidden;
      border-bottom-right-radius: 5px;
      border-bottom-left-radius: 5px;
    }

    div:where(.swal2-container) div:where(.swal2-timer-progress-bar) {
      width: 100%;
      height: 0.25em;
      background: rgba(0, 0, 0, 0.2);
    }

    div:where(.swal2-container) img:where(.swal2-image) {
      max-width: 100%;
      margin: 2em auto 1em;
    }

    div:where(.swal2-container) button:where(.swal2-close) {
      z-index: 2;
      align-items: center;
      justify-content: center;
      width: 1.2em;
      height: 1.2em;
      margin-top: 0;
      margin-right: 0;
      margin-bottom: -1.2em;
      padding: 0;
      overflow: hidden;
      transition: color 0.1s, box-shadow 0.1s;
      border: none;
      border-radius: 5px;
      background: rgba(0, 0, 0, 0);
      color: #ccc;
      font-family: monospace;
      font-size: 2.5em;
      cursor: pointer;
      justify-self: end;
    }

    div:where(.swal2-container) button:where(.swal2-close):hover {
      transform: none;
      background: rgba(0, 0, 0, 0);
      color: #f27474;
    }

    div:where(.swal2-container) button:where(.swal2-close):focus {
      outline: none;
      box-shadow: inset 0 0 0 3px rgba(100, 150, 200, 0.5);
    }

    div:where(.swal2-container) button:where(.swal2-close)::-moz-focus-inner {
      border: 0;
    }

    div:where(.swal2-container) .swal2-html-container {
      z-index: 1;
      justify-content: center;
      margin: 1em 1.6em 0.3em;
      padding: 0;
      overflow: auto;
      color: inherit;
      font-size: 1.125em;
      font-weight: normal;
      line-height: normal;
      text-align: center;
      word-wrap: break-word;
      word-break: break-word;
    }

    div:where(.swal2-container) input:where(.swal2-input),
    div:where(.swal2-container) input:where(.swal2-file),
    div:where(.swal2-container) textarea:where(.swal2-textarea),
    div:where(.swal2-container) select:where(.swal2-select),
    div:where(.swal2-container) div:where(.swal2-radio),
    div:where(.swal2-container) label:where(.swal2-checkbox) {
      margin: 1em 2em 3px;
    }

    div:where(.swal2-container) input:where(.swal2-input),
    div:where(.swal2-container) input:where(.swal2-file),
    div:where(.swal2-container) textarea:where(.swal2-textarea) {
      box-sizing: border-box;
      width: auto;
      transition: border-color 0.1s, box-shadow 0.1s;
      border: 1px solid #d9d9d9;
      border-radius: 0.1875em;
      background: rgba(0, 0, 0, 0);
      box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.06),
        0 0 0 3px rgba(0, 0, 0, 0);
      color: inherit;
      font-size: 1.125em;
    }

    div:where(.swal2-container) input:where(.swal2-input).swal2-inputerror,
    div:where(.swal2-container) input:where(.swal2-file).swal2-inputerror,
    div:where(.swal2-container) textarea:where(.swal2-textarea).swal2-inputerror {
      border-color: #f27474 !important;
      box-shadow: 0 0 2px #f27474 !important;
    }

    div:where(.swal2-container) input:where(.swal2-input):focus,
    div:where(.swal2-container) input:where(.swal2-file):focus,
    div:where(.swal2-container) textarea:where(.swal2-textarea):focus {
      border: 1px solid #b4dbed;
      outline: none;
      box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.06),
        0 0 0 3px rgba(100, 150, 200, 0.5);
    }

    div:where(.swal2-container) input:where(.swal2-input)::placeholder,
    div:where(.swal2-container) input:where(.swal2-file)::placeholder,
    div:where(.swal2-container) textarea:where(.swal2-textarea)::placeholder {
      color: #ccc;
    }

    div:where(.swal2-container) .swal2-range {
      margin: 1em 2em 3px;
      background: #fff;
    }

    div:where(.swal2-container) .swal2-range input {
      width: 80%;
    }

    div:where(.swal2-container) .swal2-range output {
      width: 20%;
      color: inherit;
      font-weight: 600;
      text-align: center;
    }

    div:where(.swal2-container) .swal2-range input,
    div:where(.swal2-container) .swal2-range output {
      height: 2.625em;
      padding: 0;
      font-size: 1.125em;
      line-height: 2.625em;
    }

    div:where(.swal2-container) .swal2-input {
      height: 2.625em;
      padding: 0 0.75em;
    }

    div:where(.swal2-container) .swal2-file {
      width: 75%;
      margin-right: auto;
      margin-left: auto;
      background: rgba(0, 0, 0, 0);
      font-size: 1.125em;
    }

    div:where(.swal2-container) .swal2-textarea {
      height: 6.75em;
      padding: 0.75em;
    }

    div:where(.swal2-container) .swal2-select {
      min-width: 50%;
      max-width: 100%;
      padding: 0.375em 0.625em;
      background: rgba(0, 0, 0, 0);
      color: inherit;
      font-size: 1.125em;
    }

    div:where(.swal2-container) .swal2-radio,
    div:where(.swal2-container) .swal2-checkbox {
      align-items: center;
      justify-content: center;
      background: #fff;
      color: inherit;
    }

    div:where(.swal2-container) .swal2-radio label,
    div:where(.swal2-container) .swal2-checkbox label {
      margin: 0 0.6em;
      font-size: 1.125em;
    }

    div:where(.swal2-container) .swal2-radio input,
    div:where(.swal2-container) .swal2-checkbox input {
      flex-shrink: 0;
      margin: 0 0.4em;
    }

    div:where(.swal2-container) label:where(.swal2-input-label) {
      display: flex;
      justify-content: center;
      margin: 1em auto 0;
    }

    div:where(.swal2-container) div:where(.swal2-validation-message) {
      align-items: center;
      justify-content: center;
      margin: 1em 0 0;
      padding: 0.625em;
      overflow: hidden;
      background: #f0f0f0;
      color: #666;
      font-size: 1em;
      font-weight: 300;
    }

    div:where(.swal2-container) div:where(.swal2-validation-message)::before {
      content: "!";
      display: inline-block;
      width: 1.5em;
      min-width: 1.5em;
      height: 1.5em;
      margin: 0 0.625em;
      border-radius: 50%;
      background-color: #f27474;
      color: #fff;
      font-weight: 600;
      line-height: 1.5em;
      text-align: center;
    }

    div:where(.swal2-container) .swal2-progress-steps {
      flex-wrap: wrap;
      align-items: center;
      max-width: 100%;
      margin: 1.25em auto;
      padding: 0;
      background: rgba(0, 0, 0, 0);
      font-weight: 600;
    }

    div:where(.swal2-container) .swal2-progress-steps li {
      display: inline-block;
      position: relative;
    }

    div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step {
      z-index: 20;
      flex-shrink: 0;
      width: 2em;
      height: 2em;
      border-radius: 2em;
      background: #2778c4;
      color: #fff;
      line-height: 2em;
      text-align: center;
    }

    div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step {
      background: #2778c4;
    }

    div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step {
      background: #add8e6;
      color: #fff;
    }

    div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line {
      background: #add8e6;
    }

    div:where(.swal2-container) .swal2-progress-steps .swal2-progress-step-line {
      z-index: 10;
      flex-shrink: 0;
      width: 2.5em;
      height: 0.4em;
      margin: 0 -1px;
      background: #2778c4;
    }

    div:where(.swal2-icon) {
      position: relative;
      box-sizing: content-box;
      justify-content: center;
      width: 5em;
      height: 5em;
      margin: 2.5em auto 0.6em;
      border: 0.25em solid rgba(0, 0, 0, 0);
      border-radius: 50%;
      border-color: #000;
      font-family: inherit;
      line-height: 5em;
      cursor: default;
      user-select: none;
    }

    div:where(.swal2-icon) .swal2-icon-content {
      display: flex;
      align-items: center;
      font-size: 3.75em;
    }

    div:where(.swal2-icon).swal2-error {
      border-color: #f27474;
      color: #f27474;
    }

    div:where(.swal2-icon).swal2-error .swal2-x-mark {
      position: relative;
      flex-grow: 1;
    }

    div:where(.swal2-icon).swal2-error [class^="swal2-x-mark-line"] {
      display: block;
      position: absolute;
      top: 2.3125em;
      width: 2.9375em;
      height: 0.3125em;
      border-radius: 0.125em;
      background-color: #f27474;
    }

    div:where(.swal2-icon).swal2-error [class^="swal2-x-mark-line"][class$="left"] {
      left: 1.0625em;
      transform: rotate(45deg);
    }

    div:where(.swal2-icon).swal2-error [class^="swal2-x-mark-line"][class$="right"] {
      right: 1em;
      transform: rotate(-45deg);
    }

    div:where(.swal2-icon).swal2-error.swal2-icon-show {
      animation: swal2-animate-error-icon 0.5s;
    }

    div:where(.swal2-icon).swal2-error.swal2-icon-show .swal2-x-mark {
      animation: swal2-animate-error-x-mark 0.5s;
    }

    div:where(.swal2-icon).swal2-warning {
      border-color: #facea8;
      color: #f8bb86;
    }

    div:where(.swal2-icon).swal2-warning.swal2-icon-show {
      animation: swal2-animate-error-icon 0.5s;
    }

    div:where(.swal2-icon).swal2-warning.swal2-icon-show .swal2-icon-content {
      animation: swal2-animate-i-mark 0.5s;
    }

    div:where(.swal2-icon).swal2-info {
      border-color: #9de0f6;
      color: #3fc3ee;
    }

    div:where(.swal2-icon).swal2-info.swal2-icon-show {
      animation: swal2-animate-error-icon 0.5s;
    }

    div:where(.swal2-icon).swal2-info.swal2-icon-show .swal2-icon-content {
      animation: swal2-animate-i-mark 0.8s;
    }

    div:where(.swal2-icon).swal2-question {
      border-color: #c9dae1;
      color: #87adbd;
    }

    div:where(.swal2-icon).swal2-question.swal2-icon-show {
      animation: swal2-animate-error-icon 0.5s;
    }

    div:where(.swal2-icon).swal2-question.swal2-icon-show .swal2-icon-content {
      animation: swal2-animate-question-mark 0.8s;
    }

    div:where(.swal2-icon).swal2-success {
      border-color: #a5dc86;
      color: #a5dc86;
    }

    div:where(.swal2-icon).swal2-success [class^="swal2-success-circular-line"] {
      position: absolute;
      width: 3.75em;
      height: 7.5em;
      border-radius: 50%;
    }

    div:where(.swal2-icon).swal2-success [class^="swal2-success-circular-line"][class$="left"] {
      top: -0.4375em;
      left: -2.0635em;
      transform: rotate(-45deg);
      transform-origin: 3.75em 3.75em;
      border-radius: 7.5em 0 0 7.5em;
    }

    div:where(.swal2-icon).swal2-success [class^="swal2-success-circular-line"][class$="right"] {
      top: -0.6875em;
      left: 1.875em;
      transform: rotate(-45deg);
      transform-origin: 0 3.75em;
      border-radius: 0 7.5em 7.5em 0;
    }

    div:where(.swal2-icon).swal2-success .swal2-success-ring {
      position: absolute;
      z-index: 2;
      top: -0.25em;
      left: -0.25em;
      box-sizing: content-box;
      width: 100%;
      height: 100%;
      border: 0.25em solid rgba(165, 220, 134, 0.3);
      border-radius: 50%;
    }

    div:where(.swal2-icon).swal2-success .swal2-success-fix {
      position: absolute;
      z-index: 1;
      top: 0.5em;
      left: 1.625em;
      width: 0.4375em;
      height: 5.625em;
      transform: rotate(-45deg);
    }

    div:where(.swal2-icon).swal2-success [class^="swal2-success-line"] {
      display: block;
      position: absolute;
      z-index: 2;
      height: 0.3125em;
      border-radius: 0.125em;
      background-color: #a5dc86;
    }

    div:where(.swal2-icon).swal2-success [class^="swal2-success-line"][class$="tip"] {
      top: 2.875em;
      left: 0.8125em;
      width: 1.5625em;
      transform: rotate(45deg);
    }

    div:where(.swal2-icon).swal2-success [class^="swal2-success-line"][class$="long"] {
      top: 2.375em;
      right: 0.5em;
      width: 2.9375em;
      transform: rotate(-45deg);
    }

    div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-line-tip {
      animation: swal2-animate-success-line-tip 0.75s;
    }

    div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-line-long {
      animation: swal2-animate-success-line-long 0.75s;
    }

    div:where(.swal2-icon).swal2-success.swal2-icon-show .swal2-success-circular-line-right {
      animation: swal2-rotate-success-circular-line 4.25s ease-in;
    }

    [class^="swal2"] {
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    }

    .swal2-show {
      animation: swal2-show 0.3s;
    }

    .swal2-hide {
      animation: swal2-hide 0.15s forwards;
    }

    .swal2-noanimation {
      transition: none;
    }

    .swal2-scrollbar-measure {
      position: absolute;
      top: -9999px;
      width: 50px;
      height: 50px;
      overflow: scroll;
    }

    .swal2-rtl .swal2-close {
      margin-right: initial;
      margin-left: 0;
    }

    .swal2-rtl .swal2-timer-progress-bar {
      right: 0;
      left: auto;
    }

    @keyframes swal2-toast-show {
      0% {
        transform: translateY(-0.625em) rotateZ(2deg);
      }

      33% {
        transform: translateY(0) rotateZ(-2deg);
      }

      66% {
        transform: translateY(0.3125em) rotateZ(2deg);
      }

      100% {
        transform: translateY(0) rotateZ(0deg);
      }
    }

    @keyframes swal2-toast-hide {
      100% {
        transform: rotateZ(1deg);
        opacity: 0;
      }
    }

    @keyframes swal2-toast-animate-success-line-tip {
      0% {
        top: 0.5625em;
        left: 0.0625em;
        width: 0;
      }

      54% {
        top: 0.125em;
        left: 0.125em;
        width: 0;
      }

      70% {
        top: 0.625em;
        left: -0.25em;
        width: 1.625em;
      }

      84% {
        top: 1.0625em;
        left: 0.75em;
        width: 0.5em;
      }

      100% {
        top: 1.125em;
        left: 0.1875em;
        width: 0.75em;
      }
    }

    @keyframes swal2-toast-animate-success-line-long {
      0% {
        top: 1.625em;
        right: 1.375em;
        width: 0;
      }

      65% {
        top: 1.25em;
        right: 0.9375em;
        width: 0;
      }

      84% {
        top: 0.9375em;
        right: 0;
        width: 1.125em;
      }

      100% {
        top: 0.9375em;
        right: 0.1875em;
        width: 1.375em;
      }
    }

    @keyframes swal2-show {
      0% {
        transform: scale(0.7);
      }

      45% {
        transform: scale(1.05);
      }

      80% {
        transform: scale(0.95);
      }

      100% {
        transform: scale(1);
      }
    }

    @keyframes swal2-hide {
      0% {
        transform: scale(1);
        opacity: 1;
      }

      100% {
        transform: scale(0.5);
        opacity: 0;
      }
    }

    @keyframes swal2-animate-success-line-tip {
      0% {
        top: 1.1875em;
        left: 0.0625em;
        width: 0;
      }

      54% {
        top: 1.0625em;
        left: 0.125em;
        width: 0;
      }

      70% {
        top: 2.1875em;
        left: -0.375em;
        width: 3.125em;
      }

      84% {
        top: 3em;
        left: 1.3125em;
        width: 1.0625em;
      }

      100% {
        top: 2.8125em;
        left: 0.8125em;
        width: 1.5625em;
      }
    }

    @keyframes swal2-animate-success-line-long {
      0% {
        top: 3.375em;
        right: 2.875em;
        width: 0;
      }

      65% {
        top: 3.375em;
        right: 2.875em;
        width: 0;
      }

      84% {
        top: 2.1875em;
        right: 0;
        width: 3.4375em;
      }

      100% {
        top: 2.375em;
        right: 0.5em;
        width: 2.9375em;
      }
    }

    @keyframes swal2-rotate-success-circular-line {
      0% {
        transform: rotate(-45deg);
      }

      5% {
        transform: rotate(-45deg);
      }

      12% {
        transform: rotate(-405deg);
      }

      100% {
        transform: rotate(-405deg);
      }
    }

    @keyframes swal2-animate-error-x-mark {
      0% {
        margin-top: 1.625em;
        transform: scale(0.4);
        opacity: 0;
      }

      50% {
        margin-top: 1.625em;
        transform: scale(0.4);
        opacity: 0;
      }

      80% {
        margin-top: -0.375em;
        transform: scale(1.15);
      }

      100% {
        margin-top: 0;
        transform: scale(1);
        opacity: 1;
      }
    }

    @keyframes swal2-animate-error-icon {
      0% {
        transform: rotateX(100deg);
        opacity: 0;
      }

      100% {
        transform: rotateX(0deg);
        opacity: 1;
      }
    }

    @keyframes swal2-rotate-loading {
      0% {
        transform: rotate(0deg);
      }

      100% {
        transform: rotate(360deg);
      }
    }

    @keyframes swal2-animate-question-mark {
      0% {
        transform: rotateY(-360deg);
      }

      100% {
        transform: rotateY(0);
      }
    }

    @keyframes swal2-animate-i-mark {
      0% {
        transform: rotateZ(45deg);
        opacity: 0;
      }

      25% {
        transform: rotateZ(-25deg);
        opacity: 0.4;
      }

      50% {
        transform: rotateZ(15deg);
        opacity: 0.8;
      }

      75% {
        transform: rotateZ(-5deg);
        opacity: 1;
      }

      100% {
        transform: rotateX(0);
        opacity: 1;
      }
    }

    body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) {
      overflow: hidden;
    }

    body.swal2-height-auto {
      height: auto !important;
    }

    body.swal2-no-backdrop .swal2-container {
      background-color: rgba(0, 0, 0, 0) !important;
      pointer-events: none;
    }

    body.swal2-no-backdrop .swal2-container .swal2-popup {
      pointer-events: all;
    }

    body.swal2-no-backdrop .swal2-container .swal2-modal {
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.4);
    }

    @media print {
      body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) {
        overflow-y: scroll !important;
      }

      body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown)>[aria-hidden="true"] {
        display: none;
      }

      body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container {
        position: static !important;
      }
    }

    body.swal2-toast-shown .swal2-container {
      box-sizing: border-box;
      width: 360px;
      max-width: 100%;
      background-color: rgba(0, 0, 0, 0);
      pointer-events: none;
    }

    body.swal2-toast-shown .swal2-container.swal2-top {
      inset: 0 auto auto 50%;
      transform: translateX(-50%);
    }

    body.swal2-toast-shown .swal2-container.swal2-top-end,
    body.swal2-toast-shown .swal2-container.swal2-top-right {
      inset: 0 0 auto auto;
    }

    body.swal2-toast-shown .swal2-container.swal2-top-start,
    body.swal2-toast-shown .swal2-container.swal2-top-left {
      inset: 0 auto auto 0;
    }

    body.swal2-toast-shown .swal2-container.swal2-center-start,
    body.swal2-toast-shown .swal2-container.swal2-center-left {
      inset: 50% auto auto 0;
      transform: translateY(-50%);
    }

    body.swal2-toast-shown .swal2-container.swal2-center {
      inset: 50% auto auto 50%;
      transform: translate(-50%, -50%);
    }

    body.swal2-toast-shown .swal2-container.swal2-center-end,
    body.swal2-toast-shown .swal2-container.swal2-center-right {
      inset: 50% 0 auto auto;
      transform: translateY(-50%);
    }

    body.swal2-toast-shown .swal2-container.swal2-bottom-start,
    body.swal2-toast-shown .swal2-container.swal2-bottom-left {
      inset: auto auto 0 0;
    }

    body.swal2-toast-shown .swal2-container.swal2-bottom {
      inset: auto auto 0 50%;
      transform: translateX(-50%);
    }

    body.swal2-toast-shown .swal2-container.swal2-bottom-end,
    body.swal2-toast-shown .swal2-container.swal2-bottom-right {
      inset: auto 0 0 auto;
    }
  </style>
  <link type="image/x-icon" rel="icon" href="/favicon.ico" />
  <link rel="apple-touch-icon" href="/favicon.ico" />
</head>

<body style="">
  <noscript>You need to enable JavaScript to run this app.</noscript>
  <div id="root">
    <div class="DefaultLayout_body__8UiY1">
      <div class="DefaultLayout_toper__5eglt">
        <div class="DefaultLayout_toperM__iDQfz">
          <img
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAtCAMAAAAQuiwzAAABEVBMVEUAAAA5n9g5n9g5n9j/pxr/pxr/pxr/pxo5n9j/pxo5n9g5n9g5n9g5n9g5n9j/pxo5n9g5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9g5n9j/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9j/pxr/pxr/pxr/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxo5n9g5n9g5n9j/pxr/pxr/pxr/pxr/pxo5n9j/pxqnntYWAAAAWXRSTlMAUCP9hvr2FwsFDqKcWWRPBPc/PBAHh0MI8/KAMSQZDdi/rZdqFOfk1MnDkpGNinpXE+3htrSup2hhOZ9/cVJMSUcsKR0L7efez4lzbTjXx7eWeGAaultNHyQiKA0AAANoSURBVFjDjdbXWupAFAXgFYoUUVFKEFBRBGyASMcGtmPvDd7/QU6iQGYNyeC6UpLvZ7OTmdlArhQvHfc0rXdcisfjqTCEnKWMT+Y07XQuZVwsxR9gZK17sjDOiQ5K9NZj5fYIcPXFHPghpNGnzAZh5Dw/ELLDfHogJqnkNxcndJOvisIh8/t/5yP/7HSkZ0ShqeIzMn8ds/SCrY4lErIq/kPmG2En3Q87fuZexddlvhZW6NP5QJn4XZlfj9n3PQYHvsX8LvEemZ/9rf5B0sXV0KV3Q2e+SHwZiBCUghmt4KzjXgSu0ip+H5ib5Df7lBDpKBPfUTXnRObjpu5mPQbKnQjkfXTt8oP4tMS736bqzFdBWXsi3ifzPXknCPkBqb0qfkfNa3Y6C00R2FLxmQqwSXxjmo7ohihsSBe3xItPUcT2+hS1ztVP8hUvbdbEK3RF9Qo+myDeQedcZBS878+8ey+I6fwhKB3ijwKIvTjoxwBckfAEv5IUAG8ZlAV50QbX7fV5AOHa4qqs82nqvQNFp+rbBr/trIeM3WwKfwRKi6pfcuAXTR0h8685me/Qdr8Pyi3xK8yz/vtQrnPgtGm774BSZt6298s/+uvwvxcofv/MEu9HTZnPFez14/Fo0mP+XsXvyPyqW6Wb2ab3P5FV8Im8A899531ujw6MQwWvzzjwXPvDgfSNVqLPxOvE81GYeR/xrCPHz/vxzBJ8W/Tee0T9m3tz4wM0gl6Hm8Ap/6aa3+JvqPpii4qnNNcMiJzxIgr1KSWrOXUaFD6rJ5ejp9JKMu8JABrzwnRMebN/c5Ldw0FTT79HKyt6fSCla60emUeK+YOI/apN62aLnjbq1YGc6jeAkgOf22b/0YXfnHvF3ncrOwOHtLlK5jHvZn97dTSI8Y655KDfXMAIH1YarIT6nPWhn+YJPnDLLC+4GhFnAh+z2sMzfpmHwMqzjZ7/wk94Abkg5Oxa8hs5mEkU+TzxTbY/0xkaNSeefe7PZ54msbUs40mPb0QUFDxcs27JH76f70WvOCsEdKFBV57zwFhYVvEIajW+oTBcX4mVVt0rDAuXnbuNLSM32f2LBKDgOUHXaarxaN212HgYTYPn7ezPzLP7W2zUZyYByqkmxnYuC/tzqzlXb3RPJGgdH9EL/atdXIBT/gP2U0j1J1W0LwAAAABJRU5ErkJggg=="
            style="display: none" />
          <div id="showbox" class="DefaultLayout_topTime__QHW-l" show-time="">
            <div><time id="current-time" datetime="1743611162032">02-04 23:26</time></div>
          </div>
          <div class="DefaultLayout_topCtrl__Ux6rj">
            <span>|</span><a
              class="DefaultLayout_btn_setFavor__QqyWm"
              set-favorite=""
              name="Thương hiệu Casino chuyên nghiệp số 1 Châu Á, [đối tác chính thức của Laliga trong 5 giải đấu lớn] cùng các trò chơi giải trí (Thể Thao, Casino, E-Sports, Xổ Số)"
              title="Thêm yêu thích"></a>
          </div>
          <div class="DefaultLayout_loginArea__7sXG5">
            @auth
            <ul class="horizontal-menu">
              <li><span style="color: #d4a34c">Đồng</span></li>
              <li><span style="font-size: 15px;">{{ Auth::user()->name }}</span></li>
              <li><span style="color: #ffde00; font-size: 15px;">$ 0</span></li>
              <li class="member_total"><span class="memberPArrow" style=""></span>
                <div class="memberPMenuT" style="right: -200px;">
                  <!-- ngRepeat: groupgames in ctrl.BalanceViewGroups track by $index -->
                  <div class="editview ng-scope" ng-repeat="groupgames in ctrl.BalanceViewGroups track by $index">
                    <!-- ngRepeat: group in groupgames track by group.GroupID -->
                    <ul ng-repeat="group in groupgames track by group.GroupID" class="ng-scope">
                      <li class="pMenuN ng-binding">THỂ THAO</li>
                      <!-- ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">KU Thể Thao</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">JZ Thể Thao</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">CMD</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">SABA</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">AI</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">PANDA</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                    </ul><!-- end ngRepeat: group in groupgames track by group.GroupID -->
                    <ul ng-repeat="group in groupgames track by group.GroupID" class="ng-scope">
                      <li class="pMenuN ng-binding">XỔ SỐ</li>
                      <!-- ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">KU Xổ Số</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">BBIN</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                    </ul><!-- end ngRepeat: group in groupgames track by group.GroupID -->
                    <ul ng-repeat="group in groupgames track by group.GroupID" class="ng-scope">
                      <li class="pMenuN ng-binding">E-SPORTS</li>
                      <!-- ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">IM</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">DB E-sports</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                    </ul><!-- end ngRepeat: group in groupgames track by group.GroupID -->
                    <ul ng-repeat="group in groupgames track by group.GroupID" class="ng-scope">
                      <li class="pMenuN ng-binding">LIVE</li>
                      <!-- ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">COOL-IN</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                    </ul>
                  </div><!-- end ngRepeat: groupgames in ctrl.BalanceViewGroups track by $index -->
                  <div class="editview ng-scope" ng-repeat="groupgames in ctrl.BalanceViewGroups track by $index">
                    <!-- ngRepeat: group in groupgames track by group.GroupID -->
                    <ul ng-repeat="group in groupgames track by group.GroupID" class="ng-scope">
                      <li class="pMenuN ng-binding">LIVE CASINO</li>
                      <!-- ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">KU Casino</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->


                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">AG</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">WM</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li><!-- end ngRepeat: row in group.GameServices track by row.GameID -->
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <!-- ngIf: row.ServiceName == 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' --><span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">GPI</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <!-- ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' --><span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">DG</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">SA</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">AES</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">EVO</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">
                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">DB Casino</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                    </ul>
                    <ul ng-repeat="group in groupgames track by group.GroupID" class="ng-scope">
                      <li class="pMenuN ng-binding">ĐỐI KHÁNG</li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">V8</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                    </ul>
                  </div>
                  <div class="editview ng-scope" ng-repeat="groupgames in ctrl.BalanceViewGroups track by $index">
                    <ul ng-repeat="group in groupgames track by group.GroupID" class="ng-scope">
                      <li class="pMenuN ng-binding">GAMES</li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">3D</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">BNG</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">CQ9</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">PLS</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">RK5</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">DS</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">KS</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">PG</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">KA</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">FTG</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">FC</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                    </ul>
                    <ul ng-repeat="group in groupgames track by group.GroupID" class="ng-scope">
                      <li class="pMenuN ng-binding">VÍ KHUYẾN MÃI</li>
                      <li ng-repeat="row in group.GameServices track by row.GameID" class="ng-scope">

                        <span class="pMenuT ng-binding ng-scope" ng-if="row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน'" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;: ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;)}">Ví bạn bè</span><!-- end ngIf: row.ServiceName != 'กระเป๋าเงินเชิญเพื่อน' -->
                        <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" style="">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                      </li>
                    </ul>
                  </div>
                </div>
                <div class="memberPMenuB" style="right: -200px;">
                  <div ng-repeat="row in ctrl.model.GameMenusBottomList track by row.GameID" class="ng-scope">
                    <span class="pMenuT ng-binding" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;:(row.GameID === &quot;Lover&quot; ? &quot;#cb83ff&quot;: row.GameID === &quot;Total&quot; ? &quot;#ffd200&quot; : ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;))}" style="color: rgb(203, 131, 255);">Quà tặng miễn phí</span>
                    <span class="pMenuP ng-binding ng-scope" ng-if="row.Balance !== null &amp;&amp; row.Visible == '1' &amp;&amp; row.GameID != 'Total'" ng-bind="row.Balance | number" ng-style="{&quot;color&quot;:(row.GameID === &quot;Lover&quot; ? &quot;#cb83ff&quot;:&quot;&quot;)}" style="color: rgb(203, 131, 255);">0</span><!-- end ngIf: row.Balance !== null && row.Visible == '1' && row.GameID != 'Total' -->

                  </div>
                  <div ng-repeat="row in ctrl.model.GameMenusBottomList track by row.GameID" class="ng-scope">
                    <span class="pMenuT ng-binding" ng-bind="row.ServiceName" ng-style="{&quot;color&quot;:(row.GameID === &quot;Lover&quot; ? &quot;#cb83ff&quot;: row.GameID === &quot;Total&quot; ? &quot;#ffd200&quot; : ((row.Balance == 0 &amp;&amp; row.Visible == &quot;0&quot;)?&quot;#ff6d6d&quot;:&quot;&quot;))}" style="color: rgb(255, 210, 0);">Tổng số điểm</span>

                    <span class="pMenuP allP ng-binding ng-scope" ng-if="row.Balance >= 0 &amp;&amp; row.GameID === 'Total'" ng-bind="row.Balance | number">0</span><!-- end ngIf: row.Balance >= 0 && row.GameID === 'Total' -->

                  </div>
                  <a ng-if="ctrl.CheckTopMenuPermission('CanPlatfromTransfer') &amp;&amp; ctrl.isTransferGamesPointToMain == true &amp;&amp; ctrl.isTransferGamesPointToMainSingle == true &amp;&amp; ctrl.NoneAvailableGame == false" class="returnMainP ng-scope" ng-click="ctrl.TransferGamesPointToMain()">
                    Chuyển hết về tài khoản chính
                  </a>

                </div>
              </li>
              <li class="topup">
                <a href="#"><span style="background-color: #1ebf8c">Chuyển qũy </span></a>


              </li>
              <li class="topup">
                <a href="#"><span style="background-color: #f39800;">Nạp tiền </span></a>
              </li>

              <li class="topup">
                <a href="#"><span style="background-color: #f39800;">Rút tiền </span></a>

              </li>
              <li><span class="btn_member"></span></li>
              <li><span class="btn_personalMsg"></span></li>
              <li>
                <a href="{{ route('logout') }}"><span class="btn_signout"></span></a>
                </li\>

            </ul>
            @endauth
            @guest
            <a class="DefaultLayout_btn_addMember__4C0Zc" id="open-register">Đăng ký</a>
            <a class="DefaultLayout_btn_login__Dtd-4" id="open-login">Đăng nhập</a>
            @endguest
          </div>
        </div>
      </div>
      <div id="MainMenu">

        <div
          class="DefaultLayout_menuArea__IVTrv DefaultLayout_ng-scope__Sw0v5">
          <div class="DefaultLayout_mainMenu__cDqOR">
            <div class="DefaultLayout_logo__B-hql">
              <img
                alt="KU CASINO"
                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAAAXCAMAAAA/dJG5AAACxFBMVEUAAABbialijq05n9hSg6U5n9g5n9haiak5n9g5n9hbiak5n9g5n9g5n9hgjaz/pxlslrP/pxo5n9j/pxpok7A4n9lqlLJEndBplLH/pxr/pxprlbNij65biqr/pxr/pxpkkK7/pxr/pxr/pxY4n9k5n9g5n9hrlbL/pxr/qBQ5n9j/qBQ5n9j/pxn/pxQ5n9j/px1tl7T/pxg5n9g5n9hfjaz/pxpok7H/pxpqlbRqlLJpk7E5n9j/pxo5n9hplLH/pxr/pxs5n9j/qBI5n9g5n9hrlbJrlbI5n9hSl8gfnvFhlL5VhadplLJWhqf/qBZfjKz/pxpThqhfjaxZiqw5n9g5n9hmkrJbiqr/pxo5n9hbi63/pxr/pxr/qQVplLH/pxr/qBA5n9j/pxr/qgNqlLJrlbL/pxr/qQVslrNrlbJqlbI5n9j/pxr/qQ5mlbdbk8P/qBZRgqT/pxo5n9hVhac5n9hplLFZialij61hjq1Yh6hlkK9plLFThqz/qA9djbH/qQb/qQM5n9g5n9hbiak5n9hbi65lka85n9g5n9hgjq//qQY5n9g5n9hZj7z/qQb/pxpVkMM5n9j/pxpYkcFslrJrlbJbksD/pxpYk8ZPks9Qks7/pxr///85n9j/pxqCpr7u8/dul7P9/v5WhqdThKZ9orxqlLKEp79ymraApL1LfqHv9PfI2ONslbNjj65ciqpZiKnn7vJejKzX4uqsxNR5n7p1nLdgjq1RgqQ/dpz4+vzb5u3B09+zyNihvM6SsceNrcNvmLVul7Rpk7H6/P309/nT3+jP3ebE1eG/0d25zdu2y9mqw9OnwNKkvdCZtsqGqMB7obtPgqT/pxvx9vjr8fXh6u/d5+64zNqWtMiRsMZNgKNJfaBEeZ31+Pnw9feuxdWeuc1mkq80bZbM2uSHqsFzm7Y8c5k5cZj/px0tHubqAAAAnnRSTlMA3Mlm6kz73PPkt18k3tnTzsnFsmlVSw/h3s3CqKSek5CGgV5YUkc1NS8sHBgNB/fy2dnYzLeklYuKgnx6dHBvaVJCQTgxLCQcEwUE+fPy7Orj4dXU0tHIyMK9vbqurqyhj452bWpkY1hUQj49KCIaCf7z8u7u7enj3NzZ0s/Py8bDwrevrq2sn56dmZmPh4eDeHd0cWZdV1NNQTAhFYUrBl4AAASISURBVEjHXZX1Q1NRFMe/iKIoCAKihAoioCLY3d3d3d3d3d2tU5A3NmLlkJKQkA4Jlbbzn9B3zhvb2+eX3XN29/3u3DgXk5v4j9oS4G/rAMJ2iK2t7e1VQyYBq9v7rvZt3+8piIeerf7jsQwY2NamqQ3TtOns5feAQeYMZQ/2PESxOWPT1guwf0a0hkiTZ4wtgF7PiSAQHTk6CXipotShjFodbxS8JvfnjInSOF1cqTmkeZH7gT6svQUAxthxECAGrUh6egiIO+x0BTgRma1oIDu2Rum1OO6twpKCJI3CitAFgAuLjwUwVjJqAhEnkvYAc5OdbgBzIuQibwS9Wp5JTaq0dorvC8xldQdgbHdLI2n1PMH4stMaTD7wUy7yWpWYLs8U1720MgrTegOOpG7XDV0lI38QITNJeiGYAey0AROnvaEfv6+s/MAy75Kqrao0WAQ8Wdff5NQME5qZjgYT3IOkXcG0Z6fReKL8Sj8uiTYaUmiU9ieNPzOjiNCsjMKqqqqiWMrGanJzc1J1A4HepO/iYG9eOiKogqT7gVlBUUUXPE4sIoWa6G9JvGPpSZyJ/x5NlKu0ysTExO/FYjI8I1qv1xu1gzCJHRz3WRlhGxexAsxSinYG4VF5IevWC8oCXpnyVF60jAgiPmv5urXr+gtU8acMGzc3t7XDx6GNtGjWRujyXFbTEj7zwXgg5NF/zU3RfCSDUkHIV1BKQmNwB7DZ8IPOgsobhNypNdrARGd26gDGk6JewF1DrsKCl7/qMgX59clTik7D9bH0/bcLYCbYmY06IcDRARKj2WkoGA+KnIBbxmRL2Q/FugR9jvzi1gYCGJxAJScn+IBxMDu1EA+6CyRGstN6EMG7KToOXNfxZfkcExZOA40ygbzDY4jP2SXK8QB8VHQJcvSDwXS1MJqwh1oeM4KdRsh27RRwOTOGVkWrzczgUx4lkPdH1YtIkXjtVADw5qalEdzAjDHvUVd7usMTQQxl7ZEg/DhaBpznJher1CfUGl+Lw2ohjP59+YzZLUXaOo8D0LeMSs5XbgQzin3sOgFXebgIxABZTU4crQQWh1IhKfUGQz2bqhPIMP/3rsbM1J4AFvC8QuUmwPKdWAWgm3QMh1k+E0v9QgB0eM6sAY6l8wHLiohI5x2L09JHctor4ktR5BEAh3neF2UgmBbSJvGYGWN5Ipxmurp6SEYV24BZ70yXR8G8NUYo5JQ1B3Y05nklwngww8xPX0Nfb9YNQEgPbnR8r5iVokKxwvqNqJEnPkV6A9unlHD7ndYGzBBLJ4dnjKP47Ya/3GG5t5r6+vbEArmuxliXZv2M+ADjawu5Rc2CxDVLJ3SSrHqLVflRVVtNm1ThCwDjlPlmybDkvGrDjClfw2TE6gYBgUIqBeo5kDhj2ifGf15DvwCCOopHrgs6D1ji6dpxK0Q2ZZWVhjLqshc6Ye/wjaoXcrRZg4H7qkwKVD0hcbG3Sx+XefYBMDFq2KVzpxfZ92k9ibqfX4ehwbBgs3Pf5iJn2/3Hx819IgKd5zeS4+wOuEvZowPB/AOaQgC9W+QxNwAAAABJRU5ErkJggg==" />
            </div>
            <div class="DefaultLayout_menu__6miiq" main-menu-slide="">
              <ul>
                <li>
                  <a class="DefaultLayout_menuA__Eilgx"><img
                      class="DefaultLayout_iconActivity__4SkTL"
                      src="data:image/gif;base64,R0lGODlhHgAeAPcAAPz+/+mZBfz3pvuDd+dFC61JMtqNF//p5f/97f75kuyOKbkwNP3odNyxSPy8auYxEP/5heSpFvbimOenDOt8fP7+/OYVEsRTJ///9NFwLf/y9f/0ff/2+dl6a/54N/pyTNiJWOY8D///vP/z7dd2HOW9J//o1rp9hv3sqPmRjPN0BP72iv/5jf/Hxf/5/v/FU//83P/zdd2VLP3pa/3//Nh5DckzJ/r//6xeTPX//P/1hv/SVdlYB+QoD//MqtypFP/5+uKHGuopEunELf/+8f/njP/9w+mGBPPMTNhVGclwSf/Y1tQbGP/2gf3MjP/++///5/CTBMQXGf/90//59vnGebARG9tmF8yMhMdKSeWODf/byt0rF+OkIu1lA//8//e1Nt21I+SbFuYdEunHeuyADdRlB+pzBK8eJeLHWNhGFt7DSu+FAP2qhf/+4P/9/P2wdv+1sN9CDNc0GeacVu3DRvjEZv/0xPr//OF/HObJaP/L0v/xhvzCt//Ul//wfuKzTP/64e5+Av/15epZA8olG/7FndulLO6jBfz/+u2mWf++pv/+yf/s8OxGEdkHDP+uquQNEupqBOrcktm9Pt6FC//zsv/edY8bJfzRhPuiY+ispeNlBPeoKuFYEPzRuuWoieteDPr/+v/1vOUHDf/48bYpIdw7D9mfPv3WT/ylr+x6C//++Ojbi+pQBuJcBPeqRfFsAtsOFv7nYOVmC+BvAvCOA+1RDP/8+v39/f/9tMoMGum5IPu5lP+xRex0CtNaZfZoI+xtCP/89v/e5v/zbf/20+iOBOmoM+2JCPj////75+ROCN9SBeZ4D/BSC//5fd5+A86PfOVqDvCYPf/w3O06Dt9vFff//P38/81dF//uuo45Nfv/9M9iIf/WcdBPCu5fIMhBIvCHDu8gC//3dOeBAN26T/j5+uymsPn5//+9yPK1YeAgEPGpdP+dbssRGv/Vn+AtC/j8//uZWPr8/OdyCu4+Fsyprf+unP/9///9/v7+/v///f/+/////yH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDcuMS1jMDAwIDc5LmIwZjhiZTkwLCAyMDIxLzEyLzE1LTIxOjI1OjE1ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjMuMiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6OTI4MzUzRjVDMjNDMTFFREFEM0I5RjA4NTg5MjkyOTkiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6OTI4MzUzRjZDMjNDMTFFREFEM0I5RjA4NTg5MjkyOTkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo5MjgzNTNGM0MyM0MxMUVEQUQzQjlGMDg1ODkyOTI5OSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo5MjgzNTNGNEMyM0MxMUVEQUQzQjlGMDg1ODkyOTI5OSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgH//v38+/r5+Pf29fTz8vHw7+7t7Ovq6ejn5uXk4+Lh4N/e3dzb2tnY19bV1NPS0dDPzs3My8rJyMfGxcTDwsHAv769vLu6ubi3trW0s7KxsK+urayrqqmop6alpKOioaCfnp2cm5qZmJeWlZSTkpGQj46NjIuKiYiHhoWEg4KBgH9+fXx7enl4d3Z1dHNycXBvbm1sa2ppaGdmZWRjYmFgX15dXFtaWVhXVlVUU1JRUE9OTUxLSklIR0ZFRENCQUA/Pj08Ozo5ODc2NTQzMjEwLy4tLCsqKSgnJiUkIyIhIB8eHRwbGhkYFxYVFBMSERAPDg0MCwoJCAcGBQQDAgEAACH5BAQDAAAALAAAAAAeAB4AAAj/APcJHMiP35N9+lxo4ABkHz9//77o0+cP4r9+GPsNJGgQoYsT6TS4cPHFxT+KFi9m3CiwYEEALlRhAkaMQ8SK/wAAoJERI0uH/HQC4LDHipUFezjgepNTZ0+fLF8C4MdhiZVd8NC0AHJw6lOoG6VW4NDCiixZ8BYsAaIPgMqnE/cdBFowEYcB8GRFerQrywEXAPxVwEijMI24c11WoDJiwdlHkWRZocABJWHDLg0+qQCgHpARFOBFGj1aFpq1//z1M3zjhs6Ccis86VcKkilZFnJHyi2FwggX+v4VBtAamzIAE/XxezOoxQIm7SyMkZ670IIDHCQSb30D242HE/1R/zFRoFC78+fHjGlnPU6fRkyJ60z0RN+X1F+qdbDBhUuPHu088F8P8tgwQB9YlPJEThM98YZ9uTzBSh/iPGChPPJYGEKGp8zxwSfcbMEKLtnY98RB+rBSyiAdiBNCCNZYE8IpctT4ooeGFCANAqXg8oU/J/KDCwbVmHCBGgQQ4IgjBIADRzhyECAHMx+8cwEOJhDRT2onvkFENaB8coEnrtzyjCs8UFPEFc0ww4wnHgSThDY+INAPK6ycWAEChoDghDeeECIoIWZcUkQerwgaSjCheKINHIPciUEFsi3jTgZOZDCNF5zSEgQffPhSixeEcOoFLdfQMcgbElL6RCB0kP/gwDX2nGGrM77wocMlldijggqxxLJKqsvMNhcugShSgwJlCOJsNJW8oOsfL1TirLNlBKFIIBYNFIgDQWhxhDlHVNKJATvoqsMfYFRyBBtsHGGAA8vg5NIymcigRRTHaNHFDIfs8McKOjRRjBhR2BKFFjJIAEVF/giFwDaoiBFAAGKk0kQdSOiwAgQQxIDExVGIgcooRKTmT2E3EBEIGV0ggkgEMUDAwBog6wABNMVMIHMXZBijZUWF4cEKEXc0EMEEJcTQxAYz/AEBwU3EwMsEEQBiBAZEPFFRa3gkMgwUKJwTxhDlNAHBBhDo4HYT5ZRQAiAoQIEBKyq3NhwRxqBLsAYlELDAQgKEE77CBmukYQkMGKj8NQCUQk6EG6NMMokAmGOOAgoCtILCHVCwAjHErkWuEwZuTMGICKyLYMTrIowyBRQ03DB6RQEBACH5BAQDAAAALAAAAAABAAEAAAgEAPcFBAAh+QQEAwAAACwAAAAAAQABAAAIBAD3BQQAIfkEBAMAAAAsAAAAAAEAAQAACAQA9wUEACH5BAQDAAAALAAAAAAeAB4AAAj/APkJHChw374K/P6hY9XP3z8AAP75m0iRIkGC+/gh/PcPV0OOEiuKvEgQAA2O+v5p+KJPn8iXJAcC2PjFBb4vIV9WjGlwn8N/LhrhcOHS5U+OO0n2zAgACDFuGv59+TIRZE5/MQfm2sphD6YWQCj2G/sQKdaYEEFyUIUJiwYXHMf2KxvyIkKB+iJ+0QDMSpaVHCs8GUuD7D+7A/P6c0FMihQ0e4CAlFt47kOImCtUyDjvCwcKUphISUGFY8R+T2ioHnuj9Q2IGvnt+wekhSkmY5hkGfEEp0TChWnkGK4MgMCILqhUy1Ko3Zh2hVo0AqJPndGHNPAMz6Es4eV9IzrY/+AipLyNFJtKV3yIB4+o9zRSQsxGY5G4OQ/yP5jzIUWLUlQN1E92mmmW0j/9sDKIEqecEoIcjoRwygVtKDEILvrwY9w/2S2VECsIbNHLBWoQwAw49BDgiBr0UFiKT5fdgMdS/zxBxCeGgOCJK654ooADzTDTjAeeZFDNMHMB0JoyLVXVjTEg+OEND6EQ8ood35jxypavaNMLAsNo6FpLPvWDQDwZOEDCNMJIUsMlfJBQiyReSHKNEowgwA8NrgnYDxSK5EGNM6ucsYoCf6zwQg2rqKBCGSTEg8BlsAnUkBvUlDHOOEdEowUyOujABzKVmCOIOUFUscxlHA00USAyHNRjyzHHdAJGHRCEyoAYsiajBTurmuWqPjCgIkYAAXQxSyp1NMHCCn+kcmwUYrDjBkgTHTcYDICIMcEESMQQwxob5LpBDCVMgEgXdlxr1XEV4AJDJodEEMYsG0DDwB8QQFBuKj9EcIgEUFjGkWp40FABAozoEUYYxUDTRBP9+gvNLA+TkadcrMmYMAZQbJMGJQxA8GwCCbDAQhMzUKLHKFAwxHFrACSSCCvDLMPIJK0I4PPPPrciwR0xG9ZxzTbz8wQUUzAiwtNQ66KLCFMgwMppcfUTEAAh+QQEAwAAACwAAAAAAQABAAAIBAD5BQQAIfkEBAMAAAAsAAAAAAEAAQAACAQA+QUEACH5BAQDAAAALAAAAAABAAEAAAgEAPkFBAAh+QQEAwAAACwAAAAAHgAeAAAI/wD1CdS3ryA/AAD0+QNAAxcuDo2+/PuH8J+/ixgHEjQIgJ9Af1/8aUh3YuJEABYxXuTHsuWTJxX2fXEBkRgwTKpcfPnypB+NiSoRImRZ8Mk+gRz2LLCCaY+Lif16AsWIrSq2jgN3cli3YNcuNMT+Kfu3702/s2cvWr2a0oULKku6kpJlpQWQG1PR9rtIg0YiGvz8Wcz15ECWXY9IPYI3gEo/iyn96a1Q4eU+wf6ojKAgJTEpxTYOUOGgLxvGyU/eqH4DAEipJWiYyIpEW5YUCiOo5GKp92zMgqpfjugghYmF48eZoIHE6iyACr2xCtyHYUS1BcbHILcwhomNPv/64f+BqZffRH38cGHok88UFyFj2pGbT05IoQLEMPSjrHegvzelYLHIAHO8J4QQDxxYHxdzdECEfuG99MR0rplQgA8fzPHAhhw+YI0Q1sxhyicY/KMQWsCVMoI0BfTywSn33GNNCHLIYc2N1twjTgel7LTQUPtUUMogOFzwjgdyOOKIHMFokgQBBCjpiBoFmHDAMPoIdZQ/pfhwQRLBeMCMK8+4ckUR1PBQpivMJHGBD6BUgws6ANzAkj6ltOGNJ6EE8wohhLxCAh/fmBEKoKF44o0TIBhCxD804IEHQ4Nocg0ntNDCiSScmAELHzoEwYkXpNJyRSYZuIPAYwBICkAg9Dj/Y88vv5xRSy01MMAHH77UcoYwKkxzjQMk0BEIq33hAYMiNYwjyBmCmBPNC3/o0MQLlZShrbZ55KHIsRNVEKkbDhiQDBvoVgJGDNVusIMYnVSSzDjjBBEEO8eaB1MuUPghgxZRRHFMFzNAYHATO3QxSxcAR6GFAZnA8IS+FQCAwB2oiBHAxjts0ITBENSBRAypbByAGKhYAkVz/zyRCB5EQOFEFxMgEkEMOujAwAo6pMEANDPUjEgXVdxBxBMTJZKIKKwQcQcgP0zAC84b8LHCCgw00UQ5vEzQCSAqQ/iPpKL8BQUK54RRQjlN6LABC9YaDM0QYTSAghtSTXQDHkrjR4EBDJakQUkMKyRguOEssLABJWncjQFKJt3wXMVNu2GEBJMIoPnmmksggeMmRT45QjQQ4cYURugiwuqsi2AJI250o0xCoQcEACH5BAQDAAAALAAAAAABAAEAAAgEAPUFBAAh+QQEAwAAACwAAAAAAQABAAAIBAD1BQQAIfkEBAMAAAAsAAAAAAEAAQAACAQA9QUEADs=" />KU Siêu HOT</a>
                  <div
                    class="DefaultLayout_menuSubList__mx2Ni"
                    style="">
                    <div class="DefaultLayout_bg_menuShadow__Rjze1"></div>
                    <div
                      class="DefaultLayout_subList__-8hVJ DefaultLayout_subHot__Dolt9">
                      <div class="DefaultLayout_subListDiv__5oE8l" id="0">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>

                        <div class="DefaultLayout_Darkened2__+D8Af">

                        </div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="KU Thể Thao"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAtCAMAAAAQuiwzAAABEVBMVEUAAAA5n9g5n9g5n9j/pxr/pxr/pxr/pxo5n9j/pxo5n9g5n9g5n9g5n9g5n9j/pxo5n9g5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9g5n9j/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9j/pxr/pxr/pxr/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxo5n9g5n9g5n9j/pxr/pxr/pxr/pxr/pxo5n9j/pxqnntYWAAAAWXRSTlMAUCP9hvr2FwsFDqKcWWRPBPc/PBAHh0MI8/KAMSQZDdi/rZdqFOfk1MnDkpGNinpXE+3htrSup2hhOZ9/cVJMSUcsKR0L7efez4lzbTjXx7eWeGAaultNHyQiKA0AAANoSURBVFjDjdbXWupAFAXgFYoUUVFKEFBRBGyASMcGtmPvDd7/QU6iQGYNyeC6UpLvZ7OTmdlArhQvHfc0rXdcisfjqTCEnKWMT+Y07XQuZVwsxR9gZK17sjDOiQ5K9NZj5fYIcPXFHPghpNGnzAZh5Dw/ELLDfHogJqnkNxcndJOvisIh8/t/5yP/7HSkZ0ShqeIzMn8ds/SCrY4lErIq/kPmG2En3Q87fuZexddlvhZW6NP5QJn4XZlfj9n3PQYHvsX8LvEemZ/9rf5B0sXV0KV3Q2e+SHwZiBCUghmt4KzjXgSu0ip+H5ib5Df7lBDpKBPfUTXnRObjpu5mPQbKnQjkfXTt8oP4tMS736bqzFdBWXsi3ifzPXknCPkBqb0qfkfNa3Y6C00R2FLxmQqwSXxjmo7ohihsSBe3xItPUcT2+hS1ztVP8hUvbdbEK3RF9Qo+myDeQedcZBS878+8ey+I6fwhKB3ijwKIvTjoxwBckfAEv5IUAG8ZlAV50QbX7fV5AOHa4qqs82nqvQNFp+rbBr/trIeM3WwKfwRKi6pfcuAXTR0h8685me/Qdr8Pyi3xK8yz/vtQrnPgtGm774BSZt6298s/+uvwvxcofv/MEu9HTZnPFez14/Fo0mP+XsXvyPyqW6Wb2ab3P5FV8Im8A899531ujw6MQwWvzzjwXPvDgfSNVqLPxOvE81GYeR/xrCPHz/vxzBJ8W/Tee0T9m3tz4wM0gl6Hm8Ap/6aa3+JvqPpii4qnNNcMiJzxIgr1KSWrOXUaFD6rJ5ejp9JKMu8JABrzwnRMebN/c5Ldw0FTT79HKyt6fSCla60emUeK+YOI/apN62aLnjbq1YGc6jeAkgOf22b/0YXfnHvF3ncrOwOHtLlK5jHvZn97dTSI8Y655KDfXMAIH1YarIT6nPWhn+YJPnDLLC+4GhFnAh+z2sMzfpmHwMqzjZ7/wk94Abkg5Oxa8hs5mEkU+TzxTbY/0xkaNSeefe7PZ54msbUs40mPb0QUFDxcs27JH76f70WvOCsEdKFBV57zwFhYVvEIajW+oTBcX4mVVt0rDAuXnbuNLSM32f2LBKDgOUHXaarxaN212HgYTYPn7ezPzLP7W2zUZyYByqkmxnYuC/tzqzlXb3RPJGgdH9EL/atdXIBT/gP2U0j1J1W0LwAAAABJRU5ErkJggg==" /><img
                              alt="KU Thể Thao"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAA4CAMAAACrIQowAAACZ1BMVEUAAADRxIarljaljSa2ok2wmT22o07LvW6qkTOumDevnD3CsmzLwIOvmz+umT20oEmrrT64w1yumDq+rGDLzIfDrGry6cHWyY6qlDSnkCuzlhqqniynkCq4qVOpljGjiR69yWyqnTbQwovUt0C3rFO0n0jIvmbn15WpnTGtpj7BpCiufzCdgxGbhBC1ulXApjWxsEu5nFGvpkHVu1OxnEHv2H+5pVW5wGHbcX3XypPd77bYzZ++NS3c4rG7oz3Y06S3pFGrrj6+pzjKqCG4yWKehBTBsWrjymTUuEa/rmTEtG/MQk3Ag1TT6KPZv1bRaWf///+6EhgjNmy+ARIIJXinkCgRK3TCABIAHnq7DRccMm/s59Dl3sGtlTPTx5MAGoKtbyaghxr6+PHg17O4pFG4JxuxKQ63Bw2bgAvp48jd06zWypwdL199c0GzPB2xEAeoHQD8/fj29Onh27bb0KX76aLIy4INJ3DDsW1FSk1vbEqznkavWiKlNwKSdQDKuXzAwm8yQGUOJWQlNV9NVVkrN1FfYFBoY0yumDxLTDyLejlUUTV4bC5ZUyy0TiClchm6MxeuRhCeRQifCAD//enr/drv6tj145rJ3Yray4jNwIcJCnXZxXO7t18+SV8tOlpWVUUwN0RmYUFlXS2diCxVTia2bSNIRCOIcxqrVBalZBM/OhOfUQCmFgD0/+3//9Lq+cvu47rq3rTY76//763Z26rR2Jrp1ogALoLv2Heqn2YhHGG7qVu2wFomSFdNNFVgc1KajVG8f0x5f0d1WUS1ajZlPjSrfyqQex95ZhGceQybXwClLwCPOFvMAAAAUHRSTlMADuLdy7ixNe7KdHEH3ta8uqyek00tIhz39Obay6amin5+fXl1Y1RD/vXy7erky6mkoZSRioNVQUA/PDUXFO7q3NnW0MO5uLi3tZmKg3NlXgGU4GEAAANTSURBVDjL7dT1U9xAFAfwd24FWiilXihWd3d3WbK5JJwr50eR4lKKU1qk7u7u7i5/VDdLe8Bx7e+d6eeHTGa+b3bf2+wEosSPGAR/k233joeBVNoU8kyQwTCvNrlmPCTKgNDN6y2wq8cOXSyVbwRFglIzSLciTpcyVuPVQcTiKXatRC6VZ2aY9UmZY+LkqmS7Nwv6kNvnzJEPl+qp4eq4mWkj9NDXwqlmvV4qlcUrFHEyNSk0T9FBP0MnJmQoyADbN5P3hEylNBX6W5AMMGtdknKyTZG0SQkgWRBVsGTLqBHxo0cr07RjNKM15lEzl0CUNG1K7xlK5o2FgSRAJCnpa6x4eXHiuMS1Jocscdw4f/HCqDRr1tSiApfF6bQc85sClcYD3unbUn6n81MHT64K53eddCCEjCZEnGgPlp9r08zOInuNkdm68jwY8/tLUMSDy1aWLT19JqRWwIQ8LMrBO0pQgbM24EDEzr0sY+AEga2/ADNIgdu2L4ffvwshZ8BfQAuuWw1MqILhgvGQcVXMw7mej7uMyFh2CDl8qPDE2yDb3NDUZC2fDiobrgrzGN88WHAMuWrsyFFZZDGhvUJF3alm67l0GKT2uG2d7lzPuxIfMlXWOFHAdOjos3o2FApVCG0qEJsIf67q6cFnb2kxlxWiw9etTANTVxeUih/6Ksa5OXQKv8ulN9e86JmCMxiE1tniKZo9JCcFJ5HFV2kxtbhM6PFlliHYdhUQQ6oxKcj1dDxEPldhrbOsyKhv5EjONS4DUXIHLcgvsxQbHYVk1iLL0fJScYHz6UBN20Eq8M37t2oRFbh7ew9LFggOlwC16BpdIs97EPUwtxoMDCPsmQu/rMzjaZsvEfX0okByrl4fuTeLOrA4CF99hH6Ir6UkZ4TzkQXIID94cRN844i/+PCX3ZzYYeNI6LV0Qj6mFd2P7l2huaH0Sjb0sZX0SeD8OwfKBZKTDtdDP4OreVrReYajZ3h6ZNSPZOlEugnPP38inuHuC9kQZf438d65bW0NHGMQ2tNhgNTvZNZL4dfvT3HsxQ0Qw5Ab2H2JP/6mydq6GmIa3I33VX2oYM+OlEBsa6r5zmbr2UnD4E+mdfHHX0XymH10fxoVyWP3sUoC//2rfgJ3KhwG9srEdgAAAABJRU5ErkJggg==" /><img
                              alt="KU Thể Thao"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB8AAAA4CAMAAAAy2dOFAAAC9FBMVEUAAADXECDRkynTqTtlSQFZQQDcuF3Ysk7UqjrRmC/UKhrVHR2AXgN4WAF6WAB4VwByUwBdQwBiRwBlSQBOOADo1KWpfATfv2ralk2+dgqiXAOebhWYcATRjSe8iQTNnRy1XwjTpTfTMRiIYQDWHB3SNxiHZAfVrUBoTQFkSQKAXQBNOABUPQBALwDfsnvFkgvUfi3VoSm2bQXOkR/NYBvImRzOXxCxgALOaRTPWRKLZwWrew7SORbFjxTXFh+6jBCXYQPQpCvGlxnQhh/Wr0aCXwTVJBvVIRzTMhh0VQBvVA1/XQBnSwBwUQNhRwBYQABeRABVPgBaQgA/LgBpTADJkBPjyYLWazTNfBe/jzbSpkXSOxamZQO0gguecwbQSROjXwa/WAyPaQPcumGQWATcu2LJVg7ESBHTqjqAYhF4WQbSOxZLNwB+XABhRwB8WgB8WgBZQQBVPgBwUgD////XDyHcLDzytLnhSljtlp330tXod4Lv7+/58uHmaHT9/PeqqqrbwZN6enqRUgH9/Pz279XJycnw4Lfu3bCWlpbnzY7BqIfQtH/ix35hYWFbW1vUnDvWrDh6YjiRVyqrZQVlOQJwQAH5+fn59/P17+bPz8/z58bt5MLf0rTttqXRvqHTx5bo0ZXfypPSwJPFt47UtYqGhobiv3XKtXHLoW1oaGiPfmDifF+fh1ZSUlLYpknJeEmyg0OudTo4ODjRlTTVRSi5jSPVGyC2aBu+XhuuYBScaAKBSgDw8PD79uvl5eXf39/e3t7V1dXt4M/n3sfy1sTl07q2trbazrPv0K7p1Z/Sp5jprZGPj4/olorkyoXRn4O1mHnCinjBpHOnnXPTj3LUsXBsbGy3mGTBn2O8lmOtlGHemWDHilaUdVXddFK+eFG4VUrDhUifgUTLpEOlhUO1k0LXZEA+Pj6JaDyReDvZQzrEnTiogzhuXDe8ZjSnYTSmfiydcyxmVCvIcylmUynVMyPVMSPDbyGbYyG5chmdUQyX6SaxAAAAdHRSTlMA+fPkyWn89+/s6+Lg28rBsZFZOAv+/v39/f38/Pv59vTy8u3r6+noxLWqUjEm/v79/f38/Pv6+vn4+PX09PPz8u/v7uvo4dvby8S0rZ6ehoFxQhYV/fz89/b19fX08/Hw7u3s7Ovq5+Pi4d3c1cO6rKSfjq/I1zUAAALISURBVDjL7dRVUFtBFIDhTQjubsXd3d3dqbu77wXaJoUkuLu7uzvU3d3d3b196SaQNoQwfWam/8vdc76ZO/u0YHolIca62RDKNHAKyhL0medtYGSJDufYEB7ko+yJW+/sr8dQbeUtIBfnvVRNSHiz8EbnVZ4YytFbWUBYREREaMVqfn5dkItWOH4+e3tVHMbIUXW+Kp86OvD70RynYd3RkJbGZbxYHQ18Nm7uK5drudnwYZiXHxjBNDIli2Q6O2VO1JLOmWvMmUWCe+qT4mGctLW6ly6wtTyZdrn2mfnw0JHGQ6mFLtEQQgoRFqIPScVSF6glxGWWHW8d+vEdFpENIQdEJR1LPwhpqQQAgYS47NKa1jvdn2MPV1yiewHleU8x3Xm2A6HkVIvHlRdarjd1lT19dJTmlGJiT3MszZWCgYh0Svanygc3uy6eyn55q04LbdshMT2Jgg7RRpxANKvirUnLlerqpvNP3tSRaZ5xgHgGZqBDqZQBEJMip2S13U+pudvdKNkwz+51AtzXXp8Rfw15siYAQC2V/OHju5wX73PakhfIyY3KlxTExKQ3xyPnEkYudPXGl5zhn4ODvx7ONTWRpeZzw/0xMUT69QKRBxqt4eDF83Jw8PLKm5rJUvMs8HgeHjxehcfFSg+5+IxEuBvbBXdiWD9Vjjqal4lFQBiBRUJpAUBrLRfDq+Tz8/P6TzNcyZ/uATOjxx0m9vZ2lESOe6KUHt3DbasYDqOwHZDh3D5gLN8sdl6uGDTG6Ib32LiMIGDkqzDZBxRFkTB+0DfJjQXB33TMWP2VVQiTh2neZnG8NmAu2Ik0wSWX6YMJaXMz+14nUTAxA01DJncnANZC7L7+8dkeBmBSWx0Gxr1vkRhgE0Ehmu7lC0UBu8IEuWORk1x1APv0BbiisLOuBDBVoR4K3xwIEmDKxNcpbpL4x/v0v+nUb5YsWJXtLUecAAAAAElFTkSuQmCC" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">KU Thể Thao</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="0">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div class="DefaultLayout_Darkened2__+D8Af"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="KU CASINO"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAtCAMAAAAQuiwzAAABEVBMVEUAAAA5n9g5n9g5n9j/pxr/pxr/pxr/pxo5n9j/pxo5n9g5n9g5n9g5n9g5n9j/pxo5n9g5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9g5n9j/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9j/pxr/pxr/pxr/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxo5n9g5n9g5n9j/pxr/pxr/pxr/pxr/pxo5n9j/pxqnntYWAAAAWXRSTlMAUCP9hvr2FwsFDqKcWWRPBPc/PBAHh0MI8/KAMSQZDdi/rZdqFOfk1MnDkpGNinpXE+3htrSup2hhOZ9/cVJMSUcsKR0L7efez4lzbTjXx7eWeGAaultNHyQiKA0AAANoSURBVFjDjdbXWupAFAXgFYoUUVFKEFBRBGyASMcGtmPvDd7/QU6iQGYNyeC6UpLvZ7OTmdlArhQvHfc0rXdcisfjqTCEnKWMT+Y07XQuZVwsxR9gZK17sjDOiQ5K9NZj5fYIcPXFHPghpNGnzAZh5Dw/ELLDfHogJqnkNxcndJOvisIh8/t/5yP/7HSkZ0ShqeIzMn8ds/SCrY4lErIq/kPmG2En3Q87fuZexddlvhZW6NP5QJn4XZlfj9n3PQYHvsX8LvEemZ/9rf5B0sXV0KV3Q2e+SHwZiBCUghmt4KzjXgSu0ip+H5ib5Df7lBDpKBPfUTXnRObjpu5mPQbKnQjkfXTt8oP4tMS736bqzFdBWXsi3ifzPXknCPkBqb0qfkfNa3Y6C00R2FLxmQqwSXxjmo7ohihsSBe3xItPUcT2+hS1ztVP8hUvbdbEK3RF9Qo+myDeQedcZBS878+8ey+I6fwhKB3ijwKIvTjoxwBckfAEv5IUAG8ZlAV50QbX7fV5AOHa4qqs82nqvQNFp+rbBr/trIeM3WwKfwRKi6pfcuAXTR0h8685me/Qdr8Pyi3xK8yz/vtQrnPgtGm774BSZt6298s/+uvwvxcofv/MEu9HTZnPFez14/Fo0mP+XsXvyPyqW6Wb2ab3P5FV8Im8A899531ujw6MQwWvzzjwXPvDgfSNVqLPxOvE81GYeR/xrCPHz/vxzBJ8W/Tee0T9m3tz4wM0gl6Hm8Ap/6aa3+JvqPpii4qnNNcMiJzxIgr1KSWrOXUaFD6rJ5ejp9JKMu8JABrzwnRMebN/c5Ldw0FTT79HKyt6fSCla60emUeK+YOI/apN62aLnjbq1YGc6jeAkgOf22b/0YXfnHvF3ncrOwOHtLlK5jHvZn97dTSI8Y655KDfXMAIH1YarIT6nPWhn+YJPnDLLC+4GhFnAh+z2sMzfpmHwMqzjZ7/wk94Abkg5Oxa8hs5mEkU+TzxTbY/0xkaNSeefe7PZ54msbUs40mPb0QUFDxcs27JH76f70WvOCsEdKFBV57zwFhYVvEIajW+oTBcX4mVVt0rDAuXnbuNLSM32f2LBKDgOUHXaarxaN212HgYTYPn7ezPzLP7W2zUZyYByqkmxnYuC/tzqzlXb3RPJGgdH9EL/atdXIBT/gP2U0j1J1W0LwAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">KU CASINO</span>
                        </div>
                        <div class="DefaultLayout_icon_jackpot__T+cef"></div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="3">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div class="DefaultLayout_Darkened2__+D8Af"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="KU XỔ SỐ"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAtCAMAAAAQuiwzAAABEVBMVEUAAAA5n9g5n9g5n9j/pxr/pxr/pxr/pxo5n9j/pxo5n9g5n9g5n9g5n9g5n9j/pxo5n9g5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9g5n9j/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9j/pxr/pxr/pxr/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxo5n9g5n9g5n9j/pxr/pxr/pxr/pxr/pxo5n9j/pxqnntYWAAAAWXRSTlMAUCP9hvr2FwsFDqKcWWRPBPc/PBAHh0MI8/KAMSQZDdi/rZdqFOfk1MnDkpGNinpXE+3htrSup2hhOZ9/cVJMSUcsKR0L7efez4lzbTjXx7eWeGAaultNHyQiKA0AAANoSURBVFjDjdbXWupAFAXgFYoUUVFKEFBRBGyASMcGtmPvDd7/QU6iQGYNyeC6UpLvZ7OTmdlArhQvHfc0rXdcisfjqTCEnKWMT+Y07XQuZVwsxR9gZK17sjDOiQ5K9NZj5fYIcPXFHPghpNGnzAZh5Dw/ELLDfHogJqnkNxcndJOvisIh8/t/5yP/7HSkZ0ShqeIzMn8ds/SCrY4lErIq/kPmG2En3Q87fuZexddlvhZW6NP5QJn4XZlfj9n3PQYHvsX8LvEemZ/9rf5B0sXV0KV3Q2e+SHwZiBCUghmt4KzjXgSu0ip+H5ib5Df7lBDpKBPfUTXnRObjpu5mPQbKnQjkfXTt8oP4tMS736bqzFdBWXsi3ifzPXknCPkBqb0qfkfNa3Y6C00R2FLxmQqwSXxjmo7ohihsSBe3xItPUcT2+hS1ztVP8hUvbdbEK3RF9Qo+myDeQedcZBS878+8ey+I6fwhKB3ijwKIvTjoxwBckfAEv5IUAG8ZlAV50QbX7fV5AOHa4qqs82nqvQNFp+rbBr/trIeM3WwKfwRKi6pfcuAXTR0h8685me/Qdr8Pyi3xK8yz/vtQrnPgtGm774BSZt6298s/+uvwvxcofv/MEu9HTZnPFez14/Fo0mP+XsXvyPyqW6Wb2ab3P5FV8Im8A899531ujw6MQwWvzzjwXPvDgfSNVqLPxOvE81GYeR/xrCPHz/vxzBJ8W/Tee0T9m3tz4wM0gl6Hm8Ap/6aa3+JvqPpii4qnNNcMiJzxIgr1KSWrOXUaFD6rJ5ejp9JKMu8JABrzwnRMebN/c5Ldw0FTT79HKyt6fSCla60emUeK+YOI/apN62aLnjbq1YGc6jeAkgOf22b/0YXfnHvF3ncrOwOHtLlK5jHvZn97dTSI8Y655KDfXMAIH1YarIT6nPWhn+YJPnDLLC+4GhFnAh+z2sMzfpmHwMqzjZ7/wk94Abkg5Oxa8hs5mEkU+TzxTbY/0xkaNSeefe7PZ54msbUs40mPb0QUFDxcs27JH76f70WvOCsEdKFBV57zwFhYVvEIajW+oTBcX4mVVt0rDAuXnbuNLSM32f2LBKDgOUHXaarxaN212HgYTYPn7ezPzLP7W2zUZyYByqkmxnYuC/tzqzlXb3RPJGgdH9EL/atdXIBT/gP2U0j1J1W0LwAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">KU XỔ SỐ</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="0">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div class="DefaultLayout_Darkened2__+D8Af"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="3D GAMES"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAtCAMAAAAQuiwzAAABEVBMVEUAAAA5n9g5n9g5n9j/pxr/pxr/pxr/pxo5n9j/pxo5n9g5n9g5n9g5n9g5n9j/pxo5n9g5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9g5n9j/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9j/pxr/pxr/pxr/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxo5n9g5n9g5n9j/pxr/pxr/pxr/pxr/pxo5n9j/pxqnntYWAAAAWXRSTlMAUCP9hvr2FwsFDqKcWWRPBPc/PBAHh0MI8/KAMSQZDdi/rZdqFOfk1MnDkpGNinpXE+3htrSup2hhOZ9/cVJMSUcsKR0L7efez4lzbTjXx7eWeGAaultNHyQiKA0AAANoSURBVFjDjdbXWupAFAXgFYoUUVFKEFBRBGyASMcGtmPvDd7/QU6iQGYNyeC6UpLvZ7OTmdlArhQvHfc0rXdcisfjqTCEnKWMT+Y07XQuZVwsxR9gZK17sjDOiQ5K9NZj5fYIcPXFHPghpNGnzAZh5Dw/ELLDfHogJqnkNxcndJOvisIh8/t/5yP/7HSkZ0ShqeIzMn8ds/SCrY4lErIq/kPmG2En3Q87fuZexddlvhZW6NP5QJn4XZlfj9n3PQYHvsX8LvEemZ/9rf5B0sXV0KV3Q2e+SHwZiBCUghmt4KzjXgSu0ip+H5ib5Df7lBDpKBPfUTXnRObjpu5mPQbKnQjkfXTt8oP4tMS736bqzFdBWXsi3ifzPXknCPkBqb0qfkfNa3Y6C00R2FLxmQqwSXxjmo7ohihsSBe3xItPUcT2+hS1ztVP8hUvbdbEK3RF9Qo+myDeQedcZBS878+8ey+I6fwhKB3ijwKIvTjoxwBckfAEv5IUAG8ZlAV50QbX7fV5AOHa4qqs82nqvQNFp+rbBr/trIeM3WwKfwRKi6pfcuAXTR0h8685me/Qdr8Pyi3xK8yz/vtQrnPgtGm774BSZt6298s/+uvwvxcofv/MEu9HTZnPFez14/Fo0mP+XsXvyPyqW6Wb2ab3P5FV8Im8A899531ujw6MQwWvzzjwXPvDgfSNVqLPxOvE81GYeR/xrCPHz/vxzBJ8W/Tee0T9m3tz4wM0gl6Hm8Ap/6aa3+JvqPpii4qnNNcMiJzxIgr1KSWrOXUaFD6rJ5ejp9JKMu8JABrzwnRMebN/c5Ldw0FTT79HKyt6fSCla60emUeK+YOI/apN62aLnjbq1YGc6jeAkgOf22b/0YXfnHvF3ncrOwOHtLlK5jHvZn97dTSI8Y655KDfXMAIH1YarIT6nPWhn+YJPnDLLC+4GhFnAh+z2sMzfpmHwMqzjZ7/wk94Abkg5Oxa8hs5mEkU+TzxTbY/0xkaNSeefe7PZ54msbUs40mPb0QUFDxcs27JH76f70WvOCsEdKFBV57zwFhYVvEIajW+oTBcX4mVVt0rDAuXnbuNLSM32f2LBKDgOUHXaarxaN212HgYTYPn7ezPzLP7W2zUZyYByqkmxnYuC/tzqzlXb3RPJGgdH9EL/atdXIBT/gP2U0j1J1W0LwAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">3D GAMES</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
                <li><span>|</span></li>
                <li>
                  <a class="DefaultLayout_menuA__Eilgx">THỂ THAO</a>
                  <div
                    class="DefaultLayout_menuSubList__mx2Ni"
                    style="">
                    <div class="DefaultLayout_bg_menuShadow__Rjze1"></div>
                    <div
                      class="DefaultLayout_subList__-8hVJ DefaultLayout_subListTwo__P6WWb">
                      <div class="DefaultLayout_subListDiv__5oE8l" id="0">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topSports__Zzktz"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="KU Thể Thao"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAtCAMAAAAQuiwzAAABEVBMVEUAAAA5n9g5n9g5n9j/pxr/pxr/pxr/pxo5n9j/pxo5n9g5n9g5n9g5n9g5n9j/pxo5n9g5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9g5n9j/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9j/pxr/pxr/pxr/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxo5n9g5n9g5n9j/pxr/pxr/pxr/pxr/pxo5n9j/pxqnntYWAAAAWXRSTlMAUCP9hvr2FwsFDqKcWWRPBPc/PBAHh0MI8/KAMSQZDdi/rZdqFOfk1MnDkpGNinpXE+3htrSup2hhOZ9/cVJMSUcsKR0L7efez4lzbTjXx7eWeGAaultNHyQiKA0AAANoSURBVFjDjdbXWupAFAXgFYoUUVFKEFBRBGyASMcGtmPvDd7/QU6iQGYNyeC6UpLvZ7OTmdlArhQvHfc0rXdcisfjqTCEnKWMT+Y07XQuZVwsxR9gZK17sjDOiQ5K9NZj5fYIcPXFHPghpNGnzAZh5Dw/ELLDfHogJqnkNxcndJOvisIh8/t/5yP/7HSkZ0ShqeIzMn8ds/SCrY4lErIq/kPmG2En3Q87fuZexddlvhZW6NP5QJn4XZlfj9n3PQYHvsX8LvEemZ/9rf5B0sXV0KV3Q2e+SHwZiBCUghmt4KzjXgSu0ip+H5ib5Df7lBDpKBPfUTXnRObjpu5mPQbKnQjkfXTt8oP4tMS736bqzFdBWXsi3ifzPXknCPkBqb0qfkfNa3Y6C00R2FLxmQqwSXxjmo7ohihsSBe3xItPUcT2+hS1ztVP8hUvbdbEK3RF9Qo+myDeQedcZBS878+8ey+I6fwhKB3ijwKIvTjoxwBckfAEv5IUAG8ZlAV50QbX7fV5AOHa4qqs82nqvQNFp+rbBr/trIeM3WwKfwRKi6pfcuAXTR0h8685me/Qdr8Pyi3xK8yz/vtQrnPgtGm774BSZt6298s/+uvwvxcofv/MEu9HTZnPFez14/Fo0mP+XsXvyPyqW6Wb2ab3P5FV8Im8A899531ujw6MQwWvzzjwXPvDgfSNVqLPxOvE81GYeR/xrCPHz/vxzBJ8W/Tee0T9m3tz4wM0gl6Hm8Ap/6aa3+JvqPpii4qnNNcMiJzxIgr1KSWrOXUaFD6rJ5ejp9JKMu8JABrzwnRMebN/c5Ldw0FTT79HKyt6fSCla60emUeK+YOI/apN62aLnjbq1YGc6jeAkgOf22b/0YXfnHvF3ncrOwOHtLlK5jHvZn97dTSI8Y655KDfXMAIH1YarIT6nPWhn+YJPnDLLC+4GhFnAh+z2sMzfpmHwMqzjZ7/wk94Abkg5Oxa8hs5mEkU+TzxTbY/0xkaNSeefe7PZ54msbUs40mPb0QUFDxcs27JH76f70WvOCsEdKFBV57zwFhYVvEIajW+oTBcX4mVVt0rDAuXnbuNLSM32f2LBKDgOUHXaarxaN212HgYTYPn7ezPzLP7W2zUZyYByqkmxnYuC/tzqzlXb3RPJGgdH9EL/atdXIBT/gP2U0j1J1W0LwAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">KU Thể Thao</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="79">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topSports__Zzktz"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="BBIN"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAkCAYAAAAAa43JAAAUm0lEQVRogaWbe5Bkd3XfP+f8fvfe7p7umd2Z3ZWEFmkFZUAgBJICxmWrsPBKUQoJ2yQusFSkjG0g4lUVgxNRwZU4CSJGMTaxkCgkP0LJNmDFUFh2IhQFBA6OApYc4VilOAhRWmWlfe9Mz3Tfx++c/HG7Z+e5D/lM3emavr/n93d+5z3y1L6L3UWOZVX5++p88OjCbkJqWEsuQmwaOuMVRJQVUWJTk8eAmaMaOH78GNrrceFLX0p59DDLx5cQFRDhNHRvUL1ZhQON2cfM5TMxhg1NBEiIJ9QCiKNrxkwODoxGI0ZVxdz8HE2T0LyD2ZiqKVE97RpwnIx4eUb+ZUQu8fbrB2OMbzWX4cbWWQgcK8ccPnkSHDwERKBJShFHJDdGdYEGMITy5EmabhfZtQtSAiACqPt8yvIPVKoLsalvNlXEfd10oa7bHepp9zCBSlBV7PT7BRhbO89eg7sQHyPye5tHk3buF0BeCea057fVe3dUNdciv8dFLvHJvkW4dqUsf7Ux/9Ba3gkiLJlxtBwTRWncXtC6ItBMPsma5ibT6nOjbu8BNUPcSTGidU2sKjzoduvftJkYI5UbKSVke65PjmMOhmP4p7yqviJwbBUrEVZWhvR7HYJG/JxOwAiqeN4jnWbhDi/G05XJ7NQBOajodXmYfuVICCQ3FscliCAvlBuAuHY9LkKsm3d20/ABmfydpYS7YyLrrvgZyR2yjIShtjVX+OSXAObQ4LO52Q3R+dz0vYjQVBXeKc7qtq0ngSAsrAwxd3yb9ZvI0ZVOcRzYdQpLB+QZVHF3QohQVRxbXqEW0HjOi1lHce0fLoIYl8+qRlVtUozMHj3KYjJOzvXJ7RxO2AzPMhKOLy9DWC+7BTDA3JHJNpNDJXJ1EvmcAwmnGyJZlr3gDSaBuiq56OTi9m1UT3x338W3qdkns5TwiWjzIB93EbIQGCGUJ07gDtrr8oJl34Q2H5syV7vvqM2ozKgAV0VewDziDnmHJIrZRKSse5zGnXrymXAqt8HYE8vWUFmiHwL4uQmYtRTNODA7y5Nzc9u2CarsWV7+jbwqf6sRwXFc5O0k+2bWNNTjEYdPHKNqEiH83Th9dV1bfJfqpnEHakt0LYGs51bn7M7bzdBOh1TkNCsryBqLRWg5vF7leMHaLeOTQ9mdZ0T5u0jSlrpNw3P9PsGdPYubOd+ahoXnD1HM9j/4g127NK+rp9XDF1SF0oznTy5SBaEfwua1vMDFbQU8qII7TUoEb6/8ZPw97lwYhFxFnFYxHwAOmdmWilfMCJ0u9WgEZkxVlUw6nwK+ncEdL91YKDosxEhyx8yYWBs7gZew3kYx4P+6+6Jto0sAem4cjJHvsfmaJ6ALnNfpknvzfomCW6SsS4ZNg+GIBLAG1AE6OC9BmBOVgcNx4CTwfcHrs2GVTcC7iGR1TSMJ9cBKp7jUkH+Yue8XuBTYU7jRKh0QkUPu/vhgZuaBWvWPVfUpWWM3mzsxy9BOh3JluVVSTK1zp+GUjGdyEAHYESM14G7FYKb/9hjjjSL+epAXr12vCLj701meP9KL4X53/zzQbPIfDDKgE7fkNZEQ9ixmsStl87TkBUWvS3lihE5Wp2aausXbROQtAlcCL/MQ0NA6Eu4kUX+y8fgXjfn9Iv7lbW3YrYBPIVSDpaWjVbDddXf245XKz4rTC9vL2T3g+4tud39M6VeWDz1/r1Xlr6rqoVOn6WTdHuPRmMYcEWk5fp2oaU9jxZJcFHNmgBL/oLi/r9fpvMzd8UnbtaRt330xxn1BwtvqJn3EkTuwdNdaOeBmhCxjZteu1fnXkKPyKfCfTs5DnuyjGuRRAcyMbl68NwS9hRAvS+6IrcHi1BRBxF/ZEF/p8AtB7S+T8xsIv49vRm6Tpoh1M16amflA2Rk8lov8gpr35CyUm5mhqrPl0vC9ddU8hvBTiGCqmBlZlhE7HaqUSLQeXQIqd2paBTtKRlA5OF/ks2b2oLp/SkRetkbUbE/uWOspvdLd7mzK0Z9YY7s2+hDtAQu+8XEGDrmK/INg6RvV0vACc49B+EonLz4dQrwMM7YCcS0JjojjyFUi3CvKf0Skt7HXFiraX4HIfxDRC8+42U17dzRGNIQXNfiXQl39cnc0AlpB3On1IASSOy6tqKndaCZWzVJqGGj4sV4I/z0J+89p8unGJzgnlxvqRv6SVjy279pFkuzUnGuecfJW3tfuM9V49Kfi/oio3mju2DlicQoU/nE+030k5vkFLgIxQoxbKFeZSuiNE636kocdDklr412AyMJ2CISUPhFTIoVwuwFFnlN0CxaHQzqaUeOUgLozNmM+i1xSdP6ebeMviDM19Q4KLAMdcd+7jqcnXSeW0kWV8ZA5rxPh2VXV6w6yXhE7grtgtNwYRK7AN6OwxrEtHX7gMHJnthK5OLrrWn3VTuVIFi/LnYeq4fANVlWLYnZ2vqBDMtG7cfbjXAFyBcaVBq8V53qcz08AWd9PFVP5RG9l5UNZXVOrMtOdQYK2dvuE+4YpMRsCr+n16apSbyXY3L9Xq3y0CuF1wGtFwhXiXFGFeGUj8s9w/9uN+ItAci5QuE9FqGktqQZaa8mdRoRGFaPldnHIHDYCiAjSNEhVf8vg3e52hYhc4SFeKXDFnqq8Utw/1CBPNBt0iDvgdmlWV5+TxUUYDk8PvLsT3R+yGF/VxOzdavYQ8CxQAzXCAeABnJ+NEq4S90c3Qya48O9Dqj+SLS/TyXJmejNtDAcYmbEQI1f1ZuiIUG6hQB2/DfFXNSIfa0L4juCHgKHAkSaExxJyu+CXOXzC1+qjyViGv8HwW6cH0j6KqRKahNY1CUoBCjbbIq1TU7stzP9i2rPnR72q7nZ4QmAFsAAnF+rmf5nzSUNe3bH0UdYGz6a3UPQn40zv57UotgdeAA/hXg3ZfkWePJ1SSSrM1M2js8vLV6cYv7zxvYsQkt3WKccfJjUMujOEoJRmnfkYeU1vhk4Im0B3kZG7vV2T/wtESoFNUVNZ7SOVG/9c4JYpWFOQJ9z8Kx33PV13ZpqGOs+pegPmTi7SP3KczNnZmXDq6gzS9nXxw+L2oza347fTwgLSpPX7A2oRyhA4r67T6xaXPjYqOm93DeuUsbsTO53bK5HelsA7oGbf6heddzQqeEpbNdsAQELNVzTEnwb5ylbgm8rt+XDpwwN38v6ATozLl3d7dIBR2rSZhxO8AfjC2YTmplKuSvaZZPzLqUs25X+DnsO7xSGqEkSxlEiDOWxh14c76HUbrTdrYzbPZsGvJot/QV0jdX3aHIMCMRnj5eUvNE3zftmQCzCzeRXesSXwAk0oincGVYoQiHl+RnPSac0yHFz1Jx3/b1uODLdTVx/ZI8plVXOrZvnNSzG7w83/2Mzvc/g1c64Bfhx4/AzTbhq+Tglz/rWofHu65olPTCX+M6WImCqu2oZ+o95OHm9HJj7pmj4hpScW3H+kgCftbGIDIkQRCqAeDtGy/HRQedhXsW+98JjnN8VNOYI22fFHmuX/x4AsRhqR1czJ2ZHj6jeIyZ8C16x7owpNc1tP9MSLFxfvOizyB0d37/6D2pxoaSL7TpO52LTX9sBXktGIELMMEcHwf+fYf2pj/bR2PrwK7LXS2GOdpqHjfgfwPszXxfkVWAzKhcvLvzsbi2eW8tje+hghyzbZ8k6bIJkBlkPgqV6PHUy8ZJePA2/cgM6PxE3bFHDn86PRMm32p32fAXYuiSCXEWrXuunXBX5sA1pUZnd+f9++auHo0d9+xZNPcnhhgWF/QJ1FNNXEs7CbVRUVYTklklnrkYq0Jpz7g7QJlfkprAbBlb3u8tigru914eZ6Ioen+xegxLHkPNftFs+LkFJ7o1lcJISAx7gO/EKEuqp4vKoogToEBkA1HtMrefDiXvdpR/ZND1cgW7Xj12xzFGP4G9mQ6xGAEDGU1CQ2nrmHgIVAL8sQTyzVDSIk1N6E6X8B3rSmOSpCLXLPiX4/C2af2X30KHNLSwz7A8adgqpTUIeAmUJyAg2mCtpGT1Rg1CQWx+PWcYN14WOBJYRHDfZPFW3tRoG+OsvyNyf8ZqdVzmv6MMYZAQFIIQTHUQfJMjh+vFW23QJJDbijKjQiHAiBOiUyIJt45wAuYu48Br5vLWKRzZLmsKBHJpnOTRQEXAw71R4XJa4skZUl3zl+DMXZ1y2oWpOqdrUbxHST2MmrijrL7npm797m4qefvqe7ssL8saOAUBY5w34f9TYsfWLQpxiXlFkEVZIZBw4epG4aouqWN7GY3/m/ybP9nlpPNSLMavw3qOhE/qxrXzqMaUXN1Ms9BYy3ogZa5RqyNjVqxrGqInU6XL4hhD1N9lRm/0/WyHmfAG+0BzxtHMqyDJPQ4+bdtMlhXBV3IwGugXxpiW5Z8vjKCl50eMWOi6hWhi1rioxc/VpMvibO1atDiaBmZMPh3c+df74MhsO7dx06BDhFWVKUJQAWAs/N7eD8xWNYkTOa6aPudIqCIs+JsrVVXItkjRsNbWXCfMzIRLXZGHtypxSWS2EmnKVuQVpRNxqNcTMyVUbbiMfpeax9q7Sx5LV0nopcQIw0eU6T51iMLReIICpYG4td18lDgImo6YXQRh2n7mB775Jj1+L8140L0xakzy53Orcszc2RNoRuUwgo3ooab71ORNixcyfdQR/rd5DZGeh3kUEXBl100EVUX1MnI4iwKyvIdBInmkLgLejk2QeSyhd1spazfaZi6jTJ/LVbXPUrJl/4gQ2NoqlelVUV8ydPMn/yJDOjESlGREF0axG0kWT1F6vgi0vp7m9xWG9qipDVNY3qnc/s3fuucadzmoFPzZ/HyKDTAVVGdUmWReoYMIEKdo/dXp2LsisWRBHSxlIMM9zslkb0DpAQfFpMci4/50ZT1ldxvrvxZRXDTd3lZXYfOcLuI0dYOHaccR5pY+JnHriV+2uWNBF2gqJuI6nr68z94Y2AqjvF0tJnD+/e/a4j5513asxtOCqZEUTZQSSOGg6vlBTDMTEpuP5Mrjq7kBcEFRqfWvMTr9YNKfKf117vM1VZgvmsqKDC2T+6RUxnG1Dc1wXY0CzL/2xjyiyaXVd3O28c9vssDgYszs4Sm7Mr3GkmCiea/TDIvwX+M/BtVB40tztI6doYYwKuBx7c2F+BKoTPDjudf7I8GGAhEE7jQ/hUdATlr44dI504wbKlTozhlxeygiCnQMcFt4S7J0Fu1Jn+79LrIQ4B7FxFzTmVu6yzEp1YNs39onoMmJ9+naVE2encfWDHjitXur1hdzQmG62cdlh1h5T44T2750zDr43H4/cg0lYnTGPkTbN//pJLvj648EIO/PVfj1eWln4qFMX9WUrXqFnL2SJkVUUSuesHF13UvOSpp+7pTGL629GU6yqgiJF+t/tJEfYJ0uqD6Y4tUfX6S/2m/kcvPnjwq4fznAOqiBsq4Wxk9bo5z9bJ23gnHNC6qlcw+811L0QA/6F8PL5/Znk4CJZaxbYNxdRwZG6OA3t2X7yn2/na+Z3iPdVaTQKkuqZTFG/duXfvfbHfpz8eM7e8vDK3tHR9SOmxtGbTPpHjxfLy3Yd37rzl2Re9qA2GbSPn2nScceHMDDY//0+7Md7iEyV8SpEaNfb8rDfXLlTVV7tVRRwOSU0i00CgLdg61+dcoF/rH2u5skJTlr8ehKfWNxUE3tgZjx8JTf1m8G0PWMwYdYqfWx4M/mdpfkXZTF1/WuGWEmFm5m0hy77kTQN1za4jR7jw+HHOP3SoWllcvJ5u99sb5aWaMep07hz2ene4+x5132RNMakQ62TZ3mvOO+93ur3eJ0fNhqJbQCT8rfc611zw7DOPLBw8CMDQjQxrjQZ5IYq1Bf5Mz/Rj7cqjLizQhLBSWvPOWFUPs4GzTfVSTel+wf/EVb4ozl8Bh2lt//PBX+8qN0W4euJbb+xPJvKOUBRf9KY5lbCezFMDMcsO7RiPbzg4Hn+11+u9RsxWFXRMCVJ6n8FblwaDP0zuD6j7AUROAvPJfV+WZdfmeX5T2TQLGwNdbo5b810NxZtjlj2TQgASi0XBsUGfzBqmEcQtioo3li6vkjBJtLTJltNKHVmTYp3yfJRelyQCI/tGZvYuVO/edKFFEORGcW6cTHAICMIk7beFBHDA6pqi339byLIvWl1vK0OLEBgtLh7SGK/ph/DwkvurN1UrwwVlUfySuP+Stsng44jMT8XSagJk2k8UK0c0yf5H2Lnjesr6JJNCXIDn5uZQAsFX4yebjEN3K08DZmusNYkm1RPVvBUOThR5TteUMBoQSQmZlGW7yz3uZILfedq6dmfP9i/bzSuUsd9/R8yyPzpzSBmaPGdnSsfLQ4feVC0sfL6An1iXRIC1xa/CGmPgVPh34tC44/WYbDD4Ut4f/NyorhdD3YqfPCWqkHGy1yNvmnVQb5F5+saZ9klREIqcsB1eIpDsz60uV01ZfGNdTRt9vMuRH6jzW6byEl1rFZwNuZPgO508f29/fv7bS0tLq1x1JkruDMfjI+7+9wV+09zfjzsawunLO1a5fZJwEfGVuv7ERZe+8tbBy1/O39x3H5m3llcS4ejsgMB6OTKNbE7Hq5rmCTqdP5dJVd2mKWkjtvnOnTyfEtl2wKtCVX+te+jg96LZS6cjbV3CJ/JnHuM3tao+JO7vRuSC7ZyYDTGd7we4q86yXzdV85S2XPTpKIRAEkmYfSCo/iFwazK7USYBj81c2RY6tfX1QpbSF8YzM7cdGQwev6jVD6ttY0oc6c+wWPTImmZj7KRQacdDhN5g8J7Q7ztbhEcmGKGqXPXUU7xicfH0Nr1IejqEX3w6hq9NU0pb17O1lsLS3HD4r4bd7qeborgupLTf4CrgRUCBu4jICNUD4v6Imz2IyFdVdelsAD4TpZSYHQy+JTG+5diRI6/P8/xaRH4c9x9y93lE2iidyBHwJ/MQv76s4cG5Y8ce1TwnFUV7E1Y9VgeUxd4s4pv/qUDABKEx+04sso++/PLLv0mWbZ8AmoSoeeIJdtf1GfdzAr5ezs1cm6O34v4T/x90tv9uXZoOKgAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">BBIN</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="174">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topSports__Zzktz"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="SABA"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFYAAAAcCAYAAAD7lUj9AAAPOElEQVRogc2aebDkVXXHP+fe+1u6++1vNqYYUEfQYaKSOCxuDCCbg1QZQxYsY6KIJCIaTYnBxJQGtzIYJSkti6FMKalULIkYISxSCggDiERAgQg4MMzA4Kxv6dfLb7n35I9f95t+PegfcZzyVHVVL79zz7nfe+4533tuy+nv3kxfRCAEpZsVDIoqFKVHRBDAGMFaQXXJY4hAWQZKrxizVF9VUYUksdSTmP1z7bcZIxcC9wJ/V+lX4wJ4r+iQAWOkNxY4KzhnUK3s+qAUZaDbLVh79HJete5IullBGkc8+sRz7JlpsmJ6jPPf9GryomRmrkO7ndHNC7p5CQql9xgRECGOLHFkWTE9hjHCXQ/8nCwrsNYs+tLNCuabXYyRAQwEI4LhMIoxQlmGsxc62cMico2I/AD46uH04XCJO4y2BPiU93p56cOD1shLgZ0Dvx8FvFhVVwIKLABPAj8/jD4eMjlcwDaA61X1TBH+1Yh5F9Df6n8AvBfYoKpj3rOYYkRoAVuA24ArD5Ovh0QOSypQ1f8AzhSRa4F39b5eC3wbuA44FfgW8BXgemvltLGRdJ215mzgYeBi4D5VTjkc/h4K+Y1ErIgsFkLgKuDNwFZVvbj3yAZV/S4wKSJXq+qPgDOBl1MBfIe1pkoeVcReBlymqm8zRu4Hur8Jvw+lHHJglapKW2MoS382hPdX1d5cEoJ2QtDjVPVOhDrwflW1Ap8Q4SaQPwbdjnIQIwA+VxVsiUH7oP/Wihv0X6TKb71IWxRV8CEs0i0wi88OSj9KfQg4Ky+xls+HIKjqPaC3ioDA18RQD4EPG5EY4UpVvUSVL8svAUsB7wMoGKu5hkAUOYLoIt0KQQlBpSi95kVFDQ+lVHRxkAL+6vHdoH1VEMMFSeIu72n2y4im6i7t0aMjVfUaERKFMDiYAFFEoao1Y2RdIrLciNDpFlfmRUmSuHfGNbfBGtlSBt1ujHyDoFctdLIv94BZwn8BSl+ZWDY5Qj2NUZSi9Ks63fxrRiRS0J6jUezD5ZNj9S0vXjNNNsTFf10xRhZfIHgf8D5Mqer6oOQVgBhjxPkQHnQTY7UlA6jqa0GORRZBMwJzIL9o1GNQTm518rN70bdUlyp6Fj8Aeen1+OPWPLVnf5Nmq/vXzlqsMVcg+vGyDOSF//vR0ZRWO2eu2QEUkcrx2fk20+MNjlgxQRxZrDWoKiJycl6UZ2k/I4gQQqDdyX8x1khZNjlCu51h7K9fm31Q4tjx6vVH0WrnOGfpdHMef3oXIH81Od64HNRXbogUpX8sid0Z7shVkwOgQhTZS62RS/sRb63Q6Ra1bTv3d5LIUavFZ46NpkNo0gVuV2WlCL836FhRBqbGG3kSu8Zss7PeiuxQWBFH7uT9s63vPP70rvk4shhjqNdiZufbFEXO9GSDjScey9R4gyR2FKWnD2Sznb1egyI93EKAKDLXGWTrjuf3027no6rUQ9B5Ve0UpSfPS4rSLw2E3tYOQUGZDEFHEARhb1BtD+b5WhpT+kDsHHlesnJ61JU+nC6CY6BWea+3j42m+9z4aH3AUFiTJvEXnTXLVLXdW4XR8ZFw1bKp0W+Oj6RufqF7aujlWwCqXHtHp5tvssYckybRQ6p6YFCQ0nsfx27d6uUTBA03BdWjY+cYG0l/uHJ6FOkfCXu53PvAxFiNVcvG6ebFQTm/0UjO9V7pq4UQNEmie9I4OrdRjz/srD0KkViErhG5u1FPPjhR1mdG6skgqClwXuTs+c7aVwDLFU1BWsCCwJNB9XOqensFWEC1Sk1RZD88MVb7gLV21eCuVVWstReCvtyNNpKec0qSuLPi2L1VByaiCvV6fEXsHEXp1zpnjx3MAUaEovA/HhtJSeLIKpoM2EIQfAjrBIwYA6o/C6rLjBGMSB45y6I1rXJZmkYstDK6WY6xBmOX4Lp+KmmsHcpDIsg/qqpds3oaHw6kflXWnnLisV7hwiRyIFB6PS6K7FfHx+sn9QtyFSeCoiPASlXWquo5RuRPytJ/w1rL+GgNEZGy9GNjI+mUMWIHfZcqP44Fr/vc9NTIogfWmt91zg5RHdmm6L2qSuTMudFgGgCcNd2ZufY14mF8ND03qC6FAWZE5FHgz3qNGK9Kai2EQDJoSwQiZ3nosR2sPXoF0xOjlH7p9jVGThEhGrIRgvL7VqSlcD3o2NDvsyJC5CylD0fFkbkrjmpT/U1nRNp5GV6nQRtRZO+GwcDST/qgNxpjWsEHSh+o1+KPRc6uVrR/2EFEHs0L/xequq8owlZXT+P+pGrAqdVE++EgKHqPqsxXnSV943DBMta0kiQ6xpf+ROfMB4a3LUgTeFpVtxlr8EGLEHRbEjta7Xz1rj1zi12qZZMjPLF9N9+96zHe2kg56fiXsG9mAR90gN7p6dYMh6t8Ly/8DT6ENE1cGPZBRP5dgbIMouhlkbNTfdLTK5TXifCQsfLKyJlhDj3uYAqlJZHFiChQD6qvH+Sbxsi3ROTudidHVQ8k3bzwx/kQ1g80wKoHnL3LGCHLyhUIGw4ir8h05OytkbO0u8VBTEGMWdHtFuNRbP/LWXNN1i3OyvLyasbq+BDe1KgnqYh049jy0M+e5Zkd+0jiiFvvfITnds2y/pgjqKcxeeFx1ozFidtQlsPtRHPnzGwLY80lxtQn/GKUC4r+xBrzcDcryLJyotFILjSGA0TSGDrd/NvWGKLIXtTNi4GAFYBfAHuMEbrtgk63oJZGG5M4OlY19G1gRB7QCmBEBLf1md0AjNTTM6SKygMeK5kYubuWRhSFf21elCuGiXcImgXVYI3UfgkpT8vSn+CcuVWVZ7zXTXHk3t5sdX9a5OUrQN6zZ//cPz+/d54nn96F94HxsRr7Zha4/d7HaaQxa1ZP0mxmRLE9qZbGLxr0UVU1iux/lz4gQU/dN7OwxLgq3wNKVSX4cLwPIeVg+ZKIXEVH1yyZvirO2geTNOoWhWd+vo33SpaVG5OkWOwxi8izzsjtfWCDgrvtrscAZcMrX3zeaCNdpCQhBNIk/sn0RP2R/bNtulnxqjwvlpxoFM2TyP1hmkTbFrrF1VlRnmzkoKqCD3pBp1vcOjaSftIH3WxE3orwUTTcIGKu6GTFbfv2L/yvc5YkdngfcNawbLLBI0/spJ0VTI83WOhmJzVb2fCR70lVHiqDT+PInTBYeEMITIw17hSBnbtmqdeTNxtZGjy9A8Y4Qgw8J1UfQgCjqiaOo1tqWUxelLQ7OdaI6+bFG7RZjRE0kMTRjydGa83FFCSCO/rIZQQNy2fm2+vmFjpLVstac/+e/U0W2llkRM4y9qBo3ZIm0Q2Rs3SzwpelP0CdloQNb59b6Fz21Pbymonx+kciZ78+M9syoyPp5jSNLgpBb6yl0aZWO3t8ELN+I+bRJ54jiR1HrZ7eaAZ2lSAU3v+PKhjhdGvNyiH/npuZ7/zAWcPcQof5VveMwW6/qpLE0ddrtfhje/fN592sHDHGmEo1xHHk/Mrpsadm5lrs2dekDAFn7ZG1ND6hny96vnx/z/5oSdC5PTNNYmc3AlNhOH8qW/LqSuaoyJnXDDlNLY1v2bWvSZYVr62l0esORrS/gGJD0E90s+IvfQh/FDv742Y7+/pzu2bfsWxqxIrIu6w1DxhjPgh8R1V39zSJI9fI89K12llt19651xgzUFwUxMgNvfdn6ZJqDs6ah62VmeZCRhTb9c6YY4bnGIL+p7NmR1A9OgT9AhABHoiF7JH5hc6HQCh7O1mEjfMLnUFWkvnAjZ1OTl6Ui+C6Z3fOUkvdOXFsCUtO/sw36skd3gfyotwQgg6HYqvdyW9otroEZUO96xgqxrMiPKHKiQDGyMXAN7pZcYeIbPI+3ORDWPH8nvlzlk82rp6Zy68UYbOIXIHqkyLSLUtfzDXby43Ih9IkaszMthtDS783BL25t7tOHfyhd/S9LY4szXaGETk7jmxtqOm0a6Gd3S8I9Xr8twLnDY7hvT4Seoykn+LEyLmDz4hwrzFma7uTk+fl4o51UWSS0ocNRXspXwxB7wuqz482anSanXO8P9AxUiBydmtR+p1lGV5mjLyz1cmHcGers/Z8H8J9qroaRIKGbwryOmvNzSGEs6wx12oIO/bPti8ofbgAtAPy56AnGmPqqrrNluaz1soPs8x/oQJrYFLwI8TMqoY1FKxbYl1EY2evn+/mVS8BPb49dKQFbrTG7AJod/I3DEZOUC0nR2tfTJKI2fkOnazAGBmreilLZEqVFcDuKLKGXmPKichLVXX9cEU3hi1F4Wl1MgecVjWvpT8hyjKsBe4yRl4EjL4AI/i2V90hIh8BrgWwYpYBN4egbzEitwGrjDEfLX34SnUAkptE5MuqfH4xj4rgvSLCKSAMmTlehNNALgHi/peqihG2LJtsPNNsdWm1C0R4APjTIS+PAE4C3mJEXg5Viuv1fd9rndmeRA4xQkAxyBTIEX3+C6DwSiM8qMoDIeiFCHuhupp5By/Q8BaRH4YQaLW7bwpBjx4GToSGCK8ARodUF4B/Aj7T0/g3etfbPXmJCFsU3t3Ld582Rn4HeI+I7AaWD9ry3lOW/gxg/QuwuW2q+n2qe7NFUeXZkXr6Pky1KD4EgupXBG4e0t8E3Af8TaWnxJF9yhpzkSCbVSEsFkoAthvDJ6w1TwPPA7sE9gOrrZE4juxc5CyRszhgQYTrVDE9oBNgtwj3gGBFAtV1ScbgWW/pewuUwKMicouqPjQ0gU8Bu6nutAzVYmwGzlfVzcC3RGQL1TXMUjpU8cRNHLif2wU8QAXSl4BLRThPlVGqSd4PbLbW7Ow3lHunydyIbFK4GPRUVaaoLjknehhsL8twx6oV49c2F7rN5sLBtz+qGiLn/iGO3Wdb7WwciESkVno/2WikW8dG08L3+sdywgX/cqB11pP+ndVBJOHg65IlOr2CweA2HtI7EfgMcPqQ+uPAj6iiZzcwQxUky4DjgfdRLd4VVGll+wF7lZ0Q1FEtLiEok+N1GvWY/bNtWu0Ma031Z4oeXRuYbwSUxojmhWf1ygkWWl2aC12mJxvU05i9sy063RwjQhw54tjRameLcyy9Z6yRMjqS0gf2cP6vAKpoeiNwEfBuKqABXtZ7vf0FdJrArcDHgZ/8irHL/6dPh/aqoSeHG9i+bFZlszGyUYSTvNdjRHg1sIpq9z4lIg8DP1XVW0TkmV+1W34b5f8AcgvbC3W0lwgAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">SABA</span>
                        </div>
                        <div class="DefaultLayout_icon_hot__ZNvp9"></div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="104">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topSports__Zzktz"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="CMD"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAE4AAAAjCAYAAAA6wDyZAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFEmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDIgNzkuMTYwOTI0LCAyMDE3LzA3LzEzLTAxOjA2OjM5ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMS0wMS0yOFQxMTozODoxOCswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjEtMDEtMjhUMTE6NDE6MzErMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjEtMDEtMjhUMTE6NDE6MzErMDg6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ZTEyZDJmMDUtNmU2NC0wZjQ4LThlY2UtNmEzZWJkOGQ2NjhjIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOmUxMmQyZjA1LTZlNjQtMGY0OC04ZWNlLTZhM2ViZDhkNjY4YyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOmUxMmQyZjA1LTZlNjQtMGY0OC04ZWNlLTZhM2ViZDhkNjY4YyI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZTEyZDJmMDUtNmU2NC0wZjQ4LThlY2UtNmEzZWJkOGQ2NjhjIiBzdEV2dDp3aGVuPSIyMDIxLTAxLTI4VDExOjM4OjE4KzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pvzk4IgAAAtlSURBVGiB7Vp9cFTVFf/d9/bte/vFhiQllZpKEtBSiYhEzAwV+UgnUAWd1pEBTPGjmZqOivGjTpNOW+qgtqIdRkctU1GHyhQ/sEoTCQUExErFQCEzBAJmwAqEzyWbzW7evo/bP967u3ff7stumM50OsOZefM2755zzzm/e+7HOTeEUorLNHIS/tcG/L/SZeAukS4Dd4l0GbhLpMvAXSJ5nB8IIfyfowGEAXgB8NsvY6IAhgBcBDDI8fC8YQBFAPrtBwC+YX8zHX1Sm+e8S18AINuy4RzyOoAop1fMIc8TBWAASACI2W83vRmUBRxHY/bs2bO0urq6UZblKkqpxjojhEgAREqpGovF9rS1tb20aNGiNgAarCg27d/+jo6OO2fMmPH47t27V82aNet9AKqw5E8NxeMm/Q7UjKfdJhIo1YYOtC2N/W3FFlgDYto6aWnrbgoA51bUFhU/8tGLQmD0naBmjJOXYeinzr9QP5d4/aT4oQ+2QBBGg1I9h29skCg19JN0KLpX+/f+Dwc2tO6CBXyctbsB6AZceOfOnQtramp+n7aLyDxDNBr9ZM2aNc80Nzd3A1ABlC5btuzKSZMmlUQikcTq1atPHD169Ex9ff0H3d3dlTNnznzlz2+tu3D3ksXbqE4UACKIEMp0hyjeytr5AD6HFQkGrCgCAHpuRa0oXXXDFUKgaD4AkiUviMUwNEoT/RSEFAHEh8wZlI2gxzuKBEu/I0+cs9j76I3tsfZnfq0e+vg4rMg33AB0BW7q1Kn3uSnr7Oz8RU1NzTsAjOXLl1c1NDQsKCsrm+Xz+cYTQnyUUmPZsmWnTpw4saGysvJ5URS9AHDLjJu/D+BTqiY1t76FYMl8sXTcC8a5Y0OwBgQA9HMragkAxVe7ZDJAlJzClCYAgBqaAUrjIPC76clFxDfqB8E7fnsNPly+SD245RiAAVgDx5aEFHi5gCPck0WbN2/+SX19/T8AeI4cOdJUVVX1sD110x0QInq93isrKioejkQik0Kh0PUAoGlaEoBn2CggQmlw3pM3969takd6pNmUDXjKrp6ZF4FctpvGGWpoZ0AECYAJQhQiShVZgqJUFbyt9SX14JZF4AaOswGAe8RRSmnS+bGzs7Olvr5+DwCxt7f3wYqKip/l86CoqGg296cBQHLjZSSOvvJGAFthrZNsylIhWFoiBIrn5pNHDuCM88dejqxe8g6ngyhTf1QuT5xzpzBqzP0ZwpJvWrjhlXn9a5s+RHpD05BeG3MeR3JGWyQS6aipqWkHIG/cuPGGQkBzobzACf6iObYNss0vAvAH5z4xFYL4zQJ05AhpIgIIAigDUGJEvi4a3LLqwoUXF6zSTx583MntGXttEwDFfpgNKWwKOsdRShMNDQ2tAIKyLEfr6up+WYicC+WIcqqCX3xF6dujFj5fC+sYxIz2iWOqpjgEWTQ6KRs4wVpnOTkWzfLF1+/bRBPRTRkdeLzXhhb8ahIAv22DBxxeBQHX19f317a2NhOA2dHRMVtRlAmFyLlQFnBmvL/D7O97JYPpiolzbfuY0X4hWFqXFjJOGxdPvgpQE4URWy81WEedQVhntxgAaF/te8spIJaMq4Q1eDLSwLlGXMZoUUqN9evXr4UVsoMTJ06cnUNmJJSlkxAi6H2HP8v4poRuhOWoBEAJ3toymUjKdSm71MFO7dgXfwdI3qnPuoS1wKuwDroMuCiAWGzzH/aCmhccNpTBAowNHpuu+SMukUh0Nzc3H7OV6oqilBVo6HAOZJJH/layZ+dRmMaZFJMoVYV+uGKybbAsjaup40WMiyd2CP7RIWdXeYgdzFVYUReHBeCgGe1LUj15PMNQSSmz7eWnKgFA8gIXi8UO28waAEoIGS7bKISygSOCb+hAW8xM9G/jP0vlk2+3+T2CL3wd3xbb9FwHBLHQaGPEUiwdQBIWgCwCDZjGYKZdqeBioA07VTNI07SYrVBH+kz13yYCAMkju/7CfxR84e8BgGfsd/1E9tey79TQjuonD2pECQVHoIM/E7KHbRIacvmVLo+L9lM4cNTK9Rhwpmmarqf+fGQYRq4dMKUq1vZ0D0zjdOqLKJV7K2v9gVlNN/FrmTlw9iMAMhGlwAjUOyOdT+ZNAAJEKWMZourg13AcQ1DoVBVFUUI6xKmqqudHYCwAIB6P7zMM47yiKEG4RCwRJR2AbA4NZGwSgXk/v9dTdvV8zh1D3b9xA/JXPkZCHv+MxkriycwkqBq7gEzAU7/zAidJUhhciHd1dW0eiUXxeHx/IBC4R9O0c7Isj0bucxcgSgSAoh3vzJiuYtHYB4kvfFvKGV07FN/1+hmMHLTh+MPK5FvvAjLXb/1s75ewBiirj7zAjRo16npOyKyrq9s2MDDwz0IsjUajnwQCgXumTZtGFEW5RlXVi3DJgW0SBza0HqB68rAbgxk7tx3WuWpkwFHTbZko8d/y02ohNObuDHY9eTDW9vRRWBjx1REKgOYFzuv1XrV169bZSDtsNjY2PjQ0NNTjJmOa5uChQ4eeDofDj8iynNixY8fbAKCqKtto3MgAINL4xV0u7VQ90PYerDPliICjmjqIdLagACgmvnBl+MevLvRPX/oeiJBRSdH7Dv+R08MylFSiP9zRItU2ffr0RwF8DCts9fXr1184ffr0wjVr1txfXl5+lyiKJaZpDqqq+mVvb+8Hixcv3tDV1SW1t7dfP2fOnN94vd5yAPB4PGy9dCMTAPRT3du9jsTbcj7xr/gnr51FdvU4L3nGVDWVPLFtAYgg2yZQCJ4QEaWsLIjqye7+Nxu32noSSFdHUsC5RRzhS+iyLE+IRqNvNDc3XwELUHP79u0DlZWVL0uSdEtLS0udx+O5KRAI3FtdXf3+0qVLx0YikefmzZv3GgMNAERRVACYoK7T1QSA6LtPfk4NrTfLoXj/ZwB8nBOFkyiVE6+/lkjKFCL5phDJd0Mu0GAapwe3vtho6+GPK3xpKedUpQBiPT097/IfQ6FQ7cqVK9t7e3sffuqpp6qqq6v948ePFwCYzz777Kl169Zdd/z48QcSicS6xx57bJOjnAQA6Ny7bzsAkchSpl5CvPbmkBpVc+Bsu1Ne7dnZBmv6WFNHEMSsfgAQUaJwVKwLIZqM745/+saSoS/eGYK1jrJDshM416kamzJlytru7u7AhAkTHhBFsRgABEEIVlRUPNTa2trY0tKSpNYBkRBCiCAIzvSHgh1sk8mv9u7du+qO2xfsAyASiTijxSCiBGqndQB0/UTXTrFobBPsXY0m458Nbn7ha1iXMEnk2p0pVamhESFYSrj2YZYGaoLSONWG9utnvny7/83GjwEEYEWbyj1J2y5WSgdx/u8IIYRVJBRYc3y4kWPCwxf2Lee9sKc5rDzRcLSztjisEWb8jLy2QwRWch5HOh1iJCB9I5dEYRsIy0V9sHw1bVk+l43b39iFFc0VcezMZthCgAUiq2fx856NAMvjWE7HpyjsbXIyLOL4igMzWLPfSQ4sv81rcE6xqBNs+3w2D6vSsmksIZ2kM39Ta5XDbxVWZLH8NWHr4n0ddqqyKcNqVwwwdqZhzhvc3wL3doJGOH6WZDPnGHAsSviR5S9JWKbAbEra7alSj6MvFtEa0sVQNrBZ5zLOPmYDuyxiA5T3zoF1xDphQPIVUB4456Uwiz6R+836dQLOVxx4nYaDX+P6YQOqc32wweD7YnaJjidXzsoDpzme1J0HL+R6WYN01DEHGBBOZfzosWRYcLyBzKoEk+HbGQ9/HceMZsDxDrJ+2Eagc/p5m/jBcepz+sv6ZhvBiO9VnaCYnGInH/8mLu9cfbJ2Nx5GDEySh2e4yovzyjN1W+Wi2znA2R3m2FWdCnO9L5UK2eVy8biVhNza88kPp9sZDDnpP0I1sNUZpNQKAAAAAElFTkSuQmCC" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">CMD</span>
                        </div>
                        <div class="DefaultLayout_icon_new__k+IaO"></div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="151">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topSports__Zzktz"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="UG"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAAlCAMAAADyQNAxAAABZVBMVEUAAAAfIyYfIyUfIyX8/Pv///8fIyYfIyUUGBoAAAAAAgUaHyQWGhsUGBqcnp/Y2NnMzs3ExcUYHB4DDB8LDxIDCAqvsbGdn58fIyYfIyUfIyX///8AAAAhJSYiJigbICQZHR8gJCUaHyLqyFYAABsLDg8ICw0FCAkQFyEWGhwTFhj8/Pvw8PBRVVYWHCMJESAPExUNERPh4eFucXL/62H/4F09QUMrLzEmKSoCBAbm5+bU1dTOz864ubmkpqahoqOanJ2Rk5OMj49pbG3/72L62FvryleMfD8GDh8BCR3T09O2t7exsrOFiIiEhoZwc3T//2f/+mZeYWJYXF7y0VnryVfvyVZKTk9DR0mumEh4ajpsYDdmXTb4+Pf19fXy8/Lr6+vQ0dHJysq+wMC9vr6mqKiHiop9gIF2eXpjZmj/8WL31FrgwFTewFTbvVPQs1DBpkyij0U2OjxRTDFEQS42NisGDR7Qtga2AAAAGnRSTlMA3u7m7e/g/uDq39767uvo6Ofm3t7e3dXPyDklXNwAAAIHSURBVDjLrZLnQ9pAGMZTWwtq9y733F0SskWGggwrSxSoto5Wa9XuvXf//gbuwpLmk8+nH29+eUmei3KSuX1qJDNXZ0ZHt5RIbDhcP6DJ2EiU08O/qfFr68igw8OJEUtzUt+2vyQdLdSixkFjr9E0aJilpXg8F199WGjREIv//ZGNr8Wzj1M8xHLYp1x8bXc19ycVtqvdzO52drX+v4uquuN87jwXTakqHW9psUyGGoeNvY9NI+Z5ujbWYqjVwNvft746SVTLYOMsarqEuGb79/aRYaqEFGw2xoqgQkgFPHlIkygTsg5+3KJYJH4WEWlxgY/Ajlk6XhM/d6DG1OILidqIxfCAdLMDhvcCF8CGLS1tlcSlkpXGPYHPPJMOWcy/IvMWbmZeYBWRQYtajPTCLMxJzBfZ4C6U+9Yb6HglcBl632Li1YPsF+38rMA5sJ6l4u6gtQQdNYHztqdJi2FFzGblhhWk1acC34EJS0ubCVmQ7CyR8bAp8Ilr0q5FUReT5zZkBXWoWBJYQaRjUbtAgj/qVVCwsC/xZ5H5FscyIfLcONaDCjg2BL6E6lvifvENUDtPggqsAD9gQrkStLCB7vdT7bdRD9o4r0wtyBaoRf1Tz3jyfTfhmiWB96eUcwmJoOLY5V0JN40duYApNyfP+Jm8eC16tpvo9UticmE6On1Z4A3lBPMPRfSUjcgSndAAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">UG</span>
                        </div>
                        <div class="DefaultLayout_icon_new__k+IaO"></div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="47">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topSports__Zzktz"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="BTI"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC0AAAA1CAMAAADiQZJeAAAAZlBMVEUAAADfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgHfmgFvY8+4AAAAIXRSTlMA+/n01LLCJ4bbPO7myqCOYFBIH5YK4akZc2szELt86lcmbBuwAAACBklEQVRIx5VW2baiMBDsLBB2ZFdZtP7/J0dCLpNzTZhMvVmWlbYr3UBXuPGRglECcYCsm+80PF8QuF8L26lgyKOWVF0T1ZfabATAp5ZC0AMo3hSGCmCJTQyNX9wAeffr90+vmuP1VZr0iTdwMjj7poTyWv98k2R/SY+5OnOLCjtOt3rFT5CorQDgDihPaTmsYTcGzKkumvmIUCKz6Bg354Wj+EgxwWhfMHBn6iSMi4C0z3SaL4Te5P0CkpOf3eaE4jyHQTRkkKJyqRnoRCLYWQ6wONQpSnssxtFku1m85Qc0ZKGPjCfgLBzsThYy/UlV7oRqgHdf7ADmnrwUYLfvAn0j8QIQ2YRaOVLyQQIQiVVG2z/Jj4QDyDcKRaX1j2B9hA/SOVSuJD6oKBQPvtsP/7OOwbNgeYIPmmB5ywCEu3ccYP8S3aKo7g45A9LrZnOUsSxis3yA90WnBbDtMiYGc4lzr/gu1iZudMMhNJMD3lCl/JQ97RWn5uq2/kzncSBSfFUPUSl5jJ1A6fuHUi8nIH/uB02a83YlZkkyAjhma9J9eXrVEdZqt8ZDR69LaLxP71UcoyyibV+Hk84Kmy9FqZtW0zz1E8P9OI98KHoi9TCdk5oSo1f9ZhlVus7O7MqMKfKizgsgtp4gMrp+3QHAqjJvjomL6RrNVI5xbfZmv1AwlvbXHP8BDi0kMzJHvaEAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">BTI</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="68">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topSports__Zzktz"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="IM Thể Thao"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIEAAAAaCAYAAACQAT/QAAATc0lEQVRoge2aeXRV1bnAf/uce+/JzTxIiEAYw0xQiQLK1Ai1IpLiBFRFi4rPh/hakVaf+qiuFoosUfAtFagitoBU8An6Hg8VRFGCaJGhYchgIJAQMg834733nO/9cfaFGLG1q2vVvrX41jrrJvucvb/529/37a04D92AXsAl/H3QAJwETv2d61yEfxAo/Tt4elrSpPvSk+ek+s1Mw3CHlSEYCpQSDBOUUigFhgGGIQAYpqAMhaEEZUBD0Cl6taDh1eeO1fx3/vUD8pQ6jyx4+iu6LXyZpNvm/IPZvAidQXVQjAfoeVuXpOseyei62KeIdmwHcBUrjgIlGAY4tmAYCgxwHHDtR0Ap15KUwkCI9xoZD2cm/caLMgduLwgWTB5Q8H0weRG+OxhAr/u6pcwzbYm2wwKiEFE4toCAoHDEcB/HNQBxwHEEEYU4IDaII4gbHFAO5pxBCY+kR3svG/C/BabXJ3gthdewUeHW75Xhi/BNMIDEeI+R4TggAo6AY4OrT1ex0uHdub8d5b4TtHEobBtsW4ECv0clLRiWPBJI83gFo62G6P59ibtu+vfK8EX4JhgASrme7YggaGXbCtvWEQFBtNIdx32P6DnnjEG5UcSRc9/0jfP2BhKUx8SuryZ++kOYKWnfI7sX4ULgARBHoTwGEgrRXl+Dxx+FkZyME2zHrq/B8JpYycmIYYChCDc1otqbMePiMGJiEHEQEWxboQwwbAEFHpQP8NgNdXi79yP2+rsBUEr5AB/QIiKOHosB2kTE7kigUsoPICKt+n8DiMZNSjqknTgi0tTpm6CIBP+SACK0RObqsWjABJpEIpvcuXXjgWYRCSmlYjvy0GndWKBdREKdxhUQo9eQDjRYnEu0kA782SLSrJTyAFGd+Bb9vqXD+hbgjayvlIrT8gt0IjFO/wY8AI6tUOEQHr+P3o88SfOxw1Rvfwd/93T6PLOI5qOHOPPKc0R1T4dgM/GjfkDsFaOp2fgywcqzeLt0xXEcDMM1KBswlGDbSgAjVN9Iyl1PYsQnoZSKvuaaa24eOHBg3Ntvv12ulHoHSJ85c+Z1ubm5dUqp/SJyQjPUIycn5zrDMJRS6gOgNDU1ddqUKVO6er1ew+fzGY7jCEBra6utlPoUOJqSkpKTk5OTduzYsUal1Fsi0vYtBtB39OjRVw8ePDheKfWpiPxZKRU9ffr0O5KTk63169eXanpOK6X6pKamXnH33Xf3eu+998qVUnmzZ88et3379kql1F4ROdNh3czZs2ePPXz4cINSalPEEJRSVnR09PUzZszotnnz5nKl1HbAGTly5K0jRoxINgyDUCjkhMNhsSzLNAyDQCAQVkrtzMjIuHzcuHGXWJZlejweBRAOh6WysrJVKbVPRPKUUgkTJkzI6du3b+yGDRvKlFK7Hnjggbtt23aUUrm4pXsTMHjOnDnjlFJq9erVvweYuueygfJxzy7y55k/FhGR+txP5KMUJYdvmSgRKJp/r+zLiJYv+kdJ1RuviIhI04HP5Oi1/SRvZIrkTx4sBZMHSNGUAfLVjf2leGp/eXd8zy3A5SduHU64oRZt+EO++OKLt0REpk2bdi/gBybU1dWdaGhoODVs2LAZQA/97diqqqpjtbW1RcB4IH7evHkPybfABx98sAbol5OTc4+IyN69ezcCg0SECz3AtYFAoFRE5LHHHnsE6AqkPvfccwtFRKqqqvJN08wBYk3TzGloaDgVCoVaJk2adJdlWTm2bYfLy8sPA1d3WDNj6dKlT4qIbN269SWgV4d3g/bs2bNBRGTPnj0bgYFAxs6dO1/7Np5aWlpqgB+++uqrv73Qe9u2wytWrHgKSAUuO3r06HsiIqNHj74D6Ltt27ZVIiLHjh37ALgcyNyxY8drIiKbNm1aAfT06FCB4ziI6XNN2bFRHgu3XHSh37JXBMdWZ9ev5czLz+DvP5iYrGvo+ex6Sub/hFDVGbyplyLioFAIojOOSEl6LqoanR0SCLe1tQXS0tIyd+3a9dTQoUOfUEpJhDbOh0fD5/OZAIcOHXp3+/btn1mW5TVN05g7d+4vs7KyxgE9AoFAuMP6nfGdiwIvvfRSdmxsbHeAefPm/WTJkiWfAn+aP3/+/1x99dVDRo8ePWP37t0/GTNmzIn9+/ffFx8fn7506dInd+zYcbBHjx7929vbG9PS0jJXrVo1RSnVCBQDvebOnfsQQEtLS1uEcaWU1bNnz2FXXXVVjojYWVlZP8rIyHirqKjo/T/84Q/7ampqGmprawNTp06d2q1bt8u2bt36YlNTU1tDQ0MLUBYfHx8NsHPnzrWHDx8+oZRSqamp8bfffvv87OzskcB/AUZki7EsywAqb7jhhjX5+fkZgwYNmvTCCy/c9Pbbb381ceLEnx4/fnzHbbfdth44AzD1k6ED5cNuKXJo5s0iIlL38U75qKslB3+cLSIiwYpyEccWEXGK/32ufJqAHMi6VAJ7PxIRkebDf5Ij49Llz1mJkj95kORPHiBFU85FgiuKb8kkXFcVUWjmvn37NomI5OTk3IO7P44tKys72NLSUiMiUlFRcQQYA4yvrKw8WlVVlQ9MAJJ/8YtfPCwi8vzzz/8K+BFwPTAlEAiU1tfXnwKunTBhwiztbRuAod8SBbIbGxtLT548mbtly5YXRURmzZr1AG40SAd+ePr06S9ERD7//PO3REQ+/PDDtZqOlMGDB8+ora0t1N4YGjhw4HQg87PPPtskIuI4TvjNN99cDvTR+Ibs2bPnDcdxnGeeeeYJTd8bQCbQDxgLTIrIBpiqcY0AhmzduvUlEZHhw4fPBH4ITAJutG07dPTo0Q/0dyPy8vK2iYiMGzfuTtx9fwBw3dmzZ/Mcxwm3tbXVl5WVfanX6A94DdfbXIcUJ+KtStf+7n8Nn+dydNZNAKrP4hfp/uBcWk6VU/ivM2n67COiM7Po89JWzOSuhKorQBnYjiIccvOXcEh1CAQXjAS+6OjoxKKios/WrVv3bGpq6pDS0tIVgNPa2hrQyZQBSGtraxhgzpw5D5SXly+tqKhYVl1d/VxsbGz3xsbGCqDd6/V2TBi/EQmUUj0WLlx4ZVxcXPeVK1e+NW3atO0ATz/99J1AT9zWd8PkyZOfbW5urrjqqqtuLi4u/uTaa6/doD0nHBcXZxqGYe3bt2+TUkq98cYbd86ePXvsqFGjbt29e/f6cDjc5vf7fYBHKWUkJiYOGDVq1E0FBQUfPvroo4cqKyuPjho16qaUlJQMja8MCFmWFQWQlZUVB5zVj62jCjt37ny6sLDwiYMHD/7s5MmTTxiG4WlsbKwHwnw9UQZwgCogkJ2d/WullGlZVsILL7ywDggA1YCtBSSuwnW7GAXiGDhh97UnMZmy9e9Q/Pi/AdB70Yt0u28uzcVnKZg7k6bcD/EPu4Lez2/ETLiEYFXFhWT/l8AwTdOMiYmJmzVr1q5PPvlkfffu3bMKCwt/7fP5osLhcBCwOzKpGYr1er2WaZq+kpKSfStXrtwIVMbHx3sBQqGQrQXRGXrNmzfvnvb29volS5YcB9qKioo+7tOnz5js7OzBGk9xXl5e+Y4dO94CWLZs2ZtaaBVAu23bREVFxX388ceH1qxZs/SKK66YumrVqqWnTp36fMKECX/0er3RupoA6P+73/0u2zRNa8mSJZuBpvXr1//RNE1r9erV2UAXXONq7kRnmVZi0LbdvTk6Ojq5X79+4y+77LIb09PTRxQVFe1euXLlTk1XZ3CARsBetGjRuMjg/Pnz7zVNMxW3inDcSGArHNtBGV5XIz4LEPeQADCjY7BSfZz5/WoKf34vAL0Xv0jPRx4hWF1N4UN3ENj9Pv6hl9Pn5a14L+2JHehckfxFEMdxxOPxWEBo/Pjxr+fm5r6RkZHxg7S0tOEtLS3nLN3v93sAXn/99VXJyckPJicnz0tKSnqwd+/eTy9evPhTIGDoww/TNE0gVSl1rX6ylVJ9Zs2aldmlS5dB27ZtWw/UAGWLFi3aCLBixYoZnI8G9aFQKAxgWZaJawRNnDcs6datW+J99923p7W1tcbr9cZOmTLlOf1ORfZnoHdOTs5PKysrj65du7YYODl//vz9ra2t1VOmTLkLd/sJ8k2DDYpbWZixsbFRADNmzPhlQkLCzYFAoLS9vT0wceLE/1y7du0RXM++EAx59NFHx950000P5ubmbly2bNl/pKamDikoKPilxhtvgNsAUqaPYGWVi7mygnBbiHBTE9g2wcoK8PjwdU3n7KZ1fPXYgwB0veN+8cQnEQ6HKfr5XTR+tB0rYzAxl48l3BxA53YYXi9mXEKEKE9MTEwMQFRUlMn57SDZ7/fH4Xr82TFjxqzdv3//FoC4uLhLcPsKyrIsD0CvXr26AO1aiVW4XnMaCEaMYOzYsTPr6upeCwQCvw8EAusbGhpenz59+qTFixffCzBnzpyduMlc2dq1a0/U1NQUZGZm3nDnnXdeo/GFExMT4wCSkpL8uHW/47LkVZZlJaWlpaUADWvWrHlxx44dr+Xl5VVcf/31KQDR0dFRgGfLli05Pp8vfsOGDW/iemwNUPP++++/aVlWwrZt224BegPemJiYWAC9pUUiieH3+6MARo4c2TUQCDTfc889T/t8vpiSkpJNzz777ATTNCcBHi1DPB6PAfjuv//+8UuWLFnW0tJSPWbMmPULFiz48sCBA+/27dt3TF5e3q+B3h5ttHjjE2g5UcKXP76RYFUFVvd0gtVVHLjlRsL19XhT0hBl4kvrScXmjQQrziDt7Ur54/D4Leymek7+6mfEZI6gvegIRsIlOG1u3ydYV0fbV8eJGpgJ0Jifn/9VcnLyofLy8lat9JqioqK9dXV11UAtUAqYV1555eqDBw96tSACQKikpCRQXl5+qKCgoFwrvhrdNAHaAE9paWlrWVnZl5Zlxfp8Pr8OpbbjOMFhw4alKKWM995775WampqIZ4eAyuXLl7/y0EMP3T1+/Phe69atiwcCBQUFpUOHDj104sSJBm10AE5dXV2ouLh4T35+/mmgbt68eTtxw2tJfX199/Ly8kNHjhw5BVjp6endSkpK9j788MO5uEfszUDx/fffv3PUqFFj09LS0nAT5IaCgoL8mJiYpLq6uhDnI0NrYWFhWWZm5qGSkpJGoHTz5s2ycOHCJxcsWPBATk7OxOXLlx8rLS0NFBYWHvP7/XFnzpxpAy6ZNm3a8JqamsLHH398hZZh84gRI14sLCyM69q1a18gQQFTd/Uf+I4yDJRjE6qrwYz240lIACdEqL4Oj9/CGx+PwnZPF8XGbqzF8HnxJiShcDBMA6e9GWltwpuYiOHzcayx9Z3pX5Q8tX+AdSDphlvp/exaDI83FjcjTtCeexzojpuphoGj2hDigb64+2VQf1cFDMK9+1AFHJVOjSCllIlbf/fq4ElOh98qIFnjyteeKUAiMBSI7UCXDxiCe8fiDHBc3E6hAjI0jhrcJkyky1gH9MDdUqqBcqCPVnKFXqNddyUHa/4CwDFN03BNQ4n+VnTXtCMdXwEpuFWFH3ffL9JOMFzjKsGNcoOAS7XhFeAafF893wGKdccQFILCwJt0iZsY2mFQCk9iMkqBODaCwu0BKjyJKShTIY6jE38bw+cHKwoxFGI77hEk4L20F/W7ttN6PA/NaKkWUMSLa4ETmqhmEbF13X1CCyiMu0c7WqitmqkLJX2iv1Gcb41GoFmvF/H+Rjnftm7RyowB6vV8Wwu9QY91xFep6WoFWvTakTlncQ03Mn4a16Cq9ThaYSc1LW16HcGNFBausUagMx1BvVakjR3ANQT0fF+H+VX6+4CeG8aVa5Net8LdDhy3KaM8goNbznkckEiXWum8QbnHxwYG4raD3LMC5R4gOQKGuAm8GIqmoASAsO2YhJraKH99NZqgKlyvCYqIo5Rq1YKTiJC0ITRoAYEbiiPZbotm4Gt9eT3PUUo1aWF4+HrZZHO+lLI5H9470hURlKOfWo3zXHjW3tnM+WQuJB3ODzT+do3D6YCzPZIsajobO/AV1PxXaeUGOySW4U502Jw3troIDXp+ZWS+Hq/T84KaTlFK1Xfgvc2DbhgqMJwwGB5AucfCyhAwBSW6b2DIufMB0JdJcBDDxW44ClFuf0Eh7Gtq+hKojou3cawUwp9uoPVPu5yorB98LYSLe2jUQif4lvEg573pgqAz6m8YyF+ZI1ow7Z1eXWgMEQnjKue74L8gLd9C5zcuXGgD+660dZ5/ofVsbaiAazEVJbRvE8E9Cg4Djj5SdhTKVrrL5r6PHDk7jrgXSWxtIMK5Y+RwGM6GQrmrimsPAA0ej+CLj4bGBlqP7L+QPC7C9wgGcPbekpMvVdqhvSg3friBzY1E7kUS94TznKHoIBW5ZSQO4Ch3hiHUBsNH/uVQ6XLcRCjU3q5ob3EIYUJU/D+ax4vwV8CDu2dU315a/NvfdO923SDTnx2nzJ44YigTlDIwHEGZIMpBGe5lU0QwlHt/QOnw3xSyTxe0tX26oODMu0FHanBLuHDkTqPqfAPgIvxTgMJN0JJwu0eX4hpG5NTub4HIHBs3ApzGLZ8uuG9ehH8e8OAqrV7/NuPWy1H8jc1/3J2kXa9VjZuRXjSA/wfQ+bTN0k/n0uq7gOAqPZKxXqiGvwj/hPB/7pULV1AwWp0AAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">IM Thể Thao</span>
                        </div>
                      </div>
                      <div
                        class="DefaultLayout_subListDiv__5oE8l DefaultLayout_notice__5mgP6">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topSports__Zzktz"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="SẮP RA MẮT"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAAlCAMAAADyQNAxAAACuFBMVEUAAAAAAACOjomMjIeLi4aTk46Ki4UAAACtraqWl5KRkY2wsK2oqKSfoJqVlpCPj4qysrCampaJiYQICAgEBAWXmJMAAADOzs7KysjBwcCjo5+ZmpQUFBPR0dGVlZGIiIOHh4GGhoDT09LGxsW7u7mrq6iqqqalpqKiop2hoZydnZmcnJaUlJDMzMyzs7HIyMfFxcS2trOoqKabm5eEhH4xMTHCwsGurqx5eXcNDQ3Q0NDNzczAwL2mpqWAgHx9fXlqamgpKSl7fHZ4eXNYWFZRUU86OjouLi4mJyYcHB0RERHV1dXLy8q4uLecnJiQkIuBgXt0dHFUVVM0NDMkJCSPkI0PDw8AAABvb23Q0M68vLuenpyUlI9DQ0M2NjQDAwPMzMzJyck+Pj4mJiYHBwdFRUYVFRWLi4g+Pj3Hx8asrKmlpZ+WlpSGhoR8fHdmZmNMTUtHR0YbGxp9fncNDQ1BQUGGh4CTk5DGxsavsKyysrElJSQSEhKEhH+UlJBPT09CQkKBgnt7e3WYmJNyc242NjZxcW2IiIQiIiG+vruMjItcXFtQUE0tLSsgICCJiYRFRUV9fncHBwc1NTVjY2FgYGCIiYJwcW0eHh1sbGzHx8Z9fXoEBASDg4PBwb6kpKR+fnp3d3TExMS1tbXCwsFpamiOjoxRUU5ub22oqKQICAeOj4mKioZMTUm9vby4uLiNjYhfYVs/PjzZ2di6urepqaZoaGbCwsECAgKkpZ9dXF2ZmZVsbGxNTU2iop2WlpB7fHYTExN9fXeQkIoTExNCQj/S0tLIyMVfX1+xsa6BgXt9fX2HiINhYWFyc2y6urdvcGkpKShEREMODg5nZ2Y6Ojqfn5+Li4dHR0YhISCKioqRkZErKyuZmZnHx8Wjo6M+Pj1lZmLm5uZKSkl9fnd7e3iXl5bZ2dmoP6MlAAAA6HRSTlMAzMzMzMzM0czMzMzMzMzMzMzMzMzMzszMzMzMzMzMzMzMzMzMzMzMzMzMzMwIzczMzMzMzM7Nzc3NzMzMzMzMzMzOzc3Nzc3Nzc3MzMzMzMzMzMzMAtbWzczMzMzMzL0WDdbU0tHRzc3MzMzMzMzMzMzMw7SupUYbBdrZ2dbV09PS0tHR0M7NzczMzMzMzMjAuriwqqSZkpKMhHh4dWNaUkk0KiAaFg4M2tjX19bV1dXV0czMyMjFxcC5sbGwr6+vrqqioJ2cnJSRkYeGhH97dXNycXBmZWRfX15cV1BMPzw7MDAdGREQ7RvKAgAABBlJREFUOMt11OV72kAcwPFLCJJAAsGdUii+QfHi1Lu6zNpV5u7u7u7u7u7u7u6+/RsLXbcx+77Jm89zv8slz4E/2vru+apVD199bAn+27b39y8NWlBfX79g0LLHG5v902x+eqYLk8kUJ6KeOVfe/O1arju7fWJ2Tv+6KgGkzK2ItYnt9V7d8OewWxPHWNJCDrtOFu5aLA0UHix0NB9xdE3L36Zd3NfVbEjz8dKLQ47qIp00lUpV7duzImnq5yGj3S4jJ43Fbp6u14e9ju4SlUqVmurgjVgx/MeWGi636otb5E2qWi7T2aWSVFVAJWnrH/moSTVb3jqDoSj5oWRGShVJAoFAW4nKl8dc/12t7SSutKpLTBwDpXihAOmVdJcGg0FJMFjIK+8y6EsCDRvcGpqlaOcycww9fLygd6ayXKYqskul9iKpRNarsvWDxqVaiYUxgk6ajU7OoSKsCoKEFc62Ep3O4eiuU4U9zPot1K4WM6EMLVGqwOXGUHE21JjHL0vVeb12aeEMgZj5DIAN+RA0gE7TEiXyEDoHakpQ6yy0y9g1zhlCqPUyAJ50gqC+VhpGQ9CYAPrVgEiv3uowT9IXYp4H4CYTmo3DpXQbSy2EklOGi6tlxdP1BeJjoGExU9hHxIdpXCsv/puqbRtKb85jS/1iIfhwmlln5SM0mIul5fym/FIehVg8/TQh2LKwUzldk1CwPJI8UlCjZ7PZvh4cWRsh2LroAMJI4TNoMKwglUkqT8/zsVhpBifLdgQMHzKpTJuiYSAU69ktSc2czupBGY7RhB4G4MakLK2WWgyBEdOUpIFd050cDscox01T5wKwckLEXdbIaJj618i4gWWUy824hST9lFo/AUHdZe4EY/TsJ0iU0UKprGCb8RpLCYkStCknAfjUJ0Ukgt1urYZP48ayMsuzIr0xS7i3yCUi1HSMi/F3Xaf+1KWjLTjajs7VaOltorjCZbVacLynLYraRAShtrBEY9YAAIbuzPFzSAwlRJooxqfOhEZDEAYR1XBMNXJ2enn28U2U+jpkR0G21UiU9upDKmx0qnY2AsVL2pBmA4vbP99zFyQa2sJTUBVzsaMMVI2KRAoFSbpcpGlqFosxK57beV4DaOz2qLy4cnYFVwFjjSupURQVqQ3RuvzK2s4dXoPvtR/cak68StDfzKU+Z2kphlEYs+J502pzczusHA6a2rSwlXJAlTDHhFB7h2EulwsTpsqCbnmVHZa2Bz/bOHgUdZRQNq6hTpdBvaLNnNvCE588bjmFfjXsWscuGUKogtCmpGg0fFhRJ8z3jBu7+o/LqdmLeR0LWkD9kLJIpMyN5Gd06zx20VvwV8NWn5jccf/4zKzMzMzxu0f2O/UyaVpSDevuLDk3f+DAgfMvLLk3NGnYN9yK9nH1K1CVAAAAAElFTkSuQmCC" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">SẮP RA MẮT</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
                <li><span>|</span></li>
                <li>
                  <a class="DefaultLayout_menuA__Eilgx">LIVE CASINO</a>
                  <div
                    class="DefaultLayout_menuSubList__mx2Ni"
                    style="">
                    <div class="DefaultLayout_bg_menuShadow__Rjze1"></div>
                    <div
                      class="DefaultLayout_subList__-8hVJ DefaultLayout_subListTwo__P6WWb">
                      <div class="DefaultLayout_subListDiv__5oE8l" id="191">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topLive__2U19Q"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="EVO"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEIAAAAZCAYAAACFHfjcAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo2M0Y3REQ3MDBFQzExMUVDOTFFQ0UzMEQ4NTA4MEJBQyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo2M0Y3REQ3MTBFQzExMUVDOTFFQ0UzMEQ4NTA4MEJBQyI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjYzRjdERDZFMEVDMTExRUM5MUVDRTMwRDg1MDgwQkFDIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjYzRjdERDZGMEVDMTExRUM5MUVDRTMwRDg1MDgwQkFDIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+HuMm2AAABexJREFUeNrcWH1IXlUYP76+fn9rOW2WNHUsE3VMnQtkuBG6Flv2QYwVRLgWSKwo+mMLtuUKgpHVqFiFQjU3tqINZDUxCyutjEwl86NcGVOpWVo6v337/e6ea8fL+6W8W7kHftx77j3vOff5nd/znOe8fuqyXe/n57fDZrNtBm4NCAhYYbfbcWsb8vf378a7Btwfw7OfgoKCVGBgoAG8U+irhoeHVU9Pj1rO5ge8ADwNRxUcVcHBwYaTdJCgsyBCORwONTs7ew59d4OMX9jvWiLCDlzSSeCK82oSYq48+4CIovHx8Z+npqYexf1RPidB/K0T2wusAy4u4ntsQCxwCGi5qoqAhcHJXjgeHxISoojQ0FDjqhNiKmN6elqNjo5SBc+DtH3sS/I6OzvVwMCAPnYzkLPE77oXeP+qKgIOjsHBN7Cqz1DmpiLoYHh4uDIdNcmYm5tTk5OTKjIycm9vb++F/v7+19gHClneoUGnIe+XQcZjICOKDtNxk4iwsDDjSoXwnamKhIQENTg4+Cpyw6cYp8OLudjnLyDQTR9/YAXw539FxEXgAEKkgvFOh/mczkdERKioqKgFZDAvUB1MkK2trc+KlD3ZPUDn/1YRdI4Gab+ESxFWvJhkmGFCRSAMDDJICpXC9zExMaqpqcl0MAtoXfahQeMqA9tByNd0jLuEnjNIQlxcnEEKyUtNTTVUoSU3XxFxG/AU0AckAHXAWy767gYKgd+BGOAA8KO8Ywg+CGwDbpb2sHxnJfDVAiIY87J9MBFOgYy1MzMzp4FtJMckhM4zPGJjY1V8fLxBCJKlOU6hDxdnCCjR2huBd4EJSz+u4EHJKUrI2CX3xcB7QJiT8dcDjwDnRM1jxr4tSjAghDioDBCxdWJiohtQuDfekxCSQWVwu2xoaDAHzwSiPTiYASTJlqqjALhJ69cljpuWII5ZbbNGghLVjAMPAR+6IEG3IqANiDQUwR1ACw0j/qkOXM9C+mehiLXA3UiS6xAeNyYmJtLhwMrKSptUplyZGSBepOfKTrl59wqwR2sfAx7Q2lTIactv7rS0XwQigCrLc4bAESnsNgBPAuHybhXwNnCXnau7oLS7XEGqkZERo17AtaWvr6+lvb3dUENycnI8SEmtqqqKkUpwVGTZ58Pw+Eh2mDXS3iofP2pZUdM+E0crLeNUAzu1NsPhOPCdLCBtO7BpARFUAspnNTY2poaGhhTDAs9uQX4ogfM5yA9JHR0d0XV1dUEgy8yUQcC0xLIvDxwnJPnR+JFbNFVtlARo2lG53qc9m+IZysm4XVLCH9Ir2fnQMIlgPqASmABXrlxZkZSUlMXkmJ6ertBW5eXlzqrIUS/OFA8D30gI6caV/sEDEWZ4nNIUYtqchNJqTfK0z4ELLr6l1kLEertOAnMEVYBa4QS2x/vT0tJUSkqKKiwsNAgqLS1VjY2NzgZu96IabFpkQdUlSW+LtO+QQ+KM9oxWoyVj3dyFaj9LJ6lkacn802E+WSIsbJD/l9nZ2bn5+fmqoKDA2CHq6+tVWVmZsVO4sE+uUJ1TrTkdJbtMm8Xpk1p5bi3X3Z1ybVp7xs6CiSRwxSH9D/Ly8nIzMjKMxFhbW6uqq6tVTU2Npw++UidFjntY2yaLJQRMYziekftfLb9NdTNuiux4/6qPK84iCShDODhyc3MdmZmZDmyVLCy8wRkXkzVb+q1ZIhlHtDHOy+HNbL+p9WPSHrDMmeVizNct/Q6aL6KFXccSkOUlESVSHGV7QD5jVhtng5u5b7fMWWF53ya1hW67nIwzr579SyThCTcr2bzEMR2SG6xFkbVPl5M5+e/Wb5Z+f0vtwKLtWyfj7Ndr9v4lfOxhD5L2JRF7nPR5zsW8OVLXeDOPHlpqn4+V4AsijlvGSpRDl94n283cCVKduhr/D2CH9c/b6xaRuFjKlgLdXvR9XBy4tMjkGO5kfCbBTcANsv+PeDj2D8oOs0rqD14DJA9+AXwshCz4O1/JqXCnTLZayLHJIeq8VGnvAN+ra9T+EWAAM0h3KmC+IsoAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">EVO</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="0">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topLive__2U19Q"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="KU CASINO"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAtCAMAAAAQuiwzAAABEVBMVEUAAAA5n9g5n9g5n9j/pxr/pxr/pxr/pxo5n9j/pxo5n9g5n9g5n9g5n9g5n9j/pxo5n9g5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9g5n9j/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9j/pxr/pxr/pxr/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxo5n9g5n9g5n9j/pxr/pxr/pxr/pxr/pxo5n9j/pxqnntYWAAAAWXRSTlMAUCP9hvr2FwsFDqKcWWRPBPc/PBAHh0MI8/KAMSQZDdi/rZdqFOfk1MnDkpGNinpXE+3htrSup2hhOZ9/cVJMSUcsKR0L7efez4lzbTjXx7eWeGAaultNHyQiKA0AAANoSURBVFjDjdbXWupAFAXgFYoUUVFKEFBRBGyASMcGtmPvDd7/QU6iQGYNyeC6UpLvZ7OTmdlArhQvHfc0rXdcisfjqTCEnKWMT+Y07XQuZVwsxR9gZK17sjDOiQ5K9NZj5fYIcPXFHPghpNGnzAZh5Dw/ELLDfHogJqnkNxcndJOvisIh8/t/5yP/7HSkZ0ShqeIzMn8ds/SCrY4lErIq/kPmG2En3Q87fuZexddlvhZW6NP5QJn4XZlfj9n3PQYHvsX8LvEemZ/9rf5B0sXV0KV3Q2e+SHwZiBCUghmt4KzjXgSu0ip+H5ib5Df7lBDpKBPfUTXnRObjpu5mPQbKnQjkfXTt8oP4tMS736bqzFdBWXsi3ifzPXknCPkBqb0qfkfNa3Y6C00R2FLxmQqwSXxjmo7ohihsSBe3xItPUcT2+hS1ztVP8hUvbdbEK3RF9Qo+myDeQedcZBS878+8ey+I6fwhKB3ijwKIvTjoxwBckfAEv5IUAG8ZlAV50QbX7fV5AOHa4qqs82nqvQNFp+rbBr/trIeM3WwKfwRKi6pfcuAXTR0h8685me/Qdr8Pyi3xK8yz/vtQrnPgtGm774BSZt6298s/+uvwvxcofv/MEu9HTZnPFez14/Fo0mP+XsXvyPyqW6Wb2ab3P5FV8Im8A899531ujw6MQwWvzzjwXPvDgfSNVqLPxOvE81GYeR/xrCPHz/vxzBJ8W/Tee0T9m3tz4wM0gl6Hm8Ap/6aa3+JvqPpii4qnNNcMiJzxIgr1KSWrOXUaFD6rJ5ejp9JKMu8JABrzwnRMebN/c5Ldw0FTT79HKyt6fSCla60emUeK+YOI/apN62aLnjbq1YGc6jeAkgOf22b/0YXfnHvF3ncrOwOHtLlK5jHvZn97dTSI8Y655KDfXMAIH1YarIT6nPWhn+YJPnDLLC+4GhFnAh+z2sMzfpmHwMqzjZ7/wk94Abkg5Oxa8hs5mEkU+TzxTbY/0xkaNSeefe7PZ54msbUs40mPb0QUFDxcs27JH76f70WvOCsEdKFBV57zwFhYVvEIajW+oTBcX4mVVt0rDAuXnbuNLSM32f2LBKDgOUHXaarxaN212HgYTYPn7ezPzLP7W2zUZyYByqkmxnYuC/tzqzlXb3RPJGgdH9EL/atdXIBT/gP2U0j1J1W0LwAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">KU CASINO</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="27">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topLive__2U19Q"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="DG"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEMAAAApCAYAAABupZRPAAAJN0lEQVRogc3aebBWZR0H8M+9XFC8CWiCAlpmggI2ihqamuBuaanlkmmWkjPlpNY0Zcu02JS5peaSpShmy2RZNmVGZWqGSG6YWaKWqSiIKG4oLiz98X2O77kv7+VCXITvzJlz3t95zrP8nt/+vG2TT93ZWoBJOBf/XJOTaF+Tgxech4n4ETZckxNZk8zYDL/ByeX3WNyGd62pCa0JZozEGbgX7yu0n2I23o5puAw7vNET61jN/a+Dt2IMRmMC9kJbef8YvoCfYEtcgj1wXLluxg3CuH/gYby6uia7Ophxhex+B4ZgKPo1tXlUdv8CPFNo/8aeOBYnitrsXi7ChNl4AgvwCj6DB3tr4m297E3aZXEDWrx7TGzC1fgdnu+hr/3wCbEhG3fTZhfc+n/NtAV6WzL64mlhxl0y0X/hHhH1Z5vavx8jcBOWYpvy/X/xh3LBKGxf3m8oKtSBhb05+dXBjPXL86fx127adWIy7sd12FXc62w8jmGy0DmYLioxQ2xLP3ys9NOr9qO3mbG0XD31fQEOw+fwERyJs0WaFogULcAh2BqLcF/5dksNG7RWS8ZCsQWDy9UdxmAJzqrRThKDCzNxIS5q8W0VmL0qEtNr6O04YwmeK8/DavRObIHtsJGE3c1jD6k9by3MmF6e66j6fUbDE/UKVodrbcWMgdgWm2Nv8QIrgp0s65ZHlPsTellNVkcE+kS5b1mjzcY1kow9iUEtvrtFjGQdi8RzjKjRtij3p1Z5pk2omLEvLpYdG2LVmDSl3MdaVvIGSQTajEfFzW6P02v0DpyAK/HZQhtV7t15qhVBu6xzR3wXH6gGg7vxQwlynsNcvCA7swgv1zpqw2uF3lauRVisIRVEJUZLjLGJuNpxkqA143TML89fxFG1dg+LdCyWaHa7Qh8jBnZ4WVyHhjfrEDdfeTbojz6l7cDCjEFihM+rM+NJSZKm4N2lcW9gnDBjPE6p0efibxJc3SXJWR2PaDBjBNbDnTioLIq45lXFXdgf8+gqxi9JHjAex5R7H1252x2WSrDV7E7fI4Wb/jXafJGal7VGp4YqVFi33He3LJ7WMNptLd7X0SYe7zZcLpHva9XLZp3evAx4oQREK8KMdhHhNjGaH5ZEizBjkESOcKa41kMlbV/S1FcnrsKba7QncUd5PqRGv0Ki2PtETfu26K8ZFTOGipTNkpgGyzJjthi+b4gIL9Azt/uVyRwsccF0ScrOEIn4uESXV4gavlfcbp3Jb8ERpe3Ipv7PF73eB28rtNPFtpAk7ga8SffSVmGpSNmI8s059ZfdZa2XidFaGeyD62u/75eFPayxiDr6SszxIdmlVnZqhngY+C0OlA0bXmuzvdiTlcHPJAXogu6Cromym/tLNarZMpPdXSD62qarJyEGcqSo3kfFW8E7cXTpu1kK6pghDCae48Dy/PemdvNllzvEbg2SZK8+38oD3iClxntaDdgdMzrLAu6RYssSsR9Vx4slB1lHLD3LMqOern9eRPgYUZPl4WWRzC9rGMZzm97XMUc2r03ylRdFyto1GFLZknHitmdpEcp3x4wXZbGV4VtY67itPO+Ow8VYLhWRrxdahtaeR4to9oQfiM+fWaNN1JAQ2KDpm6pu2k+M72licOvS3Kbh0c7STU6zvNzkNOH6qVoHSoPLANUgdUM7UEp4K4JXRPQfKuPVaxS74tKm9jtJXfWR2riVveks82pVaZuLr+P73U2kp0RtMv6CrcR2VKqyRGqWlf9fKnpaYZJGqn2KSE19d4moXoBfCiOIR1hcnnfAn2SxfxRXfIUwf1Ktv1kSI60n0jFLQoN1NNRjimTKy62X9sSMPlJ8GVIGeKEMsqgMun6t7Z6iXidit0KbK7HF5DKRagdnatQ06lhQ7odKUNRfosMjxVB+SYzu3mJgz9HVhnSKdJ0tavJKoR0rEvU1y6mO9cSMxaKH90nCVMeEMjDZvcub3r+KD5bnecKgX4mP31yOBSZJXFJhvBwqVcHVg5LAVXnLQXJ8MFhylCubxpyHd0iY3YxxeigTrkh2OlNqEfc30TslmmyFGyXHuaVGu1cY8nNRr4licKcLU+6Q8LhixC9K+7oxnVn6naI1Bmt4twqPSIX99m6+eR0rc1TQIanudsLhK6UKtZvobBW6TxV/vjwcLllsq6PEWyWtvqqHPsYLYzpEbfuL6kyXgnGnVOavtoJFoN4+N1lZ7Caiv43ENNdatTrFKmF1Hy/2hKnlWiuwNvwlYa1BnRkbaMQNbzQGSDLXqjb6hqFDjM0eYr3HSInum1I06SfGciOtC7DDCn1VTraOE9c8X2xIh8Z/NlYWlTFtt2wMU218lVuRuGdjCc/ntUtBZrQYrytLZ9eWxutKPeFgSZw2KfR9JIc4TAo4FQ7RCLiIqzuqaVITxOeT6HSsRKHXSBA1Q+N4YKRlGbOfrpWwYWKEiVu9RKNOerrkLhW+UtYCB0j9ZBs5wJrYLjv7QGkwRypcT0gk+XyZ0CSNKJSI81Bxgb+vDXaCZKYVXpMQumJQn7LgoeIK98VXNTLcx0v7audGWDY3OlTXfOVkfKs8L5CNraRitLj5AYU2QDLhHWSTfiyB4Jm4s13Ep6+umCohrzLRXSRHqSK+p0VqDtDg/ITawNXk1xNmHV9+jxMGd4iNWqxrBjleJLDKgdoLc04qv/uI5AwvC1XmcVt5t0TKhAtFHc4rc76x9u0cKU/cLelC1e9DlW69XhQt2Ewjelwoonm0FEaIGD9bFlK5571FxTbRqCLtXBbTt9D6C1PHlokM01AZIjEnlvlsJWr3cBm/Q6OIdA4+JfnQTcLg6j8cSzVqGaNENa4X1Z8j5cw+uhavj8W326X4Wj/PrP4zcb4kZcMkwZkm5bWBGn89mCZ/L9oZm+J7kiYfLxHg5mUB35HayL2S7Y4SqbhUstGqtPeS5BdLywSnyeHWHDlEWiSVsktEWj+JXxembFX6GK6xQSMkEz5FygRTRHIvLuvcr7TrwIZ9Dt5j02Glg6fEm+wohmdeYdS2EtZeV+v8gTL4YJGSMXIqdpvs5AiRnCVlYX8We3BLWdBbpCx4s3iiw0u/oyQCvV+M9EWSCc+SBOw/5dupssN3SzI3SiRmphjP28v89yp9zRfp6F+e7yj0I2Rjh2Lq/wDPwi0Oqot6kAAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">DG</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="112">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topLive__2U19Q"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="AES"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAAAoCAMAAABevo0zAAAC91BMVEUAAADmVGjBOmLtXWr6U3zYOW7vR4j+fkbKFF+tCEv/kDrxOIP+QXn7RYD2QYz/tiTqOH/XSYLEDVj8OIj/wx7wPYb0Ro3/g0PXOnnJNXLcIGyuHFncK3P/riW/EVnyPoXSKG/+SHPLImjJKGv1SYT/wSDKImflY5jHLGvBIGL9QnjYG2jnMnv+SHK6FVj+W2L/siT+RXX+VGftO4n/fkb/tiP/eEv/pC+6E1j/mzP/tiP/hELmeabRMXO/AEifDUjMDlv/pSv+T239NYT/pSucADf+fkf/oi7nNXv7OYeeADn/uiP+UWr/gkPoM4TOGWSjAj/SKW//syPHGmH/lTX/ryfEJmgWAwuxLmXfLHW/FFvlUo3/ryPWH2q2CVDRDV3SLG/AJmX9M4b+Y1v/vyC+DFSlBET+Q3fGJWitC0/+VGj+iT/+T23+WGX/tSSnAEH/xhzJHWb/lzb9NIX/mDT+fEj/vx7XJG3+SnD+W2JEDiLAGV7/fkb/rib+XGLQMnSiACP9N4P+T2z+XWD/vyC+CVP/xh3/oS3+clDPOXb+blKFE0HsPYTmPID+YF3mKHXbM3j+Vmb+ZFwWAQlnFjinQmr/pyr+c1D+jD7iNHr+blL/jjr+g0P+Zlj8TYFbDSb/yBynAUgaAAcqAAgPAAIwEh/////9NIX9On/7///9N4L9PXz+QXnpxNP+RnT+alb2/v3qztn/siPklbX69/nz8/Pz5+zs2ODYgqb9M4fNRHz+ZVrz4ejVVYn+WGT+XGH+blP+clD+eEz/hz//ny//rSf/uCH57vPhnLnaiav+YV3/jTv/mzL/qCr/wh711eLiscXiqMDclbLYc5zVX5DMW4rMToL+TG7+VGj/mDT/pCzx+/fx7O7p4OTwtc3kucvtqcXZssLWpLjff6frWJPNaJK8Q3bjztb0vtTRl67miK7gXZLCV4TRAlX/kjn/lTbvfKvicZ/pSYn2OYaoBEf/oS/Piqb6VJrLdJi/ao3IBVP7jLj/ebLERNa9AAAApnRSTlMACgYQJBcd/r16HolPPzQl/vzIspJbSyv+/v79vp+JaF9ZUTsuLP38+vro2862qZGLhXp3bWVgX1tWS0L+/v3529vWysbDwLGupqalo56Zk46NdnJuRC4T/vz8+PDt7eno6OPj4uHh3NDQysrDuLi1qaiclpKMg3pua2tpTjgzJvz48PDw7+/r5eLa1862sZqFg10sKPz88fDr6uXfvY2MckNDPj4qgkmCnQAABfNJREFUSMetlmVUFFEUx++ywi7dKSEoJa2iCHZ3IWJ3d3d3d3c+HGBxe9elu7u7u+z+4NsBFAQRD/w+vLfn7Du/+d+7s3cG/oS6baSqOnQdlKWvMQrQZai+FjMeugo5N5Kl0FUsdWtgpKrqeFl56DQS7m7NkYXOIuXewBF5BXVVN7dtnQ448uVLUjgSALa5uXWDTmLwsgH3I3IK493dVTsd0EMMqSSTSnayf3J2np6eHr17N0nlm67zZNqETROmOfyfv5udnZycFzb2XuXpQdL0b5FeWZOUz2BElA2Vho4jb2cIsNsLY2flKcbDEEgkR9ewyosqK4tyEaP7NOgoe9Lloc9uq/R0r1Vg6NUbJ10l11Duyk/E16Gjp0lPGH2D8PkwCzrGlYyMo30MYX16enovACts9OomT0aULkWzJ0iSnw4PRaUdLPrghmN+fSTgYEbGiLUAQJl01GsEgIY440pu4WggfamRX7LLHDo2sZYdvNgH7xv8RtisJX8gKxvotXuSFf5qNqrc1CCsKWeUraG0e9dBIzbe3nvEGn//q3v81tpcmbQe6+VGrKfiM925/A8O5GnpNWv02/WBq/Uz1xd4lwkIOCv2LYu6CJP8/f38/DIyNhhKAsmmSpT4YR90CNcf30v24r3/jrP9se/Vq1cPlnlHRUX5i6WNPujZPRcldLemQnvso/fA6zWzcPTmGg7YD/ppApwOvBuAnd7epNMGmtDHRp+yhT1bGoygGT3ThGYU3JRzRfGfHwE47afigGOC9lNuBQY0Oo+JmyVp5HCINBYiJJyrDw3MmgVATxPh1cFafBVnlen6EchcguJ8Hc4N3YtL3q8pM9lpMo02Zke/oMDABidOTLXWLi7W3iIBYLTwazZimdHJMCoi7elGpUSaEej7cswApqbm+Z6IYC45tPrNZ9enzwHTT0YzODh48n0abXL/oCDSeRWAMixSUFjO93UWR7WeXYjCtbcA9DBh8H1EKkKU2sNZhBLMoac5Yi5RYTBXq0Tw3l8HkpkgE31voFMwRsaJRsPO0wCwhUOkrVgiTBF3G4sWfkJ8EwrVJDy/BiXTz6CkIb4o8sQh6lwGKpu6mssakkyIZKFROHP7VoCt0dHRwetAcx2NRuuPQynzUqeCxK7LTaNtRRFKnkqPZxwu4JktikCJ2ihyBRWGRaBClenJKMUEldKhkYExMQcARtXX1UVHa+IOjBkDuG8cgXnLYWnOY3wrZoryckS1VYKicL5QBYBejIjUYYu54ancyGG/bnrFkJDtAMNjMjPr62QAwGkHXnYlChZAC+is+CHxOfkJ2rWmhGgu8hmiTqVXcb+gYi0fvg8vaVGz6Xtq+FgsDAkJicmcOWD7uujb4qZxeIMVoDkWPhGDUeRiXYtqIrK2KhsVaGnlEb7fEpg5pYlIuKD540zPxdYRRmVlZX0ceyoms76+DhfeKwVxLKAZuwYRWtWIs0h3EEqqrSbShASTL1CeLq/rOzgFJVtIQTMOzJ8/CvRiY2NvUseKY2YOBIDFLFSt+/uYuhZKXKDMQxXxTKHOHS7DQjclSTi4L8AlpQLEMqFCC4az2S72oaGhWItjhsSIhRoiHno7R7YXiFG4VELk60gZpOQyy311NQYxfTVA47KBFEhZvglPyHkrCy1RDLN1nM9ms/XAPjQ2NuvjAMBMSctF8YPeWY6bMu58SQEvcY46gKyy8hmcyvTtvMbcShVMZY5gTqupttMR9MLC2DNAhh2KlaQQ+molZROET0VeBUvAMLUks0qSve/WGLzvu3C+TgkxzwBaMdEe7MPCFAE2srHSBYy32uJCxyknJ7AELAbH1NIAWmNQQrB0lBDHElpD2bwTKBt3UkEGB2XbDpyhOHaGOIr6lHEXLkzpqwBtIPWOK9B5T+QrUaEt1DYbq8UtV5txPGy53gAqOG4cAP9ANo+p857LUpKHtnFUOxkXd+B4XNxEkLCfOFER/sV5PiogGEoa8FcUH2/GUhxTzdYF/s3DqpxsDva1i7GxsaKiMXQICVXTeePbeIH8CWEVji0mAtZcAAAAAElFTkSuQmCC" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">AES</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="118">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topLive__2U19Q"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="WM"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACcAAAAoCAYAAAB99ePgAAAMvElEQVRYhaWYeXRV1b3HP/sM9+beS+aEeVawlTA3ApZBtMrDFul6ivZV5ekTq33CK1bAhXWgr1YUwfZZKbavpbhAWyMIkSFMUZKIQBMaIhgFTEKAkBsyD3c+5+z3xzk3XBUh9v3W2uvck+xz9md/f7/92+e3Bf+k5a4umQGMd9ooYDjgAkygFjgJHAE+A/YD4ZgpyfTqGJakI2KgKYLSJdO+dgztmwBNfLl4oCLEY8A84JordB3ttLuc+4tAvpT8VhWi0hIgezBej+Amv/KhImC1YclFlkQDiSoEUsqwEeo8Gm27eNIMB7qsWMQQqqZqnl5ePSVrmOZLm6goSrop6Q3yYU0VDwcNc6MlWaYK4f9/w92wumSmYcrXgZEI0AVWtK2hwH/i4IfN/9h7JnC2spNLQgjnKgFcab1dWTf8YGj2uJsne3oPmmUi0oIx834BcxUpFyOUv1xpbHGlf05ZU7zUkGJV/D7YeG5Hw9717zWV76/Hjq0wEARCgAFYgAKoQBLgda568oARvn53PjkndfB193YPIK1XSpfOeOKfgVMmvFTUJBSRLiyztemjLWvO5L/2sQPTBrQDAQcw5oBJ550KtlfcDmAKkA74+ky969oBsx9epLq91ziAG0uXzph/JZEuZ173A+v+e9JLhf7kYWPuB24FJgCDgVRnYCV3dQlbjtUjpfxKcyBdQDLQHxgDfA+YO+HZdw9OeLlY5q4ukbkvF63tkXJSygWhqPl9r1t7QO89dLSMhnobbQ1NQD3Q6KhlOCoRjpm4NQWAzoiBYUG651Io17WHeX7PaV6/Z4wK+IBMoB+Q/u3lect7Zfb7LgCW8Ujpspl//FqpVqxYoUkpDdOy5Jw5c7KAa4GxwCDAAwgp5XVSyu40kqiUYVp/iJnWBx2h2JK6thAXOyNIKYnETG5dezguhhvoA0wEbv/OC7urxq8qluNXFcsbV+4Z/LVw4XB4rXSszn/xSWemKY5rcOCOtQQir8ZVtywbrLGx8br4s6fPNywAlJqmAGeaAzR1RvjgVBNDVxQy5sUisOMxG5jo6Tv87u+sKoqNX1Usp/2m5HCiN5X4j/Ly8jS32/2f8XuPL/kh7GDvBKIAN910kxsYqyBnkpCGhBDC5XL9GKCtM3BuxMA+uwF9aKaXQeke0n0upKOypggmvlxsAK3A+ZC/+mzbqbI3NEUQMOSk636xdfJX4EaMGPEsQDRmREzTjKb3Shrx7vuHc0hI5u+8885jAKle9/Xr16/va4MBoHo8nvsAjh8//kFc6VEvFHHTq4e4+bVDLNp8gjSPjqYKFNEN2ALUff6nJ95UzchFASSnpL0UVy8Op3q93gUAW3fsytu8fXcewG035DyVILOSmpr60/jv22bPeRTAkpLa2toZuq4PtyRs3PTmHqALiJ1pCVLbGqK6OYgQ4HWpSGeqloTp//NRzAG82FXz8buWBKFq03KWbhzUDVddXX2zECIZYPULz+/99XO/KADw+Xx35+XlpQBUVlaO03W9eyEIl+ceQFUVRaSnp88HaG1trf7fda8dBwK+JQXZ067JSB/dL5nRfZNJ8+hEDMsJAwYoAm9TIAp2Am86V/ROga7aOmjelLmAUADh8XimYMeEUVZWevr4xxVV4XC4BWD69OnzADFkyJDlJFj/DN81BQUFgwBdd3vmAhw5fGgbdnKOZvdyrYiZ8veWtOMiHhulS6YJw5RbvZryr8MyPGAn7872Tw9VxQLtpwEU3f1dQFEAzeVyjQPw+/3lQAPQUFZWtgUgJSXlx/PmzfN5PDbAm2+/85czZ+tOAOSMHvPD7XsKc3RNTQV45ZVX9jkupU+y699bgrEfFfx0kl7XHiYcM9FUwdhn3s2RkIs0b9356KR4WEWA9nDjuRIAoenjAV0BdK/XOxrg3Llzx7G3p85frly905ISj8czfcOGDW8KIXSA+3509/Ztew8cBOidnfXI96bf+JqqCBoaGioKCwtrgVD/x9ZPsSQeTRWM+vn6XLemoAjB35+YJrSkXgt1VdAVlbdxKUWZQNAMBc7ZblcyAJcCaLqu9wGIxWLN2GkjvH9XflVLc0sl9mK5A+Afn5z6ELhYemBPMYDL5fpWUlLSFICysrJ9QAcQ86b3nh8PaHdG/wdLl0wToZgJoKlu9z1SgqapfXOWbpqaEClRpNViB6XiAzQF0BRFSQLQNC2MvTVFgLb8/G2bEuNs767tWwD/W29urPD7/UfjfzcMI/jMM8/sAIJi1pLk7PSUu8Fekarb+8DEn6xMGZbhJXfF1jsMKVItKZGAO6PP41zKBgaKGrSVQ4vHnGpZVtRRIi6xCQQWLFhQGI1GuxxVg8uXLSnBTp7tmzdv/lscrqam5qPy8nI/EB4xceq8sEkyUkoE0pRoKcNG3779kRsUT2rGUsuCJFVYqgBFc88afu+zac5rpKK5BICUWDirlUgk0grg8/m88Y7YS7y17PinJQAnTpzYhf2pFAC6Fi1aVGQYRgjgwIEDexyXGhnpqQ8oAjo+P5oXqq8qlEDIUqamXzPW1xUTkzRF0HyiZJMVDTchhJo8fNwd8UkqriSfPboZ6oZraWmpBsjIyLj+CzEA7cX7d78HkJeXt5NLW1kIaK2qqioBWLx48QEgoN+9apCBNkUVgpN/ePzthqK/5euqIKp55g57aM02TRFYRqT5s/VP5YeaLxwD0HypC3DyrZrky7bZzA5AKoDp9/s/deCmT5o0SXfgLCC0ZvXq0sNl5Vu2F+w7ib2SpQPYsX///oKysrK/BoPBNiAyaMT1PxMCYoH2SsDfVLa73DKMTlXVBgjdfbMFmI1ni4HGztpPigCE5po66r/WDQKElpI5HcAIdVZ3w1VXV1cCKIriW7du3bgE9SJNTU1NU3InrPyk4mgd9kKJuz28cOHCD3Jzc3/rKCqz0lL+DaDrzPHtwAXAH246XwigCJASOj/7aBfgr9v5+l5pWVEpJb0y+94CaIrLMxUg2lJfAVgKEFu2bFmJZVkGQFa/gXdxaQXFnDirx878RgJ4GDth1wOBQYs3TVcUJds0YoHa/N/tcGKw48K+DRu7n4iFL1bv+lMp0GIEO1oizecPKEIQUz2zxizbOFtxviLaPj1UBJgKYNTW1rZXVVW9D5CSkjr/qRdf7ZWgUBfQ7FwTy83uTRsID+7f78GIaRFrrN0dbbnQ6MCHWo4Vfh7raDoG0FFf874zyS6gs/HIjrcBNLf3Tm/voRsBzHCgtv79TZ8BUcVRI/j000//GSDV60p9auF/PJcAYTruNPmiSSCas/JAZNxPXkw1FNedUkJXxb73HICI09q66j4vEgICR7ZudsCiQNB/4K/lVizSLIVQLXCblsRf/v6fnT4xBTvwA3l5eacOVXx6EMDn8z3R2Ng4kh6YrirIIROei0npFrFgVc3+tyqAwC2/O2Q5E+9sO1H0QajhzM4Lfy84BYQmrSmRjrKt0frT7wFELYmX2IULW1btw05X3WLowODrR4+9wzTNqJRSmqZ5hqvUtY6pox5f/9C1j766dtDk2fcCQwD99t8foe/Te8GuPUYCucBAQKv0d+K8O8uV1mfmjb85KMe8WCQH33LvImAEdq3bbQK73JvwxhtvrIrXAsFIdEcP4JKwz02mYRct6YB4vbiGn2/9BOwCOxO7SErGrkPipaMXGDXyqa0nxj+79RgwGcgi4Qs9Ub0BwIyjR4++Fwc0TGvzVeDcQF/sU6begCu/oj6xdhXOu92AmlCt/aympqYvMEBkDfmB0PTbnEm6v24gL7YLZp08ebJQSiktKaVhmqVSyoFf80y8cHZjFz1CXqbATmg+y7K2Syll9cWOJdgeG+W0NK4QSorTYQwwu6KiIl9esk7TNJd8+YGrgCCl5EJbiJqmAFLK+yzLOt9dfl5s3YAdFinYLr/qwVI8RsYBs3fu3LnOsiwj/sJQ1PikK2IskVJe20O4gaGo8VBXxChOmKisrKx8KzMz81s4xfrVoC4HOAaYdd999z969nzdEflVOyylXCGlfFBK+UMp5b9IKedIKedLKZdJKQucyOi2uoamE796/tfLsc9eRjpw39hUbBd/G5gJzFm5cuWTDQ0Nh788YE+stbX1+IYNG34FzME+zBkNZDjjXNauJqeCvUgysFdiOpA0d+7crAULFozKyckZmZ2dPVzX9QxN01KFEAogTdPsjMVira2trbWVlZUnt23bdnLt2rVnsXeGNuwDofiW+OWdp8dw8T469rlJOra7U7BXp+CLld/lJhf/xOrE3otbuLSFXfFo+JsEosBOGR6glwMbP7nUsN0Th41vXRHsb8CAAxR0oKyeDvhNLX5yqTstESxuiYAxp5n07BC92/4PkDOen0jyU9AAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">WM</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="93">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topLive__2U19Q"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="SA"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACEAAAAoCAYAAABw65OnAAALKklEQVRYhZWYa6xdxXXHf2vN7L3PPefch699fY2xMbYDiTE4tFFDQkMjFOoS1BQlbVNSNUpwH9B8IaiNSlrIF6IqJG1EVSm8Ak2EVKUKKBRVTWiBhLQUQkMp71cKNobgB/f6Ps85e++ZWf2wz/UDQ4CR1oez95xZ/1nzX/9Za8uTP7wBl43Qn3+F2d0/wWUdiu4UlgJVfw5VvxPhckvhfDNFBDD7WyP+OQCiqMsRBLO0yVLcjRmIfA64jrcx9PhHhqhD1I+bxW+nFO+K9eB8TBCRZorI6SIO1QxSpO4douodIgyW9oDchyjAN8B+C4y3Mv96CCKeUC6enVL8RxG3STDUF5it/Amw9GPMSBZxvsDn7eZxrHIzm0S0mW9Wvp1IvA6EgNgfhKp3q1lENUPU/aelNI3oKSkMAHnR553rEaHuzbF6y6+yZvM5pFhSLu5bs/uhWzYhOT4fOWDYU28HhPq8g887iDqw+MmU4q2iGeoygGvU+XNE9ZEYBuQjEy8V7YnfENFZEcXlI2CwNPMiy7N7Kftz6xE3ihkgSUQ8IvxCQ/BLr/0fvuhidXUW6r4DgqUaEbnW4IpQ9XepZp+0WD2oPv9dEf9yjAuQIO9MsjTzDPOvPoK4jHJpZoe4XJzLMYu6wrFfPAy//7l7Uc2mRkanb8taE0JKhLr3fVV/eYr1ZeKLaxG5Q0U+lUI5aAIW8K1xRlefCpaAhPMjzOx9aHu5PIPzORgdzEaQNwIimEUsRvLOJNqd3EzWHr8yWdoQ+guozw+u33HRb2s2ouqLrzqffxPs42ADEMBIKdIeP4FWdxLfauNbXbLOOC4rzrAUGp8iHSFtIAVI8VizgHMZeWcSn3fwIn46K0Y/DUqIgRTKew69dH/fYtWaPOmsbcuzL7xQLc8ctQlFVVnY9wTzrz4+xGUg0hbx27ORccwS6jJC3ZuK9TIi7lgiuhyXdSm6awhlHx9D79Oi2So0gUKMZXvV5FaqYtVAVF8wpHGCDdMOsmKMlMIwzI1+xFB+qC4X1ztXIM7Rn3+ZVRvfPzG+/pcI1dLheeIyDj53N1V/jmJ0iqFOpJMRGsVLEZdl5+adqamqN3uwN/siFmvUZ6TkUOfxRZsYaryMHCaWiEN9+ZFQ9zHsQTE2GGmDc36LL8aa1B/OdXmr0bIUjwT3p7df+eGFA8/8SP0IzmeEsoel8vq8veZPQ7mE+hxRj6WIuoxGg8JRCw+Xt/CEoNvrwdxJqv6GrL3mo3X/0J1m4UKRDCORqj6j0++m6s8R+ot0124l1iVaLs/cF6v+AyIOSxFxHpePXppSOLdRvkQMA8yMGEpCuUColo6yRWLobRHR7eXSwVdaY+v3jqzaNFcP5lGf7/B5u6M+I8s7jKzaQN5exRHJHnKkXNqPL7pXQcLMUHUYRgzlnar+PaqeFErUebKRcbLWKN3JTXQmNtCZ2Mjo5Mnkxdj5VX+e1tj0j8dPOAPVbF8YzCOiJ4v4baoNMV3WaSL4uoxVX4zi8vY9IFc3YTUEQV3WNewu4OQj2d2MlCJmkZQqxGWgujP0Z5nc8L47lw48y8L+p57PO2tIMaKu2OCKMVBttOHwHdSsJqKouhbqCpzPvwR2UyM+w7SDk8zsbmDzSnqmVDNYPMBg6SDl0mv05n++Kob6nKI7neb3P/3DsjeDHxm9TUSXRR2hWvpYKBdWp1B3U6hQ58C42CxdKurGYxigYCsOQfVPxGXH1AAGW0HuEVh7RCccxAiWSPXgPAvVpMs6Xx4s7NsvIrvU5belGDtgiMt2hWrpOlL4cKs7RWdyC1nRvSzUy9f1F/Y9WvfmTtMjzgwRj/rW58zS3x17arLZRO44XFCI4LIRWt0TUF+cJ+qwFD4mLn8G4+YwWJy1VD2MODDDQri1GF17fzG2TuZffZIY67Oy1uhOS/Fr3TVb53TlJju87yYqnweuaR4lXFaQYvhg1Zu7KpbLYqHGEOpq6UxR/3thsIil6oy8M/GTUC6eqqofz9sT37FYYZaSZi1CPZjrze620D9EimVXRBfU5d+o+vM/V4srytdQT2QlOHIFon/dAFQsRSzWl6srrNGN8NUYy0cs1uOatR7VrH1iGMx/xuXd59dtu5D26i3Phv4hEFXnW5eFaomlg88TY7gWeBDjHAtVO5SLaKx7xLpHCnXD+FgO1bPGwuCvzOJNCI3kquuKul2g9yHyBdUs9OZeYmLj+27Y/IFLDmQjE4yMb2TN5vMo2uvvR+RnWAKRd6m4PxL1L5W9gxfFurxUs9bfiGbLIjokJisZEYlhACKIKiYG2NePIkcyizcn4ntFdBsizyOO2D90d6oXmNrya4gKex6+hcUDT866YuzGJtHCJlG9iVTfnkJ/najcg8XDJ+CbcK9wYuU4bJgFxQ7g5sPZAznoY5DOTKk+jVhtG5t+z62Dxdee3/vIdwGIdZ9qMIvzI2f6fPQKRAjlEpJ3biy605fX1RIiOvTT+H2DahtAvoLxDyKyBuS9R734KaQPiuqpltITluLjLiv+2DAsJWLdB4S8PXWJy9qPmKV/N0v/Ky4D0rmGTbmsg2gG4obiFY8DcTbIE8BfAI+KunsRdg+BPSPw60APs4tF3NPq83OrwXxpViM+Q9SD8BnMrhdxN4roRZg9rq7AjFPq/vwFoVxghYcrdgSEcDXG/Zi1wDYCf59i+BFmp4C9TANgruGOXa0uO03Uz2BNm9CsIZuBbwHfV59dYhawFB5fUWFxfmfT0xxrCjhEv4vZlUM4XxLRUcxeSrH6MNheUfcR9f5lcX5YIdvyCqlEfSMvKWFmd2AMLFYXprrEYgSzf0aGnBLdCTJ93AUmLnsI5HeGvw3V6y3ZUwjrs7z9AMhZIM+hOgRw1DDDYt2kc6zfjaUdCF8D6pQC4jLU58+puP82i2BpjQg7D4NaAQH88lF3q4CMxtDHZ60riu7as83s1WPul8MAEpZCc66hT0rl9uZE3NPq8uHpCE0ZJd9DHLEeoK710byzGl908K0uvtVFReT8hvX0gSew9BVRPVk0u+aY1u+o3YPhR8YoOmsoOtO0utMUI6v+ByDF6vdTqBBRjISlmhgH/yKWUF8Qq6VP5MXYiZ3JLbTHNtIe24gCd4m6XxH120T9DrP0RWDPG+4ehvmtWEqkYYoliyRLuxF5uB7M/2Zr/MT3n3DGJ8CEuneI0F940lL9M190KJcPFoZ+KGtN4LI2Lmsf04vuOc7jGwz1BSCkUDYFStOKIKqouovVFY9VvZl/JYXtPhvZ78fW0159Skqp/N7M7v/6Qt6ZourNfqpcOvBPK1nzJmL15qNROzcshFo418L51hCcPp61xr8c6uXVrz55538Mlg5uKEbXMnHi6Tjn/81CicvalMsHLiiXD6yvBoeo+oeO/zTw5s6FlAJh0D8+S5oZmCWwdJXPO+ur5dldotm9dbl47iuP3f5K0Z58qLP6XfvK3uw6X3QzwXYifOsdRkLAEjGUb2J9UqywFEh1+Yd5Z/W3s/b4KWGweF/Vn99a9g4tiPP3iShiBqK7LAbCYP6dHoccvnyON9eQdliPpFB+NoXyhhjrraL+gRjKdb4Y/XxWdMuUamI9+IDLR08fW3fmOwVhTXFjb2FYownqL/V59+uibgp4qFp+bdks3SGihHI+a3WnP7v21AvePieaptfh8vabcOKoeIki6lFXIKJ/JupLLH0xlMt71Od7EUVcRgy9rb3ZZ98+CLOEiMe1Rt76uweGE8GSYRZI9eAvRd0ezVrXY2kVNL0v8APkuG9Wb724HdXIvsXU4WgqcxG9IVnqAJenULbyztQPOqs331L3Zvl/T0Db1l/F1/wAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">SA</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="4">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topLive__2U19Q"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="AG"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADcAAAAgCAYAAAC2COBlAAAMs0lEQVRYhbWYeXBd1X3HP+fcc+97972np9XW5kV43zFgCAVSKPu4JQ4hIQU64yE06UzdTCEB2mkSJoEJBFqHUGZCBxKYtHSaaQIdyIBpSsxmFxpjMMaLvEiWLNmWpff0JL39bqd/3KenJyPbLO1v5mo52287v9/v+zsi9cQdTJIwTdzxHN6ud1BeDm2YfFoSOsDyivzXVfeze8kNnJPt492C+uo7OeNOU+qigOBTHw6gATHzVODreFvMfFl9JgZn4i0kCMlVW3/Ah0Ezryy4nv3H9964NzV6MdZnZKsrv2dSTgOez9qW+j3ys3E5MxXNBFbgcNfr32TxoRdJyVg7ERNM4yyfCj9lgFH5JsdMAywDLDXz3src8qR6U2ldI40GjQAhkjX2+dQktU820kBH/ljxz3ZunvfYhT9biGGAnuFoISAIoOyB44X/WwpLSRw/AMcP5y0FUROEnllCrUEoFhmFA8pQU84TpgLtXopbfBYpPYH2P5YWgtOaQmof34w5/bTUF51yB8IA7Z2ySEDJhbxDZ0uCK5e3ccWcRhbNStAcMcm6Hj3pPFv70/ymN8XIWAHqY+G+Uw0VaJpNnT7oxgaVgTslo6GgnFvnlItdxO2P5zsp0fksGAYiYn+EmZZgeD79VitaREDnpxslADIFOuqj3Hnpcjau7mR2MvoRNhfPaeS2c+fQN5rnwe09PLVzAOJW6MlanoEmbpn9iUh8SHmpzKQYiKiNn8stmOJ8Fu2MUDFpzYKIQLsTIIyPrgsEh2Jzw9jxg6njfQHjeb6wrJUn1q+io94+Mz+gqynOkzesYXFzgntf7QZDgiFqRBU0GvrQXMsLFEG5MiagFBCMplegjLMrJgS6OEEwWqTpoScpvbuF3IubMdo6phQApIayVPpAvG0qt4lQYcYK/NXn5vP4+tXTMt+2oxneGBildzSPBuYnbW5YPIvzOxqqa+65ZAHD+TL/sK0HmuJT8kqD+Za/71yVQqlZTdVB7fn1+mB5qZDi7FdSgn98jOSt9xG56HIQAbnnH6vEUxjHGoEVlMnKhO6NtE6qFZ49UWDjurk8/serq0fuHprg7147wJa+UYKyN3kMeAEPb+/hL86fy6PXrawa4oErlvDv3UMczZYhZoHWGIbAkdHuF8c10pzIYE5kMMdTiFx2kdZ+O/IsFUJJ/GMDRNZeR/LPvwuAteYSzK7V+KNpavfbnsNxa7Y8EW0WBF4oWLbEBZ0NPLV+ZXXd8/tO8Ee/eJuXDo4QKAMa7DBp1MegKU7RMPjJG4fZ9Mqe6p6oafDtC7vAncp7JtprsiIHyyKOSrmJ0JiGIloYWyTdogrEaUo/gJQE6WFEtJ2mv30SzBDFiEgE+8qv4D61Axoq3hNg+w5H4rMZM+tAO+BrkIInrl+JqcL43NqX5qZfvRfWsYaapFSbKKIGtCT46fuDrGxKsLYtGWZ9qHoNDXWmONFkyX5LCtTza+8BIBufzXXbHly2orCVbKJlZsWEBK+IHivT9L3HMTrnTZu2//BGcr/+R3Qxh7ATiLBw0hudDSoCXh5yZW5a2caFc8L4mSi6fO2lPaAkJCJhLZuJNKAECItNvzsQ/g1hQrGMcF5rbCn7BwpuJgDU5z94BgDPitFyYu/yohnjtKBN+HhHR6j70+9gX3PTR6bVnEVE1l5JcfuzGIkkhu9CIPRhuxOkKXBdMAR3rOms7nn83X76T05AS+Kjis10gwwgZtbkhOnFPGmZB3K+R8HXqFXBfgCkjjDhpueWMJkx4gyJP3gUa9mlJL9+X3U4+/MHiPzBeqwVFwAQu/Imim88C2hM36csbdFX1w6+B65LZ0OMyzobQ7ECzXOHTkLEhKBGwkm0kiudGV4LQm+LSjHXmhbL3L8oYZPzfVS2JAGB8PUs1/UXzhhuhoEeTyFjHTR952mEZQFQevNF0j+8j+b7I1XlIhddg5p/Ln7qAFbSZsRI0mfOBlzwAlY0x6mLhfsPp/McGi2GV7KWPJ+YZXLjqhYiUuDPANcMIRAaXhjMkCq64fXEYF209MG6uEPG0yg9ay5YFsHYaJcuFlqFcQojIdBOHm8kT/N9z6C6lgDgp4YYe/xbqE4o7XyVutvuBiERlo196QYm/uX7mHGD42YzvXZz6DkN8+NW9ehUyaXkB0y7KgIouVzcXs+zXzz3DG4D1/F57WfbSDkeRE2ihnQ8xMBA0aEQCGSk3ibaVIep9ELtlkMUUUtS4x9NUfelbxG79isVy7pkHvwaXqoHtbAV58PXKb+zpbolds0tGE3tGPkch+1OSjIO2q3KPkmzbAvLOLWzE+D5XNJad0bFAA5mCvSNF8NuINDMskTfgB8feDmb5M18HbI4MESh/zjOcHq50Hp6ECuDYOg41vLLqP/LB8KxwGds813kX9qCjFoEJ7P4Iy65537OZGSreUuw1lyGyGgG462gLCAAIRjMO9XjFzXFWN4YCzuBU/giJR8O59g1nOWD4Szbj4/zen8Gtwb99GTyYbFXBuiAhGn2L26IF5bXx1haH0N5wylQJuQmlkhV4zUpCTLDQEMYZ9FYOO47RM6/hNkXXY6wY2EicMpgRkH7IMJGNH7FzTiv/IrDsfZKwIdC707nyRVdErYJUnDv57r46i/fA8+veoBElEd2DfLwzqN4AnTegVyZTVcs4bI59VURf7JzIATOUgCKDuX3rDNHSU8aObG0A7SW5b3DSzytEVpUsJ9DkC7SeO8TqK7FU0qbNvY1t571ykTXXc3YnKXsceMV5oBlcGw0zytHUnx5RTsAN6/q5H8uz/Lj17vBtiAWAUHYw5W9MGNGFA/9ySruuWwhRgX9/OCNQ7x28CQ0hgYWhiQm2T2YK5D1Q34KQxE47jlevrhUGBXALMHrGSKx4U7iN2w8qyIzUqKB8fUb6dkTAd8Nz1UCpOCht3v58rK2qtKbr1nGqpY4/7Sjn9+PF0M4pSTtyQgbVnfw9Yu6OL8tWT36F+8P8P3XD4ZlAACNKXykSuz/XSFBUAliFR86QkHGF2nfjwshw3p2YgCz63zqN/2wemDpzZco79uOrEucBlQHBHmX2PW3Yc4PM2rqilsZO7kLirlQsQBIRHlvMMPfbD3Aw1cvq+6+/by53LK6kw+HJkjny8SjikWNcdpP6e02/3cvd2/tDiFXRIXXWEPUlBPtMWswIiVepXSo5xZvYk3PS0vaSjsoxZMEuQxCNtP03afDmAKc3W+T/t7NaL+AsI2ZlZMa51hAkBuj8duPAXDIrcMhBiKgmu+1hoTNI2/34vkBf3/1MmSl/ESVrMKyU+ngSI773zrMv+4ehHgkjLWawh8Xoq/oen1lIQkmlUu3L6fU/fIC6Tngl/GHsjTd+xjm0rDG6FyW0R99A5Eoo1rno0+H/RBEEymcXb+FiTQkm+k+mQbHAfuUJlRJiFv8+O0j7Bia4Jvr5nHVOS00xaxpy0qOz96RLP+29wRP7ztBZqbnBQEEAU2R6OGUp71y4FZtr+44/Ai5sf1Lc9EEwdFhEtfeTvwLt1cZZB79a7xjezAXzEO7Z3pS0YhYEvdoN947v0Vdewv70pUnBSGmI3ytQ0TREOOtwQxvHR1lcUuCC9qStMcjCAEn8w4HRvO8O5IN31eiVpg8JvfXUqBpiVrd7fEo2RoZVWE0H/WDYEEwMoK5YB0Ndz1ancz/x1MU/vMZVFcr2vsYDyrKQtgG/rbnEdfewmCx4qWqLWteUnXlRyICGg6NFzk0kq2ZIywNthlm0eB0r12AlDQJ72A7DnFRo5zn6k5/eGieEWun5cHnEHVhHXEP7mb8iXswWuvAOEMrUkuBxmhuQe57jb53d/BepA0ay2GfhgDfh1IOdDBVtCcFts3wO/XBVTMdVM/AE2Gwyi53n2cVyBhTYECJeN0CPzNhJ754NyKWxDtxDJ0dJbN5E9rIY9R3nuU61pDWoCyCcpb+X/6UlvhNWIxjSDADj6ydLA9Gm3uR2kUz/dn5VPk/7qup1narbRwf9GNH+sb9aUhOicLEKllfT/n9LRTf/HXYHvkltB7HmN3+8RWbpEAznmhi8ZGX9Qs9r4qT3SESicsiXtesbRs2/mhDPtFWxslYp+0bPxEJo94ynDorUk45QRUvAKggX1iE9gkKx9GiAm4jBsJMVkLkkwvgBwK7zhQrLizREHHp+73QeVxxnhrb88/yN/lvBDeTRnnwCQ13On4aDDS2nO5u5Z04/nnteqAU6PCmaE+DW/pMDB0NnilpXAOB7Yn9b/iMrlrZ+6WFY2wb2sej3iXAKP833puZlGpv3y9mzx5DCOfsyz85aaB1rrDsZb5TpLx9eEeaO8pbeKG1nV67A/zC/wdbAP4Xl3poFwxiM4gAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">AG</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="76">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topLive__2U19Q"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="GPI"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAAlCAYAAADFniADAAAEYUlEQVRYhc3YW4hVVRgH8N+czqiQ2UgJ6mAWYaWWgpmVZPnQS3Sx0lKTLg+lhfWgKAaWhSQURVFkZgUVdFFSzC5UFCFdLLIoJbQLhlNYhlKW083J7OFb271n5syZc6YR+sNhrX32t77132t9t7UaVm08VZ04DuMxEadgGAaiEW34Gd/hC2zEx/i2ngka6iB1Lq7DBRhcxxy78Cqewnu9ReokLMZMsRoZvsdWbEMr9qf3AzAaJ2NoQb4Nz2MZvqo2YbkbQlfhERxdULwOa/B+ItYVhuAcTMPlifA1uARz8VxXA0tVlN6LZwuEVglbmo4XuiEEPyS56Tg9jYempPfuekmtxILU3yW+dCa2dEOkK2xJ46clfbAIj9ZK6n7MLig7S2xZb2Bt0pd93ByxI1VJzcS81N+GS9HSS4QytCS9mbEvSPMeQtH7TsRn6C+WeIKIN03Ci36vY+IG/IOfsK8LmeH4UISXVozFN7T3vrsSIbgxEYLrcUcaeLBOUj+KFXlNeFtbQaYlzfNimneZtGLZSp2Bj5LwWmGQRbKLayRTDRuxMLVFrMHU1J+ATdlKzU1tG5Z0GPRran8TX/UH+nRD4GD6HYtxYvsn4m1ciZcKsktE7GrETRmpQZiSBNaLKF1E5gw7cLXatzBDM27A7eiLZ3CmcCRpvpdF2LkMi0oi6jYlgdVVlJdxVJ2EYCfuFNlB0vFQB5liYJ2UkYI92FBFeYPqGaA7rMby1D8f5xXebUjzw9klkThhc+FFrWgWCXtYh98I9Ksg/wT+Sv0LC//vxuepP6KclNDZlmrBY5gkdwbC5o7EdhFONhfebRUh4rT0MUVswWQcX5bb0y89INUsbKSSrY0XLl4ktV8UgXReydbUNpVxRHr4uwekMkWf4k3h1iURDFt0dpx+wtszgkVk8zeWcSA9dBd7KqEhta/oHN8qYZx82zrm1CxmtpWwNz3013MMqFHuFvnOfNLhXTb/3pI8x43+D6QOdC9iHmak/h6RD4sYk9odJXyZHsaKtNATdBXl+4no/bSo0zIsEck6wyBk5crXZXHCmJ8ITRYJsl4yM5LSvsLQs9x3jIiDRXt9Eis66JksX5APMlJ7RWiYXiepgaltTr9q2CmqzAcrvMu2dS/eLYtouh7XisQ8Su2BdAP+FMVcEQ3CzvYl/ZvwusqHjVG4OPXXYXfmhssTqUYs1b6eqoabxXbVYuhdYan8PLmCPMFukmfqqbioRoUH/yOhKfICb1Xi0S7r3yaP0I/Lc2KDw4Nh8iNWq0J1WyS1XX60GiziSEl+OdGb5E7AG/I7idnSoaEjKeKs/0DqjxYn3JG9TGq4KKszvfeleQ+h0l3CfFF6zBYlaoZ98pTUU0zFw/IVWikOE+3QVSU5R3xBEUPEdVBPMEasxpoCoXvEEasTqpW3CzFLXmcNxlvCS67Q/pqnEoYmudUi+RYD5Czc2tXA3r6f6iOy/UgRFHt0P/W/vMnr7tKsiHfS77Dfef4LtTMI5Eq5HBsAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">GPI</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="27">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topLive__2U19Q"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="DG"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEMAAAApCAYAAABupZRPAAAJN0lEQVRogc3aebBWZR0H8M+9XFC8CWiCAlpmggI2ihqamuBuaanlkmmWkjPlpNY0Zcu02JS5peaSpShmy2RZNmVGZWqGSG6YWaKWqSiIKG4oLiz98X2O77kv7+VCXITvzJlz3t95zrP8nt/+vG2TT93ZWoBJOBf/XJOTaF+Tgxech4n4ETZckxNZk8zYDL/ByeX3WNyGd62pCa0JZozEGbgX7yu0n2I23o5puAw7vNET61jN/a+Dt2IMRmMC9kJbef8YvoCfYEtcgj1wXLluxg3CuH/gYby6uia7Ophxhex+B4ZgKPo1tXlUdv8CPFNo/8aeOBYnitrsXi7ChNl4AgvwCj6DB3tr4m297E3aZXEDWrx7TGzC1fgdnu+hr/3wCbEhG3fTZhfc+n/NtAV6WzL64mlhxl0y0X/hHhH1Z5vavx8jcBOWYpvy/X/xh3LBKGxf3m8oKtSBhb05+dXBjPXL86fx127adWIy7sd12FXc62w8jmGy0DmYLioxQ2xLP3ys9NOr9qO3mbG0XD31fQEOw+fwERyJs0WaFogULcAh2BqLcF/5dksNG7RWS8ZCsQWDy9UdxmAJzqrRThKDCzNxIS5q8W0VmL0qEtNr6O04YwmeK8/DavRObIHtsJGE3c1jD6k9by3MmF6e66j6fUbDE/UKVodrbcWMgdgWm2Nv8QIrgp0s65ZHlPsTellNVkcE+kS5b1mjzcY1kow9iUEtvrtFjGQdi8RzjKjRtij3p1Z5pk2omLEvLpYdG2LVmDSl3MdaVvIGSQTajEfFzW6P02v0DpyAK/HZQhtV7t15qhVBu6xzR3wXH6gGg7vxQwlynsNcvCA7swgv1zpqw2uF3lauRVisIRVEJUZLjLGJuNpxkqA143TML89fxFG1dg+LdCyWaHa7Qh8jBnZ4WVyHhjfrEDdfeTbojz6l7cDCjEFihM+rM+NJSZKm4N2lcW9gnDBjPE6p0efibxJc3SXJWR2PaDBjBNbDnTioLIq45lXFXdgf8+gqxi9JHjAex5R7H1252x2WSrDV7E7fI4Wb/jXafJGal7VGp4YqVFi33He3LJ7WMNptLd7X0SYe7zZcLpHva9XLZp3evAx4oQREK8KMdhHhNjGaH5ZEizBjkESOcKa41kMlbV/S1FcnrsKba7QncUd5PqRGv0Ki2PtETfu26K8ZFTOGipTNkpgGyzJjthi+b4gIL9Azt/uVyRwsccF0ScrOEIn4uESXV4gavlfcbp3Jb8ERpe3Ipv7PF73eB28rtNPFtpAk7ga8SffSVmGpSNmI8s059ZfdZa2XidFaGeyD62u/75eFPayxiDr6SszxIdmlVnZqhngY+C0OlA0bXmuzvdiTlcHPJAXogu6Cromym/tLNarZMpPdXSD62qarJyEGcqSo3kfFW8E7cXTpu1kK6pghDCae48Dy/PemdvNllzvEbg2SZK8+38oD3iClxntaDdgdMzrLAu6RYssSsR9Vx4slB1lHLD3LMqOern9eRPgYUZPl4WWRzC9rGMZzm97XMUc2r03ylRdFyto1GFLZknHitmdpEcp3x4wXZbGV4VtY67itPO+Ow8VYLhWRrxdahtaeR4to9oQfiM+fWaNN1JAQ2KDpm6pu2k+M72licOvS3Kbh0c7STU6zvNzkNOH6qVoHSoPLANUgdUM7UEp4K4JXRPQfKuPVaxS74tKm9jtJXfWR2riVveks82pVaZuLr+P73U2kp0RtMv6CrcR2VKqyRGqWlf9fKnpaYZJGqn2KSE19d4moXoBfCiOIR1hcnnfAn2SxfxRXfIUwf1Ktv1kSI60n0jFLQoN1NNRjimTKy62X9sSMPlJ8GVIGeKEMsqgMun6t7Z6iXidit0KbK7HF5DKRagdnatQ06lhQ7odKUNRfosMjxVB+SYzu3mJgz9HVhnSKdJ0tavJKoR0rEvU1y6mO9cSMxaKH90nCVMeEMjDZvcub3r+KD5bnecKgX4mP31yOBSZJXFJhvBwqVcHVg5LAVXnLQXJ8MFhylCubxpyHd0iY3YxxeigTrkh2OlNqEfc30TslmmyFGyXHuaVGu1cY8nNRr4licKcLU+6Q8LhixC9K+7oxnVn6naI1Bmt4twqPSIX99m6+eR0rc1TQIanudsLhK6UKtZvobBW6TxV/vjwcLllsq6PEWyWtvqqHPsYLYzpEbfuL6kyXgnGnVOavtoJFoN4+N1lZ7Caiv43ENNdatTrFKmF1Hy/2hKnlWiuwNvwlYa1BnRkbaMQNbzQGSDLXqjb6hqFDjM0eYr3HSInum1I06SfGciOtC7DDCn1VTraOE9c8X2xIh8Z/NlYWlTFtt2wMU218lVuRuGdjCc/ntUtBZrQYrytLZ9eWxutKPeFgSZw2KfR9JIc4TAo4FQ7RCLiIqzuqaVITxOeT6HSsRKHXSBA1Q+N4YKRlGbOfrpWwYWKEiVu9RKNOerrkLhW+UtYCB0j9ZBs5wJrYLjv7QGkwRypcT0gk+XyZ0CSNKJSI81Bxgb+vDXaCZKYVXpMQumJQn7LgoeIK98VXNTLcx0v7audGWDY3OlTXfOVkfKs8L5CNraRitLj5AYU2QDLhHWSTfiyB4Jm4s13Ep6+umCohrzLRXSRHqSK+p0VqDtDg/ITawNXk1xNmHV9+jxMGd4iNWqxrBjleJLDKgdoLc04qv/uI5AwvC1XmcVt5t0TKhAtFHc4rc76x9u0cKU/cLelC1e9DlW69XhQt2Ewjelwoonm0FEaIGD9bFlK5571FxTbRqCLtXBbTt9D6C1PHlokM01AZIjEnlvlsJWr3cBm/Q6OIdA4+JfnQTcLg6j8cSzVqGaNENa4X1Z8j5cw+uhavj8W326X4Wj/PrP4zcb4kZcMkwZkm5bWBGn89mCZ/L9oZm+J7kiYfLxHg5mUB35HayL2S7Y4SqbhUstGqtPeS5BdLywSnyeHWHDlEWiSVsktEWj+JXxembFX6GK6xQSMkEz5FygRTRHIvLuvcr7TrwIZ9Dt5j02Glg6fEm+wohmdeYdS2EtZeV+v8gTL4YJGSMXIqdpvs5AiRnCVlYX8We3BLWdBbpCx4s3iiw0u/oyQCvV+M9EWSCc+SBOw/5dupssN3SzI3SiRmphjP28v89yp9zRfp6F+e7yj0I2Rjh2Lq/wDPwi0Oqot6kAAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">DG</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="39">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topLive__2U19Q"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="PP"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAO4AAAA2CAYAAADAg6VgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAAM2UlEQVR4Xu2dd8gtRxnGo4hgQYkoGrFxrUTBPyLYFSW2P2KDqKigqARFbLFcRRAR0YiCokG9GsWCRhMIoghq7EY0alQsaCSxt1iuEEusXJ/fycx+c2afndk9357c72Tnhd+e3XfK7s7OszszW84JV519uyEeIZ6d+Rwni9My31Y4duxYo9EQViCBR4lj4nWJL+d64grxrMS3NdwONBpLxAokcHuBcOFI8OV8WhB+o8S3NdwONBpLxAokgBj/JqJ4zxNp+P0F/t8nvq3idqDRWCJWIAmXiihc+LyIYczj+0bi2ypuBxqNJWIFkvBJkQoXzhGEcaVl+Ztheeu4HWg0logVSAIDU7lw4b0iXo0vFy7t7LgdaDSWCIK4qzhdPFjcSVxXRLE8UOSijfwv/P5HnCg6gW0LtwONxhJBEPcVF4ooyN8JBqIeJwj/gYhhQzxXrIlsG7gdaDSWSCqMh4nviFSQXxL0YVNfzp/FWSLNayu4HWg0logTyEuEE2jK98RrxIPEjYXLZ3bcDjQaS8QKRJwqnGAZZeZRSJdm67gdaDSWiBVIgMGqKFiazPcTLl7kluLe4tHiaeIZ4onioeLOIh302gi3A43GErECSXiDODvzpTxSvFV8W/xLpFfnnF+JC8RzxG2Ey6+I24FGY4lYgVS4oTgsfiKcQMfALaQPCa7Qbh0WtwONxhKxAinAa36/FU6Mm8JVmFcD3frWcDvQaCwRKxADwrpYOOGV4PHIJ4uHCG43cb/3fOHivki4dXe4HWg0logVSAaDTfEpqbH8V5QGsxis4kqbp6P57OKvcDtQo1mz3FSXzhC8qkqX71Bw75YhiAIPF7m4xvAK4fLL+YDI03JFdnGtMGs0a5aa6hEPC6X17ajYPfFqo4fgipnu4BRG9VkDnxV5+veLXlwnzBrNmkVTHeKZ+ryuweEQZXdMG+24lfi3cDs5Bvq0Ll8HL+z/U+R5vEqsxXXCrKF0nGF5FrsGz2fTdDolFI01hc+a36amfA+F/FkXV4207L4laAqeEaI3k6k8Tgnlk3NWiLI7po128Eij28GxUJlcvkN8Qrh8+MpGF88Js4bSsS0u7xK8qnh6KKI1k3/W/Kaa8kGwnBTcehyIeveuKFsylQUntbyMTg3Bu2Pa6JyXi3zHNoHRZJe/g/d7XR5/FF08J8waSreJ0CK9Ci/frPlNMaVnUCW/uo6FCntiyGqxRhkIWiOUI2Uyywn1GjdteMrNhDvom8KIdL4Ox2+ESw9dk9kJs4bS7UdosHZgtTxrfmNN6RCty28KTbzXFtOBTHm7cAd8P7xN8IJ+vi64h7hIuHQRbi3xtJYVZg2lc0LjJYochEGTNo97eSiqlWl51vzGmNLwoYM8nwjroN9Nf5d4/Jaa0heGbEeb0myln95szyaXsRJEeD1v6v3aKXxFvEO8VvD8c/zY3BheLKwwayhdT2hh13umMJpRTmxdH0jzs+ZXM8UlD9c8xjc4+KQw+sKuPwfFQSuFs05OAPm2s06amavt1y+DPZRHSm+gB18Wpzt5aJ715NsZ19O7TSMf28ZJMU/DtnbbNmQKH9yWaKU4mnfrjts7WnyKWypjTrzlMtYkMkdTbFtcJqwwaygdO7qW36rkBkzhFOZafHwhePb8aqa4VIg8PQe3WkkUh8rhxDt41VcY9YD88zQ5VG5aFrnfCaFXZoITizup5aRlTyUek2ZwlFhh1ePn4oihssypjlArzv7LWJOIu596kDjZCbOG0k0Vmiuo/Qi3mF/JFI/K4g7wlCs2lZ2TR06vryvf1JO3q8hjhTtGBBG2l/0YU9kjVkDybyrcSdsbsuqZwuYpY02APqS7l3qQONMJs4bSTRWaK9j9CLeYX8kUz/Vte8KYw5TvVGEMMVa4U5kinEjvBCffpsKdimvmz1fGmkD8V4IUHlvkhfinCyoffdOvihj+dUH4mE/dAG8WET/+bQm8SzxJvCDxRXhvlw/WfTksn+uEWUPppgrNHbRuJFjzs+ZXMsWjqZSnHSX6qaZ8hypr2t+iBcDJZCguTBEuzV7q1urqr18qtusapFDxSbMShn5ji8LFPY84qclXPX4uToCTR1oX4kMwLu6REK0z+eYrY02AP+3KA/lDrxieEkeeKeDoy9PmfFzEuOl/En0m+OAjwQcMYkU/L+Dju8QJs4bSVQ8UJj8VwI3GHg1RVqblWfMrmeK6g2ebyfgn0vWRmRf5eqA0+DUksLHCRYD21pT8Q2Igje3by+9aNqNEGYI6c3EEJ5kp25vfjZi3jDWBVyfOCN9bJoyr3kvF3cMyEP6FMH+HsFyCV/piWkifzHph8J2U+G4SfO9OfL92wqyhdO4gTGHtCqflWfMrmeK6dQ1VnjxejU5gmncVr9okVxw3UDRWuLWRbZd3ceBH4a45vXai03JvW0JQZy6OmLy9IWhlWp63jDWBNyfOCK/eEfbdxBe/6MiZ7/thvibc+KdgfHMq/qsfzeY0zg0Efj4FyyAZ83zDKo1zpRNmDaXbj9CmNHfG0MuvZIpfrWTR8ngjSIXr9qnanFecUZURXxYHiqPiCndXm+I2Kdxtz1zC3WR7u3Vrft4y1gT4blQeeBdBGE1jvnrxUXH94LtKxP8Mqgk3/r/uYwUbzzyDYTxYEeO8SeBHrLcI87ybm+bzdyfMGkrnCqwGJyZ7ZZR/1vxKpjRuXUNN5TxejaJwQ1DRFI8m91o6MUq4IWjQFKcqwtwUvjXhhqBBU5ziujU/bxlrAm9MnJG7CcLyrzPGvyX5WFiuCfe2gnjvCcs3DctpnxbolMd1pP3gyFEnzBpK1yswA80R4nHW7AZLnIV4Lo+U0fmVTOnc4JRtsslPxSmR55MKt9jMGzLFa8INpjjFdWt+3jLWZGilUbgRBPdU8Q9B+IcF/pJweZyROOkz0O8MvgckPoj/AgicFNIwuMwJs4bSTT4IJZs7v5IpbzfgMqm5jSmNGxjpRlw1v9E+KV4TbjDFqQl33jLWBJ6SOCNxcIq3hej0R8FGaDoTXhIuo9XEIS+usLwF9MrgA97+iXF/Hnzwl+BLucgJs4bSbVRgQzZ3fiVT3rRC1tYVmPTFBsV3/a/uyq353j6JokgwxXGVtQl3j6JwxeZlrAncM3FGYh936ImqKFzuZblwPsFa+3uStInOSHP0/yL4Us5xwqyhdJMPQsnmzq9myt+JjhPpqOa34rkzdn6Ly1WO6pVdcdwobhPuHqlw5y1jTYB+LAMoaWAU7gcTX8rQFTe+qHCuiPnzj4D3EXxHmU/ikAZ/KnpGr2P8nwVfyjOdMGso3a4Ld+jEyAEtXnkVjmjz4wr5La5N7jG6ighNuHukwp23jDWJIMQ0MIrrfYkvJRUm92BvHX7jh9LvJQhz/TSawjHtp4LvksT30+BLOckJs4bS7bRwMa1j6AACV2SetFlVEn4FZd7bzkBPWBj+LF6EdXcnCOaFe7Ak0oS7R3XdgellrEmEl97TwJsL/OlDECl8oTFNH/mT+GWy/GPh0p8mCL9jWP5hWAbeBkrjfk1YYdZQuskHoWRz5zfWtB7XZJ7KYBNb/qErwlSacPfI1z1fGWuSwn/dxkCugDwd9YfEl8LAEs8RM3Ic4Z1bwviiBTt/cVh2cNX9ovhcWObjdORHHvkLD08QVpg1lG5Woc2d3xTTutztobGw3cV+scJd5Svhn+rJDF8WZ5HCxeSbWsbFPm7kTJFHOt5cIVbb54RZQ+lmFdrc+U01rY+msBPMEJMe/lBc17Vx0JQb9fYSvizOYoWLyT+2jGllFW8HRa4j3K2Y48nqagtOmDWU7lol3GhaL6LhwLrBJ2A7qUyTH/5QGpp0Q30srgCrARX9+kqVGb4szqKFiymMfuxQ94cyXj0Oqd9RwgX6nnnE4wVN7W7bnDBrLMFUNtzv5QBD9csYUyzJFzZ6AqxZ2UplHHy5Lo6sBGHgqag88vGAD7N32+WEWaNZs1021Xsn3MOdKAw/EnmCa5I46tzhhFmjWbODYqrDNMFTxnyfyj+vrskQPF8893/hjuV5ordNTpg1mjU7KKY67EaIS/1gxhrcGMahNWEYeKAiv6e6bZ4v3LZYYdZo1uygmOqwG8AC/GtPwWmZkWcn2qtfDtFMDV5+j083bRPu3T5euG1Y4YRZo1mzg2Kqwwwi1m7lDd0liFw9+KiZsbxM/FW4zPYL7X2Gx916O5wwazRrdpBM9Xio+TuGveeatTAFRnn5kJvLdBP4igZfeXTr6uGEWaNZs4NmqsuI1/V3h0Do6y8jyLEJ/BfQ68Um/V+axBeIxwiX9yBOmDWaNTuopjpNP7b0MgHNavq//fvncu4XvmTBN5jPFzzfzOdUrwzwwsGlgqbwWwRX17V7s1NwwqzRrNkumOo3V+HBBzHW7YQT/g+QNKkFjb6oDgAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">PP</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
                <li><span>|</span></li>
                <li>
                  <a class="DefaultLayout_menuA__Eilgx">GAMES</a>
                  <div
                    class="DefaultLayout_menuSubList__mx2Ni"
                    style="">
                    <div class="DefaultLayout_bg_menuShadow__Rjze1"></div>
                    <div
                      class="DefaultLayout_subList__-8hVJ DefaultLayout_subListTwo__P6WWb">
                      <div class="DefaultLayout_subListDiv__5oE8l" id="39">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topGame__6ZwJw"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="PP"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAO4AAAA2CAYAAADAg6VgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAAM2UlEQVR4Xu2dd8gtRxnGo4hgQYkoGrFxrUTBPyLYFSW2P2KDqKigqARFbLFcRRAR0YiCokG9GsWCRhMIoghq7EY0alQsaCSxt1iuEEusXJ/fycx+c2afndk9357c72Tnhd+e3XfK7s7OszszW84JV519uyEeIZ6d+Rwni9My31Y4duxYo9EQViCBR4lj4nWJL+d64grxrMS3NdwONBpLxAokcHuBcOFI8OV8WhB+o8S3NdwONBpLxAokgBj/JqJ4zxNp+P0F/t8nvq3idqDRWCJWIAmXiihc+LyIYczj+0bi2ypuBxqNJWIFkvBJkQoXzhGEcaVl+Ztheeu4HWg0logVSAIDU7lw4b0iXo0vFy7t7LgdaDSWCIK4qzhdPFjcSVxXRLE8UOSijfwv/P5HnCg6gW0LtwONxhJBEPcVF4ooyN8JBqIeJwj/gYhhQzxXrIlsG7gdaDSWSCqMh4nviFSQXxL0YVNfzp/FWSLNayu4HWg0logTyEuEE2jK98RrxIPEjYXLZ3bcDjQaS8QKRJwqnGAZZeZRSJdm67gdaDSWiBVIgMGqKFiazPcTLl7kluLe4tHiaeIZ4onioeLOIh302gi3A43GErECSXiDODvzpTxSvFV8W/xLpFfnnF+JC8RzxG2Ey6+I24FGY4lYgVS4oTgsfiKcQMfALaQPCa7Qbh0WtwONxhKxAinAa36/FU6Mm8JVmFcD3frWcDvQaCwRKxADwrpYOOGV4PHIJ4uHCG43cb/3fOHivki4dXe4HWg0logVSAaDTfEpqbH8V5QGsxis4kqbp6P57OKvcDtQo1mz3FSXzhC8qkqX71Bw75YhiAIPF7m4xvAK4fLL+YDI03JFdnGtMGs0a5aa6hEPC6X17ajYPfFqo4fgipnu4BRG9VkDnxV5+veLXlwnzBrNmkVTHeKZ+ryuweEQZXdMG+24lfi3cDs5Bvq0Ll8HL+z/U+R5vEqsxXXCrKF0nGF5FrsGz2fTdDolFI01hc+a36amfA+F/FkXV4207L4laAqeEaI3k6k8Tgnlk3NWiLI7po128Eij28GxUJlcvkN8Qrh8+MpGF88Js4bSsS0u7xK8qnh6KKI1k3/W/Kaa8kGwnBTcehyIeveuKFsylQUntbyMTg3Bu2Pa6JyXi3zHNoHRZJe/g/d7XR5/FF08J8waSreJ0CK9Ci/frPlNMaVnUCW/uo6FCntiyGqxRhkIWiOUI2Uyywn1GjdteMrNhDvom8KIdL4Ox2+ESw9dk9kJs4bS7UdosHZgtTxrfmNN6RCty28KTbzXFtOBTHm7cAd8P7xN8IJ+vi64h7hIuHQRbi3xtJYVZg2lc0LjJYochEGTNo97eSiqlWl51vzGmNLwoYM8nwjroN9Nf5d4/Jaa0heGbEeb0myln95szyaXsRJEeD1v6v3aKXxFvEO8VvD8c/zY3BheLKwwayhdT2hh13umMJpRTmxdH0jzs+ZXM8UlD9c8xjc4+KQw+sKuPwfFQSuFs05OAPm2s06amavt1y+DPZRHSm+gB18Wpzt5aJ715NsZ19O7TSMf28ZJMU/DtnbbNmQKH9yWaKU4mnfrjts7WnyKWypjTrzlMtYkMkdTbFtcJqwwaygdO7qW36rkBkzhFOZafHwhePb8aqa4VIg8PQe3WkkUh8rhxDt41VcY9YD88zQ5VG5aFrnfCaFXZoITizup5aRlTyUek2ZwlFhh1ePn4oihssypjlArzv7LWJOIu596kDjZCbOG0k0Vmiuo/Qi3mF/JFI/K4g7wlCs2lZ2TR06vryvf1JO3q8hjhTtGBBG2l/0YU9kjVkDybyrcSdsbsuqZwuYpY02APqS7l3qQONMJs4bSTRWaK9j9CLeYX8kUz/Vte8KYw5TvVGEMMVa4U5kinEjvBCffpsKdimvmz1fGmkD8V4IUHlvkhfinCyoffdOvihj+dUH4mE/dAG8WET/+bQm8SzxJvCDxRXhvlw/WfTksn+uEWUPppgrNHbRuJFjzs+ZXMsWjqZSnHSX6qaZ8hypr2t+iBcDJZCguTBEuzV7q1urqr18qtusapFDxSbMShn5ji8LFPY84qclXPX4uToCTR1oX4kMwLu6REK0z+eYrY02AP+3KA/lDrxieEkeeKeDoy9PmfFzEuOl/En0m+OAjwQcMYkU/L+Dju8QJs4bSVQ8UJj8VwI3GHg1RVqblWfMrmeK6g2ebyfgn0vWRmRf5eqA0+DUksLHCRYD21pT8Q2Igje3by+9aNqNEGYI6c3EEJ5kp25vfjZi3jDWBVyfOCN9bJoyr3kvF3cMyEP6FMH+HsFyCV/piWkifzHph8J2U+G4SfO9OfL92wqyhdO4gTGHtCqflWfMrmeK6dQ1VnjxejU5gmncVr9okVxw3UDRWuLWRbZd3ceBH4a45vXai03JvW0JQZy6OmLy9IWhlWp63jDWBNyfOCK/eEfbdxBe/6MiZ7/thvibc+KdgfHMq/qsfzeY0zg0Efj4FyyAZ83zDKo1zpRNmDaXbj9CmNHfG0MuvZIpfrWTR8ngjSIXr9qnanFecUZURXxYHiqPiCndXm+I2Kdxtz1zC3WR7u3Vrft4y1gT4blQeeBdBGE1jvnrxUXH94LtKxP8Mqgk3/r/uYwUbzzyDYTxYEeO8SeBHrLcI87ybm+bzdyfMGkrnCqwGJyZ7ZZR/1vxKpjRuXUNN5TxejaJwQ1DRFI8m91o6MUq4IWjQFKcqwtwUvjXhhqBBU5ziujU/bxlrAm9MnJG7CcLyrzPGvyX5WFiuCfe2gnjvCcs3DctpnxbolMd1pP3gyFEnzBpK1yswA80R4nHW7AZLnIV4Lo+U0fmVTOnc4JRtsslPxSmR55MKt9jMGzLFa8INpjjFdWt+3jLWZGilUbgRBPdU8Q9B+IcF/pJweZyROOkz0O8MvgckPoj/AgicFNIwuMwJs4bSTT4IJZs7v5IpbzfgMqm5jSmNGxjpRlw1v9E+KV4TbjDFqQl33jLWBJ6SOCNxcIq3hej0R8FGaDoTXhIuo9XEIS+usLwF9MrgA97+iXF/Hnzwl+BLucgJs4bSbVRgQzZ3fiVT3rRC1tYVmPTFBsV3/a/uyq353j6JokgwxXGVtQl3j6JwxeZlrAncM3FGYh936ImqKFzuZblwPsFa+3uStInOSHP0/yL4Us5xwqyhdJMPQsnmzq9myt+JjhPpqOa34rkzdn6Ly1WO6pVdcdwobhPuHqlw5y1jTYB+LAMoaWAU7gcTX8rQFTe+qHCuiPnzj4D3EXxHmU/ikAZ/KnpGr2P8nwVfyjOdMGso3a4Ld+jEyAEtXnkVjmjz4wr5La5N7jG6ighNuHukwp23jDWJIMQ0MIrrfYkvJRUm92BvHX7jh9LvJQhz/TSawjHtp4LvksT30+BLOckJs4bS7bRwMa1j6AACV2SetFlVEn4FZd7bzkBPWBj+LF6EdXcnCOaFe7Ak0oS7R3XdgellrEmEl97TwJsL/OlDECl8oTFNH/mT+GWy/GPh0p8mCL9jWP5hWAbeBkrjfk1YYdZQuskHoWRz5zfWtB7XZJ7KYBNb/qErwlSacPfI1z1fGWuSwn/dxkCugDwd9YfEl8LAEs8RM3Ic4Z1bwviiBTt/cVh2cNX9ovhcWObjdORHHvkLD08QVpg1lG5Woc2d3xTTutztobGw3cV+scJd5Svhn+rJDF8WZ5HCxeSbWsbFPm7kTJFHOt5cIVbb54RZQ+lmFdrc+U01rY+msBPMEJMe/lBc17Vx0JQb9fYSvizOYoWLyT+2jGllFW8HRa4j3K2Y48nqagtOmDWU7lol3GhaL6LhwLrBJ2A7qUyTH/5QGpp0Q30srgCrARX9+kqVGb4szqKFiymMfuxQ94cyXj0Oqd9RwgX6nnnE4wVN7W7bnDBrLMFUNtzv5QBD9csYUyzJFzZ6AqxZ2UplHHy5Lo6sBGHgqag88vGAD7N32+WEWaNZs1021Xsn3MOdKAw/EnmCa5I46tzhhFmjWbODYqrDNMFTxnyfyj+vrskQPF8893/hjuV5ordNTpg1mjU7KKY67EaIS/1gxhrcGMahNWEYeKAiv6e6bZ4v3LZYYdZo1uygmOqwG8AC/GtPwWmZkWcn2qtfDtFMDV5+j083bRPu3T5euG1Y4YRZo1mzg2Kqwwwi1m7lDd0liFw9+KiZsbxM/FW4zPYL7X2Gx916O5wwazRrdpBM9Xio+TuGveeatTAFRnn5kJvLdBP4igZfeXTr6uGEWaNZs4NmqsuI1/V3h0Do6y8jyLEJ/BfQ68Um/V+axBeIxwiX9yBOmDWaNTuopjpNP7b0MgHNavq//fvncu4XvmTBN5jPFzzfzOdUrwzwwsGlgqbwWwRX17V7s1NwwqzRrNkumOo3V+HBBzHW7YQT/g+QNKkFjb6oDgAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">PP</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="55">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topGame__6ZwJw"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="JDB"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASkAAAA2CAYAAACbbm94AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAAbvklEQVR4Xu3deXxU5bkH8DcRyMaSgyzKziABFREYkKW31V5HW0WrtM1ta2trrQzYqlWv5dStWEvbKeBS9xGxLMoySCCJJMghAdGCy0TErtd2qr1WLSIjDiNLTPLc33PeGTKZvGeWzAyGm/PH7xOTj/rHeZ/nO+e85zlnBBHZsWPHTqeN8o927Nix01mi/KMdO3bsdJYo/2jHjh07nSXKP9qxY8dOZ4nyj3bs2LHTWaL8ox07dux0lij/aMeOHTudJco/2rFjx05niaA3Ms4ltAf/r9fzDtLuvBC9hjTkh8iPvHpSiF5BXuoWol3I77uH6AVkR4962l5wMdUXEG0tDNGWohBtRmqKQ/RsSYgqkQ29QrQeWdc7RGv6hGhVaYhWaiFajjx5coiW9AvR4/1DLQ8PCIXv6R96++f9Qy/deHJo8+yTQxVX9g2t/Hrf0Ppv9gvtvHpg6A+zTw39bc7g0Dtzh4b2zh0e+mjuyFDYPSp0ZPbo0Kc/KAs1XzU21PLd00N0xZkh+q9xIfraWSG6bHyILpkQoi9N/CO5Jq2k8ybPoc9PGUbTzxE0eZqgCdMFjZ8hoziwduzYyU4EgMlG1gIpAlIEpAhIEZAiIEVAioAUASkCUgSkCEhtB1KC6gpWACkCUgSkCEgRkCIgRUCKgBQBKQJSBKQISBGQIiBFQIrI25/o0QEyS05FBhE9Mpho0WDae/sgeu3agVT/3QHkv/oU+vvcwQSkCEgRkCIgRUCKgBQBKQJSBKQISBGQIiBFQIqAFAEpAlIEpJqA1ONAqthGyo6d4xMVOB3L63kNaSD1E4lUoQBSuzNC6hEA9SDy24FE95xCtBBY/WYI0eKhRJ5htG/eEGq4+lT60zWD6F+ZI0VAioDU20CqzEbKjp3ch3HJVvoBqU9TRGocwkBx+gGpo1lF6tc4m1qA/AJQLRhOR24dTn+dPZj+MXsofZAdpAhIHQRQmo2UHTu5jQAs2cyFKSD1PoDKpxe7S6S2FHEuyAlSdwOpnw0jmj+CGueNoLfcQ+m9OVlDigDULhspO3ZyGxU0meW1vAeSILUKEfRiN0Hb8HPLScAqX5CR/wuqA1RbexI9B6Q2A6caZBOAqkRWIyv6dgyp24cT3TGSDt00gv73muG0zz2SQrNH0eFrRlNjZkhxLlMdWDt27GQnQAVAZDsN+e8nQGq2idSufNFYXyze9w0Ve9cPFh9sGCbefbrPnn8uLaC3lxTTPx4rob8/XEJ/vr8n/fW+3kdpVe/FtKrPQiC1CEgtAlILgdR9QGopkKoFUgcSIvXTEUTzANUNI6sP/dDxq8a5py1qmlO2qPmaMYtavj92EX339EVAahGQWgSkFgKphUBqCZD6cxKkXlUdWDt27GQnamQySwmQ+sQSqRe7jzAv9V4RYl/NIPHy0s+JPU9NFXtWOrvtWNxz35a7u1Ht/EKqvr2IKuYV0VM/OolW3HhK/VuPlwla01PQ8lIBpASQEkBKACkBpASQ6gOkvg6kfm+J1E9GEt3ieIpuGiXoutGC5owRdA3y/bECSAn61pkCSAkgJYCUAFKCvjxR0AWTbk6AVJPqwNqxYyc7ASrmJVo2c0WCy72/mUDxpd4uId6pOlP8cfV54m8V54o314z70p8ezac3Hiqk3fcXk39xMb3sKaYX5p9ELy926LseOVcceHKQoJXFQApAtUdKACkBpAR5Bt9tidRNDqIbR41GBF0LqK5OgNRXzhY4kxL0xckCSFVYIBVWHdh2aQDg0fgjeRWXupxXInk5kpdwfDi7ItnJwXH7fSR8DPls9IUewrwB8XwkfMeUsw2pN0c8ondQcTkdCe8BPods5uBY1iI1yCZOiaBnkWqkCqnEhwJnI7Khl6AKZD3yTG+ZdYgPWdsHHyDIamQVPkQ4TyNPaVgvZAWyHFnWV9DvIuEPmqXIE5EPnMd5PZHHsKaPRsJr+zDyUGSNH8Aa8zpz7sda34fci9yDNV+MLEJ4/ReiTn6DeJBfDxb0K+SXnCGCFiC/QO5Gfj5U5i5k/jCBWpG5E7ljuEDdyNyG3DpCoIZkdGTeSIF6EnQL8t8OQTcjN3FQV1xbP0ZuOE3Q9ch1yI9Qaz9EuObm8gckPnQ5bmR25MPyB8jVqEWux6uQ76EmuS6vRL5zhqBvR3IF6pRr9ZvIN1CvXLPlyNdRt1y7X0VmoX5njXfT5eO9qGUdteygS1HPlyAz8eF7cSQXob75g5jr/ELzA1nGhZzvFPSfyBcjOQ99cC7yBc4UgX4Q9B/I5zjnCJqB8BwhZxoydarMOZFMmSZnDDnOSCZNl5kYCY/2cM6eITN+Rk6QWpYAqSVmk+3MFy0vFIj3No4V/6oYJ96vniDeWXvqPYEn8unvuNR789Fi+suDJfTH+4pp90L882NnTPnz0qniT49PEkeXoXifRGOokOKC5SLlolwweIUlUjeMulIWEoqKC4YLIh6py7HIvHjnYgE4cphThVRIiVJ8bKRspI4vUh6EUMdyf/UrZweBlOPEREq1+Z1JXsvzK5HaaSL1LbPJXhKi8flSsbdqgvhw0zixv2a82OsrbXh3RTf617Ji+ufSEnrbW0JvPlREgYdL39/31Gjx4dOniXdXjhUfrUTBPIlGWYLijkXqwQhS0SJcMKQnCrFJjdRpvzQLiIuJi+oHKAgugihSvNiXYTH5DIoXghfnvMk322dSNlInCFKaCVRbpAhI6TZSu/P6Aqmjlkjt7D4witSRbf3F/k0TxMfPjRMHassG7F9XSB+uKaAPni6mvSuK6b0ne9I7jxXQu08MqA36ANnqsSK4Zox4b+14cXAFCsOLhogi9Qh+ctFy8XHBcQHK1KD4VEhVSaSQa1EkVmdSvJiti7TDAqnU9qRSR8qD42WY2RWJGikPkDKAlAGgZLYXyGxD6pE6TqEXSOkAypUmUh4AZZjZiGzoZQApA0gZAEpmHeJD1vbxASkdSDlzhJQDSOlAygBQQYSw3gSkCEj5gZQXSLltpI4h5bRAymMjtTvva0BKPSe1s9tu2WxoxJfyxJG6weJg7VjxiTFGhGsHXfHx+u50YF0xfbSmmIKA6sMVPemDJwpo38phd364bpLYt2acmQ+A1N51Z4umpVzAaIQlKGb+hOWim98GKM49Fki9YBYQFw4XhtWe1KVYRF7A8yddhbOqzO7upY4UA9V6icxRI2UAKR6MJQAls71AZhvCz0XWcQr5+UgCUJwgkPIAKS0FpBgoMrMR4bm1isjs2jO9ZXiGzYes7SNn2XhMZFWpgTizhJQDSPmAlBwzeQA4MVBtkSIgRUCKgFQQSOk2Usis8X4FUi4bqd15DyZA6n6z2XahOXf2EIe3jhSHjdPEkfoycbj25KWfbOhG4YpiOriuhEKA6mNA9dGKEjqwtmzSgWfOEgfWnRHJ6WL/+rPEx77TRQsX9/0o5mihtQWK86t2SN0MpH582rPy7h4KhIvDCqlLJvTG4t2FBUs0gnC5EqX4dA6kCEgRkAoCKT1HSMk8XerKECk3kAoCKUoDKTmCsnCQH0hpXRwpvuTzAqkgatkPpMpP3I1z9SMuHcvuvDctkdrV7RIETZgnml8sFkeNYaJx62DRWDdEHK3t9daRqgI6vLGYDlWU0KF1PSm8uojCq/rsO1RR1u1QxRhxqGJ0mxysOV00Lkex3I7iUwPFaX8mxUjdMOpdFM2TNLdsOYpjOYpiOYphORZ+ORZ8GRZ6JRa2Hkjtx+IlGuZs4IOoRCk+nQsp+azk5mJvDpEKAimtg0i5EQJS1EGkCEj5gZTWhZGS4W2L6J1qG6m8YUAq0QPGpVGkWnb0Fk3GqaK5fqBoqjt59Ke1hdS4qYgaq4rp6IYSOrK+hA6vKaLDvn5rGzeMEI3rh4jGiqExGSKO1A4VTY+imH4aKTh1fmeBFKFoCEgRioNQFIRiICx8ehPnZ80YjKhRis/xQcplZhtSj9QVlAMpHUj5LZAiIOVJA6n4jXMNSLmAlFeBFAEpvQNIlZtAqZEKACgPogOpciClAymfBVIEpIwOIOW0kco5Us7PCqnvJUDqeUTeqXopXzQ/PwA4DRFN2wFNXd/rm2p7UFNNEX1aXUyfVpZQI86mGn1FAGuo+2j1GeJoVVnbVJeJIzVlomUxFxNO6dvjFM1fcoRUIw6k69iBVKEUn+ODVKK7ey7Er0CKn5l0dRCp2Lt7vHEej5SRJlIakAoqkAoCKbe596i+u+cAUn4FUvz0gTsJUhqQ0lEnAQAlR1buRO4YHkTdeBFXBCknasgwoyPzRhqoJ08cUh4gZQApA0gZQMqIQUoHUn4ghbpD5qD25pQFgZQXSDkUSGlAyo269AMpAlIEoDgBIOVFrbqSIMUjCAaQMlDLBpAyLJDyACkDdW4AKQNAcaJIuYGUH0CRGe6BcycHgZQXSDnTQEpDdCAVMD/gOU4zQQDlQ1wRpJzoK8PM2TNkxs/wqLDpaJYrkXrZRIrvWMkm3NVdtNSXipY6pF4TLVtLKpo3F1AzkGp6tpiaqkqoCWdTnz7Tk5o2DhneVDVcNFUCs9hsQnBGZRbczyOF1z7DUIjt56QyRWqaidS3yYmDGj11VaEUn88eKY4GpAwFUkYWkHJkASkvkJJAtSIVBFJOIJVsBEEDUn4FUoEESLmRIJAi88OsLVKybji3DfcAKZdZQxwdmYda+gmgaouUAaR4WJiAFN+gISDlAFIBs95+iLRFioAUASmuQz0GKSeQCgApWZdtkZLPmHKtfvNMTwKkDCR+41yFlAGkZJ1fiFyAWr9gkoaa9wMpAlISqFakCEgh6IXPT/GkgJQbQAURAlISqFakCEDJTJzuQVwASl6lnD1DZvwMQ9AeAJONvJ73bgKkvmMi9Qr+vZ2FwKmvaNkOoLaXdm/ZWnig5blCaqktopZNxdRcXULNG/CzovSvzZWDRPNGXBZWxgS/NxmniBaePr8NhcbFt0CZm5TDnNlB6hnzVDUaFUrx6RxI8QiCFtk4j0WKgJQzQ6Q0BVK+NJDSgFRQgZQLSKU6J+UEUnx3TwdSOpDSgZQOpDQFUgwUmUmOFAEpfweR8gMpWW+JkSIgpQMpJ+oxCKQoBaQISHlygJTfrPnkSBGQ0hMg5UbIBCo5Uhy/BVK45Ms844CU+s2cL5/UhAwwG/BVNOYL3DQo6noUe33PqUCKWnAJEkWqBUi1bMTPjdojLVXAqHJA2zyL1KKoH0PRzo8U3bFPykjk72/lBKnontTE6bMQeR2tQik+nQcpnpPSFUh5MkTKrUDKnQZS5UCK4pAygFQuhjmdQCqYJlKyhtJHitJAioCU36zH1JHimnVlGSlZ86khRUDKoUDKCaCCaSIlgcoRUtclQOoNs/mijbgdjVKHS4t6NEt94Xw0EJn7JGiaFjSLiVQlflaePKulaqBoqeovU4lU9xMtm/oLWomiXoKifwjFGkWKizEaz6BZKEr1s3s3O14BUptQNDVAqgbFUYOiqEEx1GDha7DgNVjobVhYfse5NVITpm/BQTyR9qRikXIokMIlX4eRcgOpYBxSASCVzgiCR4GUniOkDHMroD1SPsQV2TjXUDfliJEFpPhyzw2ktMjGuRNAeS2Qkh+aV+FsSu5JOSIb504ApVsg5csBUny5Vx6zce5AD+gWSHkVSBkmUO2R8iEu8wrEOU0DUOWIcTyQqkyA1EKJFJqSN863A6htaIJtDFXhdtpacAwps1nMl95xc+DyoRINUIlP6Y1IFf75WYSnmR9HkXNhP4FwwUqYZHFyPIP+jcs9FVIHzGK6YZS82zK3LNGclEaXTvhZAqQO4QD2RNQoxadzIcUT5/FIIUmRSnUEIQCknGkiZSiQclkg5QJSLiDlAlIuIOUCUi4g5QJSyCAXkHKhDlyoDReQcsYg5QRSqI12SLlRK1YjCN4MkAoCKc2st/Z393QLpPhyzwmkVHf33AqkKMtIBVDzGpBS3d3TFUgF4pBymtsi7ZFyo3esRhC8uUZqvyVSr5x0udmA3JQ7e6B5gNN2NMm2olI0UnPsmZTZLNVIVa+dVIWirgJInGpkE19S4OfSSIFzYfNjMTxXw5+q/AnKn6SLTn0AhWn1qpa7EHl7mAvGCilebL5te7F5a7bOAik+gGNOYKSMHCGlIxqQSnfiXIWUZoFUKnNS0Y1zAlJGDFK6AikDSCWbkwp0ECk3kEo0ghBQIOUBUolGEPwKpFxZRMqNmk80ghCIQwppg5SuQMoAUq03m9ojxQnkCqkpCH+llQqpRjSfdgypF4FUHQOFZtlW+AU0khw0bHMmhVT1WkhVkbOnaj6DwiWGD78vixR7LFKPoHi5kO9H8S4+5TKzUNVINaOweqHA5GwLFwwXSTxSfLfkqwCK50d4buTLE29MgNR4G6l2SAVNqLKDlNUDxpkgZSiQKk8BKb2DSDmTIMUjCPFIlSdBSs8xUs4kSPEIQjxSrhikDAVS5SkgpauRUn+XXjq5JQFS/mMNyOEn9bl5zGbqcaMSqWpc7lX1Ol9e3gGnKFArUfRc8CqkuIB/O3BGkjdzXofIguOfP0LhWCHFL7u7AIvCA25fnnj9/9MzqWAHkLJ6wFg1ce7N4eVetpFKZeK8oyMIyYY5dQVSrs8YqWTDnLjkSxupVCbOLUYQ1PCkky0JkFpgNmEDNx/vR/HrRI6Fn9RXIXUEKT7WLLxBuwpI8V6UNVJXmYVrjVQD3RopOAaKJ4ITXe7xIjNUchp3hwVSYRzAkhMUKX7AOH5Pyp/BxrkGpLxxSKU7ca7aOHdbIMUT5zqQ4olzHUjpQEoHUjrWn0cQEiEVsJHKOVKBzoRUN+RgAqS+JJHKk5vm3Dzy3Uc9gFTYAqnNkSaRDcFNwO8qUiPlRCFXo4Dl81xqpFrojmEDzWLTARQ/usCFw0WTaOOcHye4dML15uKpkXoOB/FEvbvnViDlzQApuUar+wTikAqmgZRbgZTXAqlEd/ecCqR89plU1z2TuhAhC6QO0av5heZslB9IcWO1InUBkJIPwbbbkyr5mtkk/JI1bghuhLZIDUCBz0JhVwIpLuRE3xYTRNGNNQuOz6C4oLiYkt/d64uFvTfJnFR55MC2xcgqDflOxGXGH8lnh5ShQMqdBaR40zwWKf4aMmeKSPEwZzxSPMzpSBMprwIpdxKkXDnck7KRkki5Pqs9qTsQK6S2m2cLfOZgDnGaOMk3Se7o8esESF1HlSUuNMXFaIiZaITvoAHuQOE/ioI3UOyHUeCpfqVVFYpuHAptJoprJopqJoppJpCaiaKZCaRmojhmoiguQjFchIW/AQvOb0E4YC6s9cT5WzQp5kCrUIpPQ75hHpfoWaY80/wskNKBlDzerUgFgVSmj8VYIeVKESmcGSsfi/EDKS1FpHgEIX5PKgikANQxpFR397wpINXRifOuiJTq7p43BaQsJs7V+KSaZxArpG41keL3nnPzPY+GkUBxdidACo2RtS8Hbf/64Iwfi8EBnzxtIk3G6Ws0KpTi05DvVSBVHoeUhgRziJTHPNbtkdKzhFT85V66SDkUSPEDxn6ssSMJUjwnxS+9i0eKH4uJRaojc1I6kJI1ZCOVClIdmZPSEQlUFpHqgXyMWCE17RhS/Nwen0WZ7+Xu3h+N1YRmOh5Ixc9JZYYUL8i0qfNwwKMPT8qoUIpPQ75bgVTQhEoi5QBQPkQC1YqULwOkHEDKhWPsAVABRB7rtkgZOO4AKiOkHFgjn2LjPJ09KUaK5950BVLRV7V4sc7lCA9zMlI8zOkGUgaQSudVLVYT5zriiEHKgfiAVCYT510RqUQT5zriiEHKgfhMoHKA1FSEzLRHaj8iL/X4u/h40/x5s7E43zAb68RE6hYgJd+Nkz5SGhJEYpGS4dfZcBio9ki500BKJvWX3vmBlJYGUqnMScUi5ekAUvzSO68FUnKdOZm99I6f3VMhJZPdZ/e6KlL87J4KKZm0nt1TA5RKbkOskFp/DCj+yY21w2wsjvcERCqABboQC4KD32GkOOVIOkj5TeBzg5QPSGlAKldv5vQDqY6+mZPjyQApA0gle32wniZSHZ0476pIcW/oaSKV9T0pP2KF1LVmUzJSvOfCOHFjyeY6eAIh9W8s3u1YsO7mAmWOFMedIlIMlJYDpAJAikcQcvVFDBwDSGlAKp1hznikeAaOhzkDaSCV7hcxyNe1JEfKB6TKbaTSRorD75NKBSl+di+rIwhTEAmUCqnX8oebQO1GeD9qR48oUmeguQ7j9zCaieekwmigMBonjKYJo1nCaJIwkAqjKcJoiDAaIYwGCKPwwyj4MIo9jAIPo7DDQCqMQg6jgMMo3DCQCqNIwyjMMJAKA6kwii6MQgujuMIoqjCKKQykwiiaMJAKozjCKIpPUAxhLPw+LPgeLPQyLOyVQKoIiycXLHtI8YyUA/ECKN6TikfKj2PmNo8bA5U5UgEcYwNA8ddaOXGsoxPn2UbKD6S8WCcXku2vtCrHGnuBlPw6q/ZI8Z4UD3NqWH/5kHnq3xbjBFI+C6T8iBtI2XNSHUeK+8WB8N09FVJ+JDrOk1Wk/gexQupFEygOv7GzLVK90Vz98LuGZtLQSBoaiN8WyRPQvDeioUk0IKWhKTQ0hIZG4GlmDYXPlw4ail1DgWsobA1IaShkvj2toXA1IMVFyvsQGpDSgJSGouNXbmgoLg1FpaGYNCDFT6VrQEpDcWgoCg3FUIqFL8SCy4WW3xYjH43JPlKxw5xOAOUyI+/uyWOWHCkkcrdUzp7JTfPEd/diH4tJhlRn/XJQXuvoWxCcQKojr2qJRSr2HecuM3ci8lUtsSMI9jvOW5FC0Asde8e5y4zTDL+qJXYEQYWUVwVQsqxGWoFqj9QsRN7Vex3/vjkjFWmsaHNxY3EzcSNxA3HjcNNws3CTVCLWw5yywLmw2z67h2JFwXKRcmHy2znvRvHxLWUuNC4uLiouptRe1XK8kIodQZCxkUqElNUIQjaQSjQnZSOVHaSsRhCskNJVCH0VuQgpifkbZwayE2kLVFuk3kNav4ePz6T4kZhoU9lI2UjZSHUVpHgEQYZf03LOVE8KSHkUSLljEeKMN9GR2Y/UIbXI65G/qdOK1LntkOJwg3Ez2UjZSNlIdRWk/OiN+BEEvtSzQsqJBBVI4aC2AsXDmR+a6KQbidS9x1CKzRsIN56NlI2UjVRXQkqOH7QfQYgf5uS4TaDaz0n5gFSbs6gtx9BJN3vEeuU3yHD+gP+3jZSNlI1UV0NKQ28EFEjF3t3j792LnZOKR8oZi5R8ULhj+R2QUgPFsZGSsZGykep6G+fyG2OskYqdk4pHyo1EvsH4DTE7Dp1U04TchAAjG6mksZGykep6SEmozpnqTwMp3peSQMUgtSyCTqo5iDyGjELkmZiNVPLYSNlIdU2kZL+cM9UNpPjrrKyQCiA6gNIQCVQMUpwxyI8RvpP3JhJEQsgB5G2kAVmKfA/ph0T/OxspGykbKRupVJCKnZNyAig50DlpOkcDUHIMgYFqg9QM8X8K9Oj+EuBOsgAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">JDB</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="1">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topGame__6ZwJw"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="3D"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAtCAMAAAAQuiwzAAABEVBMVEUAAAA5n9g5n9g5n9j/pxr/pxr/pxr/pxo5n9j/pxo5n9g5n9g5n9g5n9g5n9j/pxo5n9g5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9g5n9j/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9j/pxr/pxr/pxr/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxo5n9g5n9g5n9j/pxr/pxr/pxr/pxr/pxo5n9j/pxqnntYWAAAAWXRSTlMAUCP9hvr2FwsFDqKcWWRPBPc/PBAHh0MI8/KAMSQZDdi/rZdqFOfk1MnDkpGNinpXE+3htrSup2hhOZ9/cVJMSUcsKR0L7efez4lzbTjXx7eWeGAaultNHyQiKA0AAANoSURBVFjDjdbXWupAFAXgFYoUUVFKEFBRBGyASMcGtmPvDd7/QU6iQGYNyeC6UpLvZ7OTmdlArhQvHfc0rXdcisfjqTCEnKWMT+Y07XQuZVwsxR9gZK17sjDOiQ5K9NZj5fYIcPXFHPghpNGnzAZh5Dw/ELLDfHogJqnkNxcndJOvisIh8/t/5yP/7HSkZ0ShqeIzMn8ds/SCrY4lErIq/kPmG2En3Q87fuZexddlvhZW6NP5QJn4XZlfj9n3PQYHvsX8LvEemZ/9rf5B0sXV0KV3Q2e+SHwZiBCUghmt4KzjXgSu0ip+H5ib5Df7lBDpKBPfUTXnRObjpu5mPQbKnQjkfXTt8oP4tMS736bqzFdBWXsi3ifzPXknCPkBqb0qfkfNa3Y6C00R2FLxmQqwSXxjmo7ohihsSBe3xItPUcT2+hS1ztVP8hUvbdbEK3RF9Qo+myDeQedcZBS878+8ey+I6fwhKB3ijwKIvTjoxwBckfAEv5IUAG8ZlAV50QbX7fV5AOHa4qqs82nqvQNFp+rbBr/trIeM3WwKfwRKi6pfcuAXTR0h8685me/Qdr8Pyi3xK8yz/vtQrnPgtGm774BSZt6298s/+uvwvxcofv/MEu9HTZnPFez14/Fo0mP+XsXvyPyqW6Wb2ab3P5FV8Im8A899531ujw6MQwWvzzjwXPvDgfSNVqLPxOvE81GYeR/xrCPHz/vxzBJ8W/Tee0T9m3tz4wM0gl6Hm8Ap/6aa3+JvqPpii4qnNNcMiJzxIgr1KSWrOXUaFD6rJ5ejp9JKMu8JABrzwnRMebN/c5Ldw0FTT79HKyt6fSCla60emUeK+YOI/apN62aLnjbq1YGc6jeAkgOf22b/0YXfnHvF3ncrOwOHtLlK5jHvZn97dTSI8Y655KDfXMAIH1YarIT6nPWhn+YJPnDLLC+4GhFnAh+z2sMzfpmHwMqzjZ7/wk94Abkg5Oxa8hs5mEkU+TzxTbY/0xkaNSeefe7PZ54msbUs40mPb0QUFDxcs27JH76f70WvOCsEdKFBV57zwFhYVvEIajW+oTBcX4mVVt0rDAuXnbuNLSM32f2LBKDgOUHXaarxaN212HgYTYPn7ezPzLP7W2zUZyYByqkmxnYuC/tzqzlXb3RPJGgdH9EL/atdXIBT/gP2U0j1J1W0LwAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">3D</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="98">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topGame__6ZwJw"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="PG"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFMAAAATCAYAAADs6jFsAAAIk0lEQVRYha2Ye3DUVxXHP/vIZrN5dJOQkFAS0ogYIkhT6UMd6KjUVp1OtQ/rCGOtY6UDo45jVR4TKi0dGDXaWpTS6pROkYGRqUqpSLHASIsQCjRNCM9A3gkkZMluNsludvf6xzk/dt1myWM8Mzv3t7/7Or/v/Z5zv/eyKHszgBMwwBngGlCvZR3g07If+AAIACeBgVW3c9zUYMwK1pgVYFaAWQtmmRtT+jwPOecDUFHipHd3EaZjxgnTWBK5a3baRaALaAHagVagTcduYXy2RNtHgE5gDnCH/jfAW8AtwAb9b4DHgB8CvTrGB8BWoAYIAiFgBPiBjh0EYupfom0ANgNPA+v13T7nnZnfL4kR8xwILK83xJqAHuCygtkF+LUMAB3AoA4+1D1IS3MHmfi4fH2abCisW4THP51eRy9E4ExbpLBqyRXXrk0FF7x5jkgwZHqAdHXcoQ7bAA8wABTrxzsUnPj4cSsCsoCngF8Cv9fxGoBfA68D3wV+BqwF8oEngVp9LgemAgeBKgV4M9AH7EMW9e8IsX6aNPceIA1o1jZTgAJWFxvz46mmzWFLawDe09U4rWWjgmeVp4Bh4H3gnE7qB5YlztSYtxIz4xV2Tfm29eq4glOLsKENWbQOBaoL6NZfp35Qt/ZpGgVIFCiDLLoBvqp+/UrrhxTEAeBjCf2WE2fqKX13ACFLE/BoQtte4OVR5n4A+CZwG8LMJ4CVzvOhwyf8seZmQyxXP/IYEtq5wFVkFRPLAgTYhQpGI+AC5iOr2YNjBGL93J95W/lbjGQt7vtr/bXYcEhBywL+CdiBqJZGnbQhLL0VCOucbSnAzNXyewrCSWCHgjcXcAMZQCawAPgicC9wQee4T4H6if7vAZ5XH9wIaTKAvFHmPqR+24B1CPGmgbDgKJITt6ZwPNnmKgAnEIYe1v/VAL5bqjGVf8SUbThmyl81D3oqjyJ5t484cDeyqDpogIsp2vxilLF+RJx1jUge3ZHwbkNSv24kul7Td9acd2p9BAnjcZkTOI/EPsCVcfYLIPQOIuF1Gsl3FwG2BU4yPdRKIDxwNJv02KWIrxlh2XZt50AAS2VrtN6NRAOuL8zBlpVOeH8DZiAE8BKSFxPtBWAnkAOcRRj3KPAHJJ8eRhj1Z23/Sf2WAuC3+j0oJiDR1j9OTABhS62WOybSEVn5APC2Tro8qf4NBIzjSG6dsDmm5ZJ3cCXF5i/cbPaT8fiC5CbzgNkJ/z2MHpqW2bWsREAsTajzIumjbDK+OpEwbUFWsX2C/T1IDmpFdjRfUn07wpAOhBkeJN8m2/3qiyVrrNxpt0/JirrursqM+nuumRyzjzSH1WcWsogzECbNQli4XesPINFTDXwNIcsLWpcPLFaf0pB8+g1gqdY3I7JqQuYEKpCw+zgf1VNjWVD7X9X+yYwoRVjjRqSIndFtB5LshxBA0xDNl4HNFrThyXXklDQ5KJxpy86w+ixBgHwM2QDzgE3APxCgfIg6WYBseDsRjVmDsK8VkVQXEVCXInvGUUSjTticiFCfKDOnISyIIptQC7LafUntWnX8dmR3jqUYby9x1saQxR0B0qMdvmH/qpeKjOG83e0hvL/R6hNCoqIReAdh5ptInltNXJ+eAm7XH/ouD7gbAfcpZHfeAnxefzcBz40Ti+uWyMzZpNZ0yZYP/AYRtNaGcivCzkQr1fHTuTEz7yXOzKj6FQLaYr2B4eD63aUIuInmAmYCn9DnCiSdVCKi36nv84FXEMCeQ/J8ESKFtujzdG1zGmH1OiYJprWbBxFttQLZLHKQTcWLCGMvcf0J8B8k31YCfwOeJS6CLWvXNu0IU1Ix88vEd/hEzVmN6MYQH01BW4EHtbyKCPRNiHZcqt/jQRbyNSTkq7VvE7AIAc2OMPTphG9blcLPMc3SmacR6RBGwieMADGSUJ5NKGP63iBhNZq9gZwi3meCEkOtA1mgLkQPAoJyCitKeHYhgj3Zkru7EdAthhZPwk9AmNmMMCcHWeEQklfakI/osMo7XJ/uXO1dM/Bh6Piu6v5ndmnbHFJvXFe0rgVh+wYgG2HCjXRmjdY3lDrShl70FhVj6MZm52okzDJ/N8PGABQiWtGBHEMbkcuOcmRXDyPn7kKd17rA+RQi2L0ISzsZXWVM2HqQkD0FvIuE+nktzyKAnQFC3/I8ctqUG2PKTM3LuRtx29xjjf0ewtwjyHHPOm+PZYNIxBz/XHrGEVM235iSeQ2m/C62eqdZbT6LhHK/+roekTeJ5+4F+hxFUtQe5PhoEn4bx+HPuMxJ/LIhHVm5xUh+cyaXAyYYIRL2+CI9fU9kL+f14DYOhQ/faPyHs2YuzJj6+Ppnr/UxO7D9ydpwR30mciKxxk28NbL05SEknRRciIx0dQ/7y4tcnhCxYXaHBqyxH0DCcx3Cri3IAuxFLh5aga/o9x1B7hz2ICmsDkkbS4Ftk0YvyZxIjggCJcj11Rj3iTZixCA6NObg+XPu6apa+zadUco8LqoG95aE6Kh3AV9CclVYfUgEM4pESxSouhyNeOZdabpUVzSLIoeDf4WsEx/rEYn2CKI3fep7A5KiQsjpbAB4CDkY/BthfZ2O0aD1/xdzAgN2b35wysY3/facm8I2WwwiYXqWP0yk89KonWxKoFjKzVlsztd/ztwK6K3jvv4T9c5w64lXETnTgmwQEZJujfJdxGoX4I2m41v8LlOP+YleiUU5ONTPIIbe2PVUm4VsnOeAZ5CjbBdy2mlBIs2N6M9lyMEgoH0LtZw6fqjGNidQbHOm+V0VVcU2rzuPQBRHoYOinUe4/J17GDn34aQHDwd6iNoh3Fwf8Nd8BkaC+cDNCHijXQ7b0uxEy7MpIAdTuwjfwoNwqA/2hQZ5J85KkCu0FxF2n0cufjORFPE7RCL9Cbmia+R/DxQhRGVM6r4glf0XdAQwJjDZnZUAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">PG</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="141">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topGame__6ZwJw"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="FC"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD8AAAAjCAMAAAAUlSINAAAC91BMVEUAAAD/eyL/dib/fCD/dCj/fCH/fCD/dib/dCf/dSb/eyL/eiL/dib/eyH/eyH/dCf/byv/bS3/fSD/byv/fSD/fCH/fCD/fSD/fSD/fSD/eiL/dSb/dyX/diX/dCf/cSn/cCv/cCr/byv/cyj/fCH/fCH/eSP/dyX/dCf/cin/bS3/byv/iRf/fiD/jRP/dyX/eCT/eyL/eCT/ghz/ay//bS3/ay//cyn/cin///8ZGXD///gABHJIJ169vcoAAGD///wAAGfo6PEACnM4H2AAAFsMDGkHB2UAAF1zOlUVFW3///rV1eW6utT+/v7Y2NolJXcAA28AAGL9/flCQokAAGn///4AAGsAAGSgoLoCEHgACnQcHHIaGnEXF28TE20PEGsFBWQ7IV8AAFP///fq6vL///HDw86/v8unp74AAXcAAG0ICGgAAFf4+O3r6+zn5+nPz+FxcZ9fX5lWVpJDRIsgHnELEG8sHm4EBGMjFWJNK2E/I2BoNll2PVOORE6yUUP4aS//dSfy8vju7u/f3+zc3Onr6+Xd3dzW1ti7u9W2ttGtrMu0tMaQkLaNjbGGhqx9fax2dqNnZ5tQUJIvNoc4OII0NH8tL30EFHsQFHRGKGUQDmQNCWQFBWBZL11wOlkAAE8AAE2gSknHWD7VXTnmYzXsZTP/byz/eiP4+Pv4+PT9/fDh4e3z8+jZ2efm5uPh4eDMzODS0tjMzNTHx9G6usqbm7+Wlr6Li7eWlrR0dKdoaKFra55YWZlXWJRSU5FJS45TUopHR4c9PYYAAYQYJX4kKH0ADH0SHXwsLHspKXogIHQACXIsHWc4I2RIKF9SLV1/QFMAAE6URkyqUUa3U0MAAELAVUHPXDrfZDTmZzLsbC7/byv4byvt7fbk5O7o6OTf397Jyd3AwNi2ttKmpsivr8SursOfn8KamraFhbOHh7B6eqZtbaZOTIwiLYMYFXRhM18NDV5PKlxhMlpjMlgAAEyaSUujTUnIXzrhYTfZZjUhPZDoAAAAOXRSTlMAj+uS7r2TWu/uhHHo1YtDGgXx79/JrqmknpiTY11MMiogCfrCun1qSDwUDvjk5OHZzcy0l4BYVDRgHV1tAAAEHUlEQVRIx5WVVXjTUBiGg3VrmeDu7m4tkgVIl1EotFChXspgaztgY+4MZ7AxYBsT5kxwd3d3d3d3u6DLSU5Slhveiz05+f7v28n/nPMXIWnertL/4NG+Y02ETeM6lf8Ht54NXdj2XjejogdzERUVdYHr/de4W13bQ3uTWxqrbBAHMpsmI4NLUSlkMffq0f4Gcbagh35DKuA3P9jinTS3guLn5x8Upvj4pxrlr3RtULpEObAiwtVHCkJnCSsKSuGGQ+rMO+2Av2XZJ3WIkJNVoQWnpdzSdHlWWQ0Q4JKQZUnhrgqMuDxdyEY6h35ariryaAUCev/ElnL7H6P4YS/W+v5yf/pxoTzGvRnw141RvVJy+nda8MUSZjkn23sDvfTVRt4VkPZWrSdoJ3sxRYEjIctwuT+jJOZ8PzAFLj9ElDQEx3fGimPz4OuZYtwbYjIameQki5nYOxCmpcqLG4D+rVSHTIFt3oSaRkAM9lOPaP+efJMOT2Y6eTJ7Bo/0C+KxpRPh+2cBIhboQSp5VUi+QT/CvA3WrbVFu1Yn/fXiFIuZj9xzWUxjN+pxKnl2qEWnFxlEaeMoQtKtsXU9SX+PXBurScuyx9CcPmPAQfKoHFzn2I1eb0dpvE/8aEgeoM6l54ax2j91/miKeev2E3J/paOl764XEAHmMyInNDfA9j1LsOMbWYdEMpZC4pVOiLY4lE2HglLeJgeLneyZmcXg+FQvwg6s4Tw+Q01E2tzy5IETHbcpGTTWQP3VnCttSfobFWJLJEIunhB48CQpbAwuEumMBEpC2E9c5CMkbWIVu7w4/dsDcCZZesos0pnNSc/Hl7Ntr8ynLfBX/iJbxO1PsRBM8myxSReBLpJMBLPhjbzQA1z/0siMzbBKuuDpKJoFR3LsTPICQo9GTJ40jVruQ282If0dfmOpc2FVYD6uwGisYaKtsLE7AlDxFmgXnlwxYwBofzy2n2nSQuJ8rA9NbGTYViHN7uvG0Yw9UZ5bCyGpH8du/2v51W5tq1F0+WZ7AZXjnzeuAXYwfW7wgN89RjVeyYw1tIj8LBB9BQuC1yVt85SpzFwhsso60cNjEOv0pqIlntDvUiwzzaKEB/PXkY/gK3HtbQHCDA+4/5mayLs1EEitPMVhWlrN/PftqPWaO4LQw+Mgc/nXqy66IQzNEsLV732BxNQE49artTqDipqCeMX0qUMpfHdgl6ohLBrdCcfCdifO9qX0oYEv9ymw0F916E22qOdzVKMdRqE9e7SwCuIUkJAnU6tldMVZlRwzXkqoD3+/m7r5hEcPh5wPX9kUcaJ/ndtXcqOHT3BQXnAhL/5e3Q6M3Ld2bX5VFq61WyD/4NLA3c3Vlc/nO9Sq3dt4dGSL/fo0rsKG17jTv/6antUr8XhArSJo6pT/F3GOK9Is/mssAAAAAElFTkSuQmCC" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">FC</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="157">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topGame__6ZwJw"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="KA"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAnCAYAAABjYToLAAANhUlEQVRYhY2Ye7BdVX3HP2utvc/7PnJzX3lAyANMIAlPIVKHMghaRJGxQ8e2Ugo+GKudtuI4bbVOpdpq66OdSseOnY7VioyC1QJSYQYEebciIWASTCAJ3Bty3+e5H+vx6x/75CYXa3XNnDkz55w567O/6/v7/n57q5lPXQdB0IMVABAISU5oZ0juUJUIyRx4QZUjQi8/U5L8Rt9K3iFOtuA84oNoYV+v2XvY9bLHpZ090l3sHNSRoYZGKWilOS6zREbjlcJ1UiKloBZjUOACrVjRyTJKASJ+lSUAXBwy+0ehl/+WZBYiA8EVX/ugnPXbKqVom2h9U9AaE5v/Cal9Uln/Q1x43AeZ8iGgtUKU+qVb/mKwIIBCGX2dKqv3hCT8esg9iIDW4F0BrACjUcETXEBEkMhQqVYuCJG5wGfug2QuH1Dqx07rHzlrH7YiPw7wqgf0L2BcCSbFS7QZNBW5UR+bucnNhq3eR5AmxCEjrFqNM2WwHiKNmZ1BzTZxuoT4gFpqobTGj08iATAGsb1SfXrqDQHeYOGjAVoOns7hR96PPqSUPB20WgxaFRcKqJlPXQc+FB5T+hREPqTy7IbOdHtsceJsmNxAiKuoYFGHDtB4/hFqZcETI7MLNBvrsLsuhfFxUAKz85jHHqH69JOoeg06KXknJ738ctSFFxJqVYzNUXv3oW67HRabOFVasoYnu7G6p+nt12JUU8381bsRHzCjA+9TWn1R0qwejh6jd/XHqL7xYqL+aQnggeQne+Dj12PylHzTBZT/+WtUWb5Q6P9u8QMfxH/9K4SupfqVf2X4vTes+I0GlnY/w7FzzkUoEVMiQ5jBvWrK8eXmI5fuwAzVPqzK0ZeUUiUEvAgDEYyU6lRrDarGUM1Savv3wCN3kU4dRqIyKresDjA4OEylWqMSApXZWfjenXT/6z8J1hHiEnFrkeFqlcbqUSqRodJswsMP0fnSrWTP/4yIEgnQQegSGnPB7VAzt7z7omhy8InQTgm9HMk9qlIitGYRr9H1VagAPkmxR44gaYoZXYc4j2+2cC8eRo9MYAaGIATs3BL5C/uJRidQA0OI8+QHDuGSHqWxdTBYQxZa+MVjKMCqQVriWcKzgGeJQA/fVfO33vQtPVy9FhcIaY6f7+HnO4RujuQ5YNG1GBVHiCohPU/oZYh1iBPwAd9sE9ptJPOgI1SpiuQeyS1iPeIESS1uYRGdZhgMCYaOVrSCYxFPC09HFbkkIp1ID1W34QW0wgzW0AM1zNgAfraNm17CzTjs0TZYjx6oYFbXMcM1xDp8My1CuFTGDMcFjPVI7opYOV7sIWAiQzwyQtJNafYSmjanHQJdhBYeD8QorAQ82IggMYWxCE7Ae0gtZqiKGakTdzLc0Sb54QXc1CLp3lfBBcxIlWhyiGiwjvae0Enx1vcjp4BSSmFKMVoZklaPpVaHXjehTaDX91ROwKAQwIngikKzESEsojWiDSpPkP0HCauHYWAV0kyhl2FWVamOnYKctQY7tUj2wgz5kXmSF6YRE4iGB4knh4kbdVQskBtC6giJkDW7tBfb9JopPRwJijZgETyWDIgwBCUEEQLSV0ypjgRBSUb3nhdwW85nsNsjf3Y3Ic5Ra9aiXBXp9RDv0YMVahdvpnb+Buz0IunBo6RH5uhOLxQxUCthKjVcasm6PdI0xSNYDG2gh6CBLhYNjKFZwONE4YEciJTKIrEhQUH00hHm4gnkM3/L+iTgn3yMZO+TJIcfIyQtkBjxAUkd5D2C9ahSRH3nJmrbNuDm2iTTc7QPz7Aw9TIKjSJGE5EgLOEQIELRJGdk9RjnfP6LtOIyzfdcTzvtYVC4fjvSoZcvifVgIqKGRr/yKtQ1pcveyNAHb6Zx6bvw09MFlA2IF3Rw6NYiLs+xzQQ71wKE+oZJ1rxxB2tetxHQKDQWaONRKARFhkWimCvuu5911/8unfN3otefigcChceM0j4KnTQzwzWCUugkIziPSAClATCrJhCvEecRG4gkJ3txgdzXqbSmsL15QqOBWj2K6uaQO4bXj5MsJSwdmyMjxiMIxVF1ECa3bmfsvLN5ZXqKAa2JT9uIP7APAQIQG51pAu2QO0QplHeQ2WUogOBygguQOXQM8pP9HNp1NfqeH7D2n77O+Htvpn7qmfDSLNLpIR7yxS5DI0NEukyGJ/Q3DEAKDG07gwio1utE9Rr1jRsI/VYWFdXZiZRRPclccUQ+x1hLOLmnRRH4QIgM1b0vsH/tuVT/7MNsXFVDX7KLxiW7aAB+30EOv/s3sfNzmNoASgRlDC5keHR/cPHkwMg55wCQ7D9IZdMGKuvWLffjGEidy/X8/ul2HEcEFMal6DxfMQlhNKI01bljzC5GJH/6cc4cGUSfFKAAybEjZK8cQZkSuFAELdJXSvr+8UUlXvh6AA59+1vUo4jamVsp9RXrj3hONyZXLdp2QhBB2YDK7IoNRcfE4kmePcTLN/whZ1xyIY0Q4KQptPfYoxy67DJ0pYqKSkjuipbVD8zjcBlQRrHuogvpzM/z4lNPYvKckQ0bqY6twZ3YNuhSKbI+tUigmLlczslaqHodvfsA+y96KyM33cCpwRcTbH/Z6WmOXPsOzMgQujGEpDlYT7AeL7JsaI+QAAOnbaQ8MEDzwAGee/gh8qlpBrdvo3bG6cv7KlSiXStZIgghaFTSgzxboVi11+Tghu3Ymz/K9noVtDmhprUcvupKwlKTaM16Qi8rxmsXiuNchgoEoAOM7NwJwDO3305cqzE6OYGOIxobNy37TEOmdb3UIfeID0WjzrIVirmZRaK3Xc2287dTCSfKQpzjlRt/j+SZZ4k3v47QTRDrwYV+FXsIAYfg+17LgdHtZwGw+bI38ZFnnqG6ejWu3aGxZRNx/0KALArN1IoGlEJ7h36NYvnQMGuff5pTYMURNm/7Bov/fjvV7VsJ3XQZSpxDWUF8ICiFk8LUhctgbOcOALa+/W0ALLTblBGGNm6iBCSAAqtLtXKnmJ08yllMtrIq41M3ktx7N8n996743IyPF9L3cnAefFgOYfrvRVOmr5ZQB8b7R7lslSjGWMvg6VuoD4/QL72unntlLsEFlA+Id4h9jflLMVKKmf3Hz634w4HfuJKBK99K+uKLxZ2V9Se8ZT1Yh/TVCgp6QGN8kvHTT1/+j7v+/GN89/3vZ3x8gvr4OEOnbcIBGsl1d2pxAR8ycYJkGWRp30R9sCimvGUrrbseoPvowyvgxv7iY4Ui7eQEVO77URFWJH4HWL39LFQUYZOEb/7+DfzL3/w1U088jnGW+uaNDP/axWTAaLWW6HWb11jJfR6yIjKw/aM8fn9XqaCqNQDmPvd3K8Dqb7iYwcveTLp0DOUUkllwniDHw7II1iCBFBjdUfhrz3e+w3f+7atsAdL5eSpxiUHg5eeepQZYCfu08iFRInnIHJLnqFIZfdLmqlwGr4jXjND+3t30Hn10BdzEpz5ZxELS6UMVlego4I6/a2DtBecDMPXMboaAGpB1e+y+5/vc+dareOmhH1IHTO7v0y/tfbmbtHovRx5YNYj89w/x09MnwEyEagwTkhwRmP30p1+j2i6GL72C1LUR0csgx9tQQLBACVh7bgE2d+AAEWAA5R1ffdtVPHfv9xkBhoz5k1TJMa06GZLYb0ruUJNr8E88yNG3X8H0H7yP7sMPkO7ejT06jYorlE7dwNK999J76qkVcJOfuQUPWJJlKH+Sv3rAwKpVjG3bCsDCvr2U+9/hPRWgAtS1vvnsNeN/f9b6SfQpm9dQLsX/YNP8p5LkRGMTiM1Yuu3rHHnnNRx6y+X4o8cwQ6sATQBe/fgnVoDVLtrF0CVvokOGoPEKvDrRwNvA6rO2Y7RCRFh48SX6D71wQEWpzqjSb49QX0ApIq3QWWYJQTJdil8fcveFdL49E1XqVM/YSjwxWRjfRIQkQ7KMcmOUxft/QPuBB1fArf/8Z5dVcyLLfdL1FTv19cVE8dPvfpfFPKPUV6yE2jegzHl1Ze62UtyQ+CCYP968vkj9krG+l983t3/6y2lqn8O6SIvaEimtVRCk35iVjiDNWbrjDlStRGnjaZjGAKW1a8kPHGJmz9MYYgLQJjCDpwdcfcstLE1P8eVrrqHkijmihrpjNfoKr5gt1BMmBxsYrVEvvXlXAVaOyBe6zDx3BAvUReGN3hCVzDUm9+8soS/RPqByT7BC7uZJAFMfZPCqtzB50wfIZ47x9G//DiUqgGIKx16K+BnbsZPpPc8Wg6JSDCjzSRfCX5ZRWF3c7PYkcPa6CWJjfh5s9vmXCUZTRZGFgAShvdRhqFHb0VD62rybX1MOYQcoMiCjRdI/TlNZhU8zPIICpvDsJycCuv0qjMBNVsrvmjClOw9229QxuP8D7OTI+rmllMIYjTEaFHuCl0/Mid05Hctl7YhbnZIjhgZl6mgibLq0POwVraV4pUAZGDTmZxNxfJ72cmf+mgn4tev/BVsBCWilMEphNQ+2jHwoI5whlehaG+vbvCq1AhUUhembBDzCKPq4Uv8xaMz5VRPtsb8ECn7Vh8OvWUb64ShkEps7qEZ3dLrJuM/dVUrrK5MQzusiIxrS8aj81KCEbxz12beDCE6EX/5oGP4XBJq0JmQe5C0AAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">KA</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="111">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topGame__6ZwJw"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="PTU"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="{{asset('media/logo_FTG.png')}}" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">PTU</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="16">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topGame__6ZwJw"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="CQ9"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEIAAAAYCAYAAABOQSt5AAAKCklEQVRYhZWZe3BV1RXGf2ufe3OTkJBAmMhDoUogFQhqiUMLvmjxLYNTO7W2RdShjbUO43vUUuuIio+idUYdpopWfLb1USEFW0GpFkFQAgiipYSCRQmUQAghN/ecs1f/2OfenBsuAdfMmbn79Z21v732WuusK8Fmj6PIWOAsoA4YBAjQCvwLeA94/2gABaQaOBU4ASgC0sBO4GNgb8EVoYACnjoNjiyDgcuA8cAIoCTS9xNgKfBmoUXSCxHnAncAZwKJXl68DngcmN+rek7OA2YA3wWqCozvAf4KPA2syBs5NiJuBn4F9OtFh/eAW4HV8c4jEfEYMLMXsEKyDPghjv2e0i/CnPY18BYADThrORYi5gPXfA38G4HfZRs9iRgG/Bk4vceif+CYzJptKVAPXAQUx+YdAs4AmmJ9FwLzgKE9MLcAG4ADQH9gNFDTY85m4CpgdS9ECM7cp8T6moFXcNe3M8KvB6aTb923AHMBJPjMOCylGmeOcWUagXuBDyksI3Dm2BC1VwCXI7ozwrwAWNJjzavAU8A7QBDrT+KIbcCRl5U24BxCWZfr8TSONxuYFWs/AdyJI7injAP+CAyP9Y0EtkiwMeE4NboIuARwzAu3Aw8WACskV6FMw3AuiiUUMAxAdDvOekAJEa4EXjoGvAaUJxFM1P4CKzVAJtItKydg9D8QzVNeBn58RB/i+odiaULoH/W+AEyTYG0KDOMxuiq2ZC6J8BYMjpSjSXaOAbo8d5895iHakJsjOoWEbTwGNIcXmsmovB3rfRrlZz02didwX9RqxbMnIbThWVDJ110AG/0ImYI1CyNifJTRjknLbAKBQMCXpSi3YPRYQlW+Xl0ekjEIjCGkIYcZys8RbcRo1vogaQ9/jILk3ruUwPw6hxHIDAnMKPENMV1Pi43Pwzdt+AJpz23aREwYwDeQTrqDCrxFhPJRtC5JKNcmxPfqEZ0c7cWqcBOBgiYce8mQHMN5u9boReKOsDPhHqMQyPTY7FUq+hTqQWCgJHDKdCTz77oVKMsgnqJdnmuHcr+oXInzReDC76ciudMeHNPo3ZwFqECXouU+eCGExumGOL3dr/dQ6qMVExJYOQ8kq/dqQT/BGkwSSGUgVChVl5aE0b4F8IH9SUIVCAySjpyxBUTP7tZPHxfEuUUFDhahHdHJmBgRKtCWguIQSYXZjVrgGWBONGsyGoU8UUD6xIjYl3dQVpC9JejBJNLHdxZniW2VPbHZYYLAnJZrCm+BIglLxgpr19XwVtNwAgz1ddtJdyXZsHUQlWVpLhmzlVEn7cRL+XCgDBt6YCwogzBSFyF2ILwPznr0UBLSkdUUh4f7n9Cg7R4EPlIcKe6ywfsj+sehUorooWhFPGc5HvjYXT0LGQ/dn4LAoF0G6dflLDCI/K/oibG1QYJQ4lnYNhCkTyfLVozh7jfOorw4g1phffNALEK6K4Ex8M/13+CMk3cwrHofl45tJpXKYAMPYAhhLrdoAXaCoBnP3dOE211BJ2yi65ZOgAROcWUH0A70BSqA40C2RTdyR26tcpmqvIkVsB5kovwoFYIF7Ug6S3NXwyByQfzVCQKJX341yRD/f+UsXlfDgLJDVJR2uYHIR1T0Sefaf9swnJZ9ZRRbYeo5Tei+MsTlA1nxEUKsgC/5V6E3EUXTHlJkQdRH8/INdwcdEWtwSRK4rHY2gWzB98haYS7cBga14vxdQq8XNC/BS6g17TEnM5jKdhauOp2PdgzkpKq23JBI/iZElIF9OyhN+TRuGM7UcZ/hpXzCjuJWuuf2AyoIpS2KPiVALVCJM+VqXGbq46xnO7AL4XOsoL4HxvYDyqLN+8D+WC7xAso9UU6QAp4F+R5Gu1DyrS4bseB8rDymcecvJAyh2Yg1YA2Cnps5WMya7cchhpONsbVHPLXoPX2Lu2jeW8GjS75D2im+DWu+iDCrCcyYSKGrgM0oTSjvYs3zWDMXa+7Dmoew5jmU5SgbgRWI3kgIBGY01hRhDQRmG6HsyeUIKm1Ycw2BcZEhMBNRNiBcXEDdctAbUHmL0O039wTGGELeJhQIBZP0z9jV0n/A+9uGlA0uP3i1qjyG+/44oohofVVpuvaBZfWs3zIEL5XOEEpjFhMrl6s1oNJKaIa5fkNuPO8xEEqCUCZg5RGU1Vi5JzZnsXN+HppOuBCrvImV+wgkG3JHYmkEVgG/Be4G5qNswMqjhd8rHyc0NB8Aa4DTg4OlqeOHfXnPRaOar3t25diKSTU7tnX4yYmRaW4qYBF1nnBjwugBK8xDdD2+h4bSEps2A5WHCHWhCs+hZjqwGXQrLoQdxKXh1SCnAENjVyv/40/l71hBLc77hxZJBQCz1Mp+VB52p6Pg6hHjY0cWR2p3FpIDfkX8N6oBLkRZrFZIlmTYa2X6tD9MXbR5Z/X1px7fMrM8lXndqqyyKv8GvgLGesbepCrNX7RW7Nh1sM/IX0xaPath0uqq5P7y2bgaRlGMsbVqZZx4Ch51wBbQ9GG0YipRarFMQJmOcEoP7reC/F6VuVgJCQEjmFSAegq+GY9yK8rFSOyruNunNOHKATfgCkMACxGdKv6rx7m5KmuAeg0NRf3baPeTk15o+uby5RtHTGneWzl5YHnHzOJE8KEICzsyyYG728tO7Arlv9dO+vC2uqG7qs8csvtKOlN3ZTqLEWMpIEtQLsomoihIwuZiu4bSnaw5eRn40WEobvxTlNkorxAYEEWyKTqAygiFb6MyAuiD6JcoH6CyEpec3R7DGwW6WTJ/GpjtqkVlLaKl6icoKuuEAa1zDrRU3fuXTTWmcVPNxEyQaO8MEq3jBu+uqh22c8WgZFB03rc2X4HKHUFLVa1VIhIE4Mloy7/MbUBZiWUWyju51Dx3YlHbMAVhDsLomNd/DVcqHNmDkIVY7sKyHo3SZ0N32MxGBqNgRRCeB34So3U+wgyAOBFg5SyUBcAwl5gYkuWH9lDRvqBjd/9FnYoE1qQGlKZLEv0O1NGZuiLcW3lyqAbxwizKcuBxDK85TJ4HftrjXN8BFkUJUQYoRjgB+AEwocfcRzDcjNIXZQ5wNS4MZyUEFqAsA7agbMMViIpw3yI1CBOA65AoDDtZjOFSXOg+jAiwVKryEtniiHX2WlTS5T5gAEJD5lAJKtYdpHNOXwG3iuFFdwrdaqpyM662cdRKcUwsMFMMT+TKAQpqqQV+A1xxhHW7ceW9JC5PKfTOh0W4LT5SiAiXgSkzcdWnodCdWeYWdnv2VuAZhAcQ3StZAvKJAJXRKA/iqlC9fdxngDcQ7kV0o5gIq5sIJypno9zP4RbUm3wO3InR13O42f30QgRAKcrFAhOBMeSX8z9TWIWwCGghsoxeiMhijkM5X+AU4EScCXcC2xU+QlgCbMrDK0xEtu/7AhcA5+D+Hugpe4CVCksRXgQOYWK4kfwf4gc7ygDogwgAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">CQ9</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="140">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topGame__6ZwJw"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="JILI"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,UklGRioeAABXRUJQVlA4TB4eAAAvK8EkEP8nO7Zt1YrW2tfvxZ0ASIE/YiQ9UtD2vrI1DViy7aaRriwFhuGX1jGrm+0yU2KQBEu23bbNBUWCpGQ7PfnLWrLlbKn33tQIwA0DAEET3N3d4RtGruAJXrL2ik5MdZ/cJwuANcr/P0ZrYhNsgVVQm/irsBA6RN+CbhJjTca9iNcROEM5APb9iEhLU1VYNcGoeuA5iuEyZjRDa2gGZmiG1lAN1FANzcBWNEMz0IaKylU1kbtI/+PuzNF2zGASzIG6FGu4ZsEfAYaQRaC4xCUYOSIlEEmyBRGralFTVDMJmQy9yBZEc1k7TVHNApkNQ9Gz6E21qFVFg3gWDUMGrpF4RldwFTEqnXh1mCe+OZ/fybqaB8bDjpz+mwt0LpYiai2WEuRcTBKNJC2qR4DBzipz4KPwsbDWuDfhC++B7mBsWFsFX6IXnJ90s+rnJPPRLYGebd1nZzpTrRQ9BhRAAQUGoAcUSEAEEqAU11OADCigQAYKUHlcIKd+El3JEZFDmmdMGqe3EfVUA52Gytna4t+6jVK+6R5A/x3bilRaF19xKfbZz2KqJuiqapJt0eqV41/Y9uWvNv835JdwddrgHZkcboMeoS5CkTDfnfXehTrUkcm1B70IWMAcEbDAMfgv2LfCXSYXu7N0xz5gAXMUvEeQzSAZyXcmAGUKRwL3FDIiHFfykPBYyR7wPCh9FsoINs+3LOaJyTx5czBOHo65f7xIq/5q8bSTEuEHkChIEhKAVEGG0AGEI3j5e3G+e39IXu7Mxbp4O7pBw+s9M+MgaNs2bvmz3vZTiIgJkEeSQAvt+BdP2LYtU6NtW7s7WobGl4w6Gd3CTdzdilAUcLtEsBKC3T6/hxHaHYjb7d7u7t49yz1vb87jOM+q87ouluUe3fe+R/RfoiTZcds03pPgM8CjeEEpf4BvbdvXp9m2jSk43WUuronwUb+GqLteriwkIX9L8OusYPmncrobVawnxSrImbq7YFXgst9x/P6xDl6y7xH9dyjbStxceJGYLmCWJvYPfP//56attm1HcUHC3jx6L+4dvwwx5Oi997LV/sN+HBBD1lIkFIqkxDQTxz123A4DaUeHvNbMb0aj4Wh7x+8X0X9YkK22rQ4QE/sVQMVOGfn/ov+q2v/99x+kTJGTmC6JAVOMSrfU2ebNt3QJFzRg5ar8iYmmOTOLeyWxWXB60qqWkyXLdhbktIxRnnxLWWYBA1aOCnTlT4Qmp2fv3X+EByUx4L4ZNlUsp2d0tg+LNvLR/Xuzatfmy7dUCc8U6OWq/EnQzOyj2/sPHOS+Ym3vPnYd5P7b94zrAbq9/2AX95XAug4euNVthqgCiM63RAmbMgv1MlX+BDA9e6Ov85kFbNmaz7ZHWAsQI5kAWF3Z+831GcPkzPVveiurE1FWU4TFqu7035iV0yAi33h0XolIa4m26qo3+m52zxRGROWFJLw9wiLGcMv816rysjPZfaT/8dZt80uAv2KJsmUkV4itIleTa4EYGXcRRwKo6hs+Nmk4NsyqBOKAi5q4toJwUy7F5gaOzBisfFUqHpKKuGUxsbW2tYXrTLkteO7Q0JXJgoioXI+IyngNsJpcRXLlCmD5MlIG88+LPuQH81u+NJWXn+kjQ3u3LPmQXPSnRR+ILQaWkly2HFixElAda6TDMQ4k5gZHr1TgyijnJFK7ztBmWytBaKsh6QTKqw+NHBVo8n1dEkn6Kp9WqGTXWbaeXKNt7bqwbS2AlrnBkX8WhFW5OnicGPP0ACuWA8uWkouBD/gn44/nF0zl5efY6MAXW0U/XkSSkcFyAMppHGtjcc9tNXw2MHq2Yurs6EClodX1dLSuLdoiAzdAkk68b3jsknD2+EBlknS8IGmiaK1XtibC20PJJ1E5cPxCQWMbVbkTxo1UpHuA5QCWKn1AmhGtfAxskcrLzhnhxwA03/vwhx/8CHk8Atdz4SXnBkYnTpyeGB14PSl5qDbftogXJEm6qcAPWH1oeOyCQfJ9xU35BJPKlaKdq9evtsiEgBwSEwVgVfBGTTYE3RiN1kf0ApH6kKz88fN8cdGCVF5uruXGhrq2zFfSdn73A1K7SKFXWz0fbjLWMzSWuwyODfXEalyTihPtrdZWO6LjpxF4zvOHj4+fNVzOjQ51tTl+Ki2HOanDSNYYtEzEdS3YNzSau1wQVuVhlmi1FoXEmufxYuXCd6TycnMpNzbS/8WWhacqnycgkD9UG/VrFKp1sh6cRGzu8Mh47spVjo8cvlOdcHwvcBM1jLdG7RoQtM0NUvCd5HN9Q6MT3xqumjIPz1Un3XQAL0ky3+b1tLdn2olkC2Jz/SNjuasFYVde44XZ9pgFafmyKD0P07vlaVV52Tk5MTrcv/fphS2Yf2w2Kbfh8hWw2rYQjrnpqOzqHx6bOHnZpGsGu+fNqpi55IHq54FM5jcv7blO9XOdfYPHx3PnKgAr3zeqzAXWl079kXEAhrUAJDK969bKZ32my7xS0IBFVZ5oDbFurd29AiKLD+VF81sWnrYqLzenT+bGR0cG+ro6P1/AY1QqVx+wBAoIRu3xRNWdfX0DI2MTuZOnwZwZosG+fXeqEjWu+o3NI8csiYBwWj/r7OkfHh3Pnbxg+GdUvmbnqs6Ib4iRKgDbiTUtVV/u7Tk0qMq8VtCARVbeEmsLKR71hUsAJfNpH275PKrycts7Mtfnn3rcTPbzG0xUWB2F2t477rr91+O88OeHn3peanbOSnd0+FDXnVhCPsaJlKPfh7T5HD7X2Wv2qxmgU5cqEJ1vq/ze+K52Jqw7O7mly6i88HfTe0Gm+VZZBSsxc8qxokf5ifEjm/qHPr/RNfPQvf/G66/qyf558aVnIGGDtqfnzjv278P4L/7076deMCXjG1crcPUUZYyG+/aaho5vjlzKjrEN8Gs9yeSLnoHj4zmePCUnXp589WXUc6zA6mxrD432jH/y54efeuElNc33Sys9g3FzYL3jzp69JnTSJL6n8szF51wzD7+9/Yaa7AtP/OvcxWdU4HsAfg7gl9J6eu/E/n3GzX9//IWXX+cbeFfSPX8K4MToQNdziRrS9VP0xEiqBJhK03VIdvYNj5nxAa5UIF++jvK077mWOWwnQyWOX/jXky++qgZczlmz5AxuHt8L7L8TvT38pW5StO+NqMTFJWYe+pdNAK+/9PTDf1AkdmJkdIyFPHMD/ejr5V4I+QffsBK4cAqQ+4VnBcf10ymkUSuWVhZ4ota9/ccnTgFnzADly/ffkEnXC9IpEgDpewgBtK9bs8f4w8NPvySFxbtlXOWXnoGxhzCvpb5+AAM55sdGOWKSJnFxqZmH/8W33gBefv7RP118Vj2xwmQRhYncAJUe7V9PGe84LhyunDUM92pksGvr2SBGmk3mEqjYd9hw5uLpCuTN18JPwd6zqSDLsN1CV1amWU4rPfPxPUofgAceIgdyhbHREXPl+4nimHlU2od8RzNx+lSXMSTwENkP9PbQ9v6HJS6gLwo1CaqxTosaAQkMgefayLU8X74WLrxAVE9rv2bDjOaIeO+jr/wv4d+39SgPQGLCcnLa2TOX6JlHqr328vOP/dlAnciICYWGif38rSj56rqqSOqxrq03URPQCOWBugAK3xbyeyC4ADxf8iWtkyAQNogfkcoGUq+Plb0w2Q+TEhMoFJVTdWeBS9TMI9ZsqdOsqcqknSS4/3YPST3WaaMmoJmAcWl8DygOD0b6NIB1Egjc0EMGrcek7UFlaKSiquvU6VSEXfIpmUzFjLah4uCURuUOepAYvjksG2Eiaq+Xyx7J4ghI6dNXDBWmgjDTgQ0kg9ZLSTygcFKkK6pqTqeSn6YiLZGMVXdaJh8U6ofv9OLBp3l1g9Lf2Eyh1jiAovBSANJQ0i6rZeEm0e82ZWSra2LJT6Ms8WmCjCsHpnFSRb+JOwEfPtUp3NAkES23vrQ4VGJRV9cI0NuHoPVB/tWHVE8MKrF4gowyiloniQFxl5+Ast5kZLkMOAAUSa0IDRABqkkp+oKn0jaJKSPTWR1LzAwdbbun0YDFhL8GxVuAeFOJAFQrP0TiGqX+oEkafJCWA22Zztr4zFDd0b57WD60sN+f2tJMESA0lgrYMAKlwEkvZ1jJwaG2jmmJGfIAi3QnBgR8JC1Uq1xoKCnNEewwqBM5aKbHfE6ZVM/D08xXIi4JI2Y+oKGfJoAcB/r9ZH3mhbKh1FCzM2M0QB4KWi5P5iYmAUnR3lGtPkimLo0wGNVGuxU08pTu+E2e6oW3So/ZtdGLtEKOzoAdMVkAJuDI3e2dSjLiELeZT6koIJ/zU5M1nsq7aCoZakW3mo6NRnkGLc8xCkxRUp6VJFAXbag12rFbPZlOATp8hFkKjRGgdKT1AvaWuh2Z3ZtEhaAVxjg6VixMqZRnLTkT6AcVHGQRY5TwFWhKvaJugQUA9pbdm000xqCZJIsYlHbApBabCWLWA+SLLAIYNeEjERoP0nIPXGrSishb4Lp/s/udXxkFz/RGOCRxwKR5dkhFWApCP+jAEDBKjuVzPjIh8tJsKMGzlasSq1erjVCt8GsTjTJYNxojwBBwQKdLKtqAZKymKptpb1OhjGB0jPkjZXsmkTHu6zfSvgcuGSn9HApY7a7dm3/zFzk6Dwbr8AiwE+khDEN6mtyypyIPNZoOkOkRFR5aOoxn1QuVUz8vKFJFkoI9FdSgZHjnXTVHH7ydqNiZNqUyPafUTEGtHUCGO034ATLZIPKhvZlosIgXRQqBNcWopNp3fyPRTgTNJLLMtMN6XbVnxGlRH1mXKqe6NIoOZjqyFRI+NqIDYTat79DsuaB6NW0WFEdA0vonhUrY9fa7MusMVAStAlWkHN1hy1ZFXx0tFGS7wU5USRy+sXybsNE0KdWQJKHWA5J+UTiBmnATV6LoN7/904+fB6oC9nkVq8lOO9pc6hhpJLW0JllNE/CwXc1/hDvSeaYq0oEvFrModF4kSwbqz0wtaf/wYzk2q4NWzZpamBBtJDPMqlX+uhmForoWJryoR69MdkfEPZo1tUrSK4pkliHIHawzkdZ7v/vDT+VIRO3FwfqspjZGolq0OdXNDJUG7YdaxCTK9/R2eZzY1LFzR51132EpFGsphpoQGUBcIiUzP//LF182hTJoMcYTcZe0U8NMsCutImM+ro3FiZqqz8u3Te76Nu/OaAcAUv1rBiDcXgyJDDqQwU4xS79TU86vkYlLgnVDPEEtY8na6iOsngoqdwiSWoImPvPwJ3meeGf3TuOsJ2niHUYdANqLQ83od2SsSBQxNRiwxTckHChpkWTDZRFGRG9RaUDLaozHfKj/oVJQwd+pdi+h1qDRq3i9k4EHgPtVT3J3h6zOh+V9jJ8xfkrEXdlKiPqZhlU1MVW1G8r3uZydR4sTD94P6ZAkIGs6JHHIywBzpL04b68Mhg9Ua9cOUc8ZoXuaCZeksrhsn9VUmc5QcWJSdfSuLOsU0rwcyRf0yuDUZInVrgQ/iKidDyK+7z3vfpfALqfGiPsNaaYDZKsEHMqrUKy2pjqbHipOmdDtAU4UxlRTPFYlSBYBtdjlXpUYAh+MQEOEfZTLb37JLRocAPhIUNa70/K27yT0njxRxIhqB4XPnXZZqxLh+d17+PXoT5jHzOg+2VDfwOijaVt3bFd2ZCu7ak6n/JHxWsf7c+SgvDe/s0Kal88rqkiWuNN2rEqgfj6EAN61IN0GI21EBrbTmmwXTqcAP0n7SkEvd5NAm7oRBLouFh5X+XDcEUGu8vWddig+hAx2LpSxZaYhaY43FsALAOvOxlq2ItWVMxm7RPhdjZVxR6TutOmdQ0KY37drKpui62OIKIfq2Mw6ekqpI7pLu30eJZP+Yo6r/LTrKn8ofJgk/JC4FVojog5/zcDWbQoq0S1IegFwWp39rBWkjOM8mlICOGumVVNnTT3Jj+gGhAr5IUlohLg84r6+zmULuk+eqvdVR+ojekbd6af18c56p8ubY7zc5b4aGxK//Hdl8zRy+zYoVFXzRH1Et28yrOMdoHke3co4a4bjI0QEhiFytom1J5TmAOhZeQKxR0p8nMHN23Rzur5817vvyAD9uiy9alX+tnWdCcxBWR/dVIuCeub8elTCFqzTmgIRceEJeoHi2hbdnpyPIyIEbqpqPhqoK2Sd/bBD78PqjtmP3rbdxnay1JkAR4YHLNdmiCbAEl5PXDED+RIV3FFkkwJg3ckT2qJyLTJI69XkrrXrjtmnsmq8pffYEIDM5VBpClmPea/AihkWgRUq+Poh3Z4Sm3QD1tEqmw81LKtCutauK1Afi8qsbOi+C9nsMksJ6e9l8CU6cuuToyOIo7SeE9YPEfkEl1+9xXqntQFogjq6ug4Yrlo32Ty2rXO8m1yVRUCE9YmQKFoGm2hpJrVw8tVdJzs5SsnEGlEiOTlCOefy1YtnPcgoBNesx0bLeqGq5gdQ7C1b1p4X1HjXG82qAdSneTjBKyIkbs3AIZS8uG+tj2ysyQRH1u37F0whn+QCIY2NANYch5qsD8de4K718VIVCmC8epZreFwb5Siv80MEl/AJ4+MA/M4P1DIP5Q/WuIVJWl6jVVGIlic3rNIFOxiObsCaAFynR7um5GjVaGb78RovAdTs3vUbTvH+Fe9XkUbGeos98xD+DtJliRnz5LKCTMsXz7shrF6/wU0Nx8dsacbqDVCA1cZsf9epgWnu8XrpPr+o2OujI+PZ0sPX3TA+8evwkTGLDA1Pb2NyZRUxXNed6sWzJmcKP4n4hS9OwwbV7KoBwHV+ZLSrAXuwAJep0cy5wuI1Xtck4RgvAlS2F15xY2JlNTm6VX3wrBc2i8DW5h7D1nt2z3MSkytKLI1m3QcvBJDD0tX2c+t1cwAsU6NdpaxaDXLZHGkOZY93th6vK32dB6Xc6AoiTiRKwXYYEWefwJ8flLZGk2pgfNKubjdCsMvmrPZ1t/qZO20FV9mNtMz1hmXWeDdAjde1bdXobnvOepxD60V/p6c248pnn8Copcf2QVZWV+SyPJ51gzpnWtY17WoHYq60pUtcSC5ZOleaQxDj3WBt27keeq+DcmF8iaZoObXheI3TkBk3ZKZejTXLj6s9IxBK6eVHl1bUZJniScevsfzHRBzlJrl02VzVAsCVJFcRJFcsscwLBFesFCyxbRV5GhSz41NLND2V2rC9xlO1sxoiIoTjSB2C7cDtjC/L2iVEFsftaoAlCUtWqLCKBn/zpAlXM+ap9oXFf7xq09LM0kv3QdXeiC8T0VKccxx2dgqdcUPUfeA7G3EIKcgSyyPwGTOSLkaqmlGKvVA1D1fbWm2tXNKizbf5jde9aYl55eu9rpXy45siVSnTiChnteusFobzetUen5E1iigwhumxXMmXousmnSUuV3uYT3JeC77TSlL1SLRgvrQA6PE62NuWlOhe+E6nvwkEcBRydkLGl74C5/fVq5aH6axescamZR7i1LRU+grQfn21zBPfWIir/vPvp17yQAvJMvmPd2WrtW3nla/37EHF2ogrIpvfielX9cnJugIIwTFjdGpJkGkoxGUTaQZliOORZCu5RGq98BuqGU/7gith5QJbUONd0mJt29mBAt17QTE3tqnIDBAAgeldnchDc1gXr0QQUWKbgiyO5eHuWRLHI5a0LmmFell+w3L+4adf+sgDS2gpLfDxEiBsu12xksYtIIuhSMbhlwTRJ6ew7IAnKPFnEJknoW9VApQw92muiNyQFgRYn6+1ojAPQhV8xrxGZIqR6L72irn+LZFkCLMkzlmiARARh0GbMT4DejARcQ+FYzzleMrx+HXdYBZWiCtC5oFliHCQ5+vBqLGAiKDWwEFEodYLiBKixwuaNhyVrYgZxiIinLMEkdrsMGhU7cmUpP/O4CIKxzixjhvUOXMiULhhhug2UQYnrEq9HQGcR2EQCG2LC0AiAjQ0XjkhL6OrTnYAqpRGnAvDWOTCQCmzRKy6iEPBd5LxTYkiIvCQY/LyN2ql/ABWjYhklgZkiFXFa7TPI4AMFEutFZTCf1pOyBtZbj5ufgoxHQWmn5YbLQ6J/WbgdmKbUr1FJNsW/QYgjYgSnUduwGdq8ODaPTUyRHwjcYWQEYlIRGO8cqR2UbYSRpoZKE04PBhwcSmKaLcI+/o5aNXK+TEw3hXESNmVepMAGULB5WWGBhlssZ/cf5syBEA4ZYiQDH3xigKR2cv7dmeQYdvbRGpI9PPA+7TEKD0EjvkacRtxMNzDbSLP11ltopvrZ4hI2BAossTMlF2tt48igRzhGYCkaItXJjJ6/L39KycbM28DA7EqsSCf4YnLYnpIPOFtkO1L96QR/p4xseX6jVa74RezMhBFE4iB52cKeLasXy6IBQZ1F8iXOPriRZQjeC9eXdk3osHCQGQZABQkjZx8STd7fKFGO27ekgHEjCULLl+Bk+pVoWrEq4ZIggcrw087tdbuefibM7WKtQ6ZXwgVqIM7RX+n29MaLyKiQK/7DHzo/IaVjRkymyMBSQYwHAwRqIhC5npfMLQbbDNIcz6FRIIX71hgKVk6CkqFpCmMRiToQUPJdj/8I8ILv3gnZcJSk1wkofT/aJUDfmcPjfESESKjVGvC7zFcv5lPDEw4rsRGhUgygJZGMXCEEye4fhcy1+qc7LZAj70FFZHbROemUPS4te5V7RvwnEI9TsaIg+1J6IepL6/dwk1fjFVRjcQdpwy+gBAhXkVlBI3nL//6l7tv5jtxIyPziIgA9SMxAzAfpClUELabsQ4z16nnu+xwqTBhpPkWCfE2GYkbssA+vLhk3cKQ2W2Zh0Rmf8sNGu3d07C7rrz6093CTcoQCnc7VIQc+p079vVf+RcQIsSrFDGgfnH1ZqGTjJGZET0SBPAwegaZNFNp5hp/ebfd8N2tmJn+lCDs+iNxk+cPrePrUp4bT1a2R2KDrOPVW7sHYZ8IX9+3OqmBwQaqQqGlA9WMUSLnXN573tUYL0H8wMvGBzFT7PQoKQmgUnuoJ/M5nvk6zFzj0qWP2S7+stdMS/ppxuinOrbf2H7o5ScM4Twg7JFbx+Erie+ehXya+rCci5E5L4n1U6Ei1Ahx3ugv808+e3rjZXh+aQXMpSjrPHJ8PRmAU5Akc52H202uMUNIB7y6NI1OpbYdlDuGcHkBcg01u8It5KLu2UPP7pvgVA1CVROwE4RmrJWCs57OePmD61WLy2aGdxwMqQgRccpeRUPmogqZa+TRPtQtNshlQwONTilA311jLCh5ZMSyTqXGF30+DWnxeiUbE6rHCxRF5/nOiaJ/2OXPebyGLN5oVCtO0hQup+UVER7K1VI2tqAl8/ScJHOd718/5uq7VmJgZEQjY63oBz4lDBUjIjOW2ipWgZ2E/IvDWqUDXkhGRvynRb9xpi1eIvhrHCMjni8kEGMeoitz/n8kmWv8FahlJ5fqC5dwxPECz0kYcGIO84yJjuV69Sazo/C7l1RzMRi7OLOqHyAiM+4G4OOecw3xEjAaWGXwJPw8R8DYg1Pxyroyn5NmrlOOmLYataprZ1MDwwT9xFhz+cOaIeQqS87sxzuFYiUAdvAo/FYifjFlCFN+hPMo30c8g1yl1jzkY0pHvBninWXgVH3+I9KLOdl8RWQuu17gDSNz3Qrva+HaW4k428HolIOa7zIInuHgMSNGyaxVLPObNXA7V7h7Sa3qdOL9gRaJJbf4uwI7muMt+bWguhohrOVKUB9K5roV7KwH1ZJjbXWSE4N+x6vVg7JkyjHRwP4gnsgWbLcCPRXD0912o+ax2Atb0SVv2XxQtNoHGuPNF+yiX29gULatvGoqrOQ0jMz139YCd4FT8yulooN23qk1qO7nDNAx+rF4KtnJ5i3HLXtBHXhqtwTYA1Nu4FfLpehSrlRhU4P7PRGI14sab7nCcm62qFFTTazMM2m2cBiZ65azw8eI1KYm3+EhgmwbNc91rAKRRWQ7RZcVIWDxQA+fqr1pyVuaxY41DVInArfkeKIz3jpSq00gQOVUmjyu4WQ+hJ3gx6nVICKeLZgNvEoZkahKPgZCEeB9Jk4VL3xg6NTSIUSgqY9D4tUTK1GE+Ih2aSiZD0NOjx8LO4DsEuzeiLU6IhI1SagBIh6cRWhp3XLQE+P9F5JhZD4cOT/ZfyyItLlaiGKjCeEcP4l2Qw69nEgnH301jcyZ/syHKE+O9yNXg56+jh764a4e9o+eng8h3sOTqK15eKY/8yELnR0fMnZOzg9UKnT66G16pLenQYYVL3ztHCEs0pz5v4o8OgUNfXa0v8Mn6Z39g6Pjs/NHb/ufSv7vP/+LFQA=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">JILI</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="79">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_DarkenedFive__0l37G DefaultLayout_topGame__6ZwJw"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="BBIN"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAkCAYAAAAAa43JAAAUm0lEQVRogaWbe5Bkd3XfP+f8fvfe7p7umd2Z3ZWEFmkFZUAgBJICxmWrsPBKUQoJ2yQusFSkjG0g4lUVgxNRwZU4CSJGMTaxkCgkP0LJNmDFUFh2IhQFBA6OApYc4VilOAhRWmWlfe9Mz3Tfx++c/HG7Z+e5D/lM3emavr/n93d+5z3y1L6L3UWOZVX5++p88OjCbkJqWEsuQmwaOuMVRJQVUWJTk8eAmaMaOH78GNrrceFLX0p59DDLx5cQFRDhNHRvUL1ZhQON2cfM5TMxhg1NBEiIJ9QCiKNrxkwODoxGI0ZVxdz8HE2T0LyD2ZiqKVE97RpwnIx4eUb+ZUQu8fbrB2OMbzWX4cbWWQgcK8ccPnkSHDwERKBJShFHJDdGdYEGMITy5EmabhfZtQtSAiACqPt8yvIPVKoLsalvNlXEfd10oa7bHepp9zCBSlBV7PT7BRhbO89eg7sQHyPye5tHk3buF0BeCea057fVe3dUNdciv8dFLvHJvkW4dqUsf7Ux/9Ba3gkiLJlxtBwTRWncXtC6ItBMPsma5ibT6nOjbu8BNUPcSTGidU2sKjzoduvftJkYI5UbKSVke65PjmMOhmP4p7yqviJwbBUrEVZWhvR7HYJG/JxOwAiqeN4jnWbhDi/G05XJ7NQBOajodXmYfuVICCQ3FscliCAvlBuAuHY9LkKsm3d20/ABmfydpYS7YyLrrvgZyR2yjIShtjVX+OSXAObQ4LO52Q3R+dz0vYjQVBXeKc7qtq0ngSAsrAwxd3yb9ZvI0ZVOcRzYdQpLB+QZVHF3QohQVRxbXqEW0HjOi1lHce0fLoIYl8+qRlVtUozMHj3KYjJOzvXJ7RxO2AzPMhKOLy9DWC+7BTDA3JHJNpNDJXJ1EvmcAwmnGyJZlr3gDSaBuiq56OTi9m1UT3x338W3qdkns5TwiWjzIB93EbIQGCGUJ07gDtrr8oJl34Q2H5syV7vvqM2ozKgAV0VewDziDnmHJIrZRKSse5zGnXrymXAqt8HYE8vWUFmiHwL4uQmYtRTNODA7y5Nzc9u2CarsWV7+jbwqf6sRwXFc5O0k+2bWNNTjEYdPHKNqEiH83Th9dV1bfJfqpnEHakt0LYGs51bn7M7bzdBOh1TkNCsryBqLRWg5vF7leMHaLeOTQ9mdZ0T5u0jSlrpNw3P9PsGdPYubOd+ahoXnD1HM9j/4g127NK+rp9XDF1SF0oznTy5SBaEfwua1vMDFbQU8qII7TUoEb6/8ZPw97lwYhFxFnFYxHwAOmdmWilfMCJ0u9WgEZkxVlUw6nwK+ncEdL91YKDosxEhyx8yYWBs7gZew3kYx4P+6+6Jto0sAem4cjJHvsfmaJ6ALnNfpknvzfomCW6SsS4ZNg+GIBLAG1AE6OC9BmBOVgcNx4CTwfcHrs2GVTcC7iGR1TSMJ9cBKp7jUkH+Yue8XuBTYU7jRKh0QkUPu/vhgZuaBWvWPVfUpWWM3mzsxy9BOh3JluVVSTK1zp+GUjGdyEAHYESM14G7FYKb/9hjjjSL+epAXr12vCLj701meP9KL4X53/zzQbPIfDDKgE7fkNZEQ9ixmsStl87TkBUWvS3lihE5Wp2aausXbROQtAlcCL/MQ0NA6Eu4kUX+y8fgXjfn9Iv7lbW3YrYBPIVSDpaWjVbDddXf245XKz4rTC9vL2T3g+4tud39M6VeWDz1/r1Xlr6rqoVOn6WTdHuPRmMYcEWk5fp2oaU9jxZJcFHNmgBL/oLi/r9fpvMzd8UnbtaRt330xxn1BwtvqJn3EkTuwdNdaOeBmhCxjZteu1fnXkKPyKfCfTs5DnuyjGuRRAcyMbl68NwS9hRAvS+6IrcHi1BRBxF/ZEF/p8AtB7S+T8xsIv49vRm6Tpoh1M16amflA2Rk8lov8gpr35CyUm5mhqrPl0vC9ddU8hvBTiGCqmBlZlhE7HaqUSLQeXQIqd2paBTtKRlA5OF/ks2b2oLp/SkRetkbUbE/uWOspvdLd7mzK0Z9YY7s2+hDtAQu+8XEGDrmK/INg6RvV0vACc49B+EonLz4dQrwMM7YCcS0JjojjyFUi3CvKf0Skt7HXFiraX4HIfxDRC8+42U17dzRGNIQXNfiXQl39cnc0AlpB3On1IASSOy6tqKndaCZWzVJqGGj4sV4I/z0J+89p8unGJzgnlxvqRv6SVjy279pFkuzUnGuecfJW3tfuM9V49Kfi/oio3mju2DlicQoU/nE+030k5vkFLgIxQoxbKFeZSuiNE636kocdDklr412AyMJ2CISUPhFTIoVwuwFFnlN0CxaHQzqaUeOUgLozNmM+i1xSdP6ebeMviDM19Q4KLAMdcd+7jqcnXSeW0kWV8ZA5rxPh2VXV6w6yXhE7grtgtNwYRK7AN6OwxrEtHX7gMHJnthK5OLrrWn3VTuVIFi/LnYeq4fANVlWLYnZ2vqBDMtG7cfbjXAFyBcaVBq8V53qcz08AWd9PFVP5RG9l5UNZXVOrMtOdQYK2dvuE+4YpMRsCr+n16apSbyXY3L9Xq3y0CuF1wGtFwhXiXFGFeGUj8s9w/9uN+ItAci5QuE9FqGktqQZaa8mdRoRGFaPldnHIHDYCiAjSNEhVf8vg3e52hYhc4SFeKXDFnqq8Utw/1CBPNBt0iDvgdmlWV5+TxUUYDk8PvLsT3R+yGF/VxOzdavYQ8CxQAzXCAeABnJ+NEq4S90c3Qya48O9Dqj+SLS/TyXJmejNtDAcYmbEQI1f1ZuiIUG6hQB2/DfFXNSIfa0L4juCHgKHAkSaExxJyu+CXOXzC1+qjyViGv8HwW6cH0j6KqRKahNY1CUoBCjbbIq1TU7stzP9i2rPnR72q7nZ4QmAFsAAnF+rmf5nzSUNe3bH0UdYGz6a3UPQn40zv57UotgdeAA/hXg3ZfkWePJ1SSSrM1M2js8vLV6cYv7zxvYsQkt3WKccfJjUMujOEoJRmnfkYeU1vhk4Im0B3kZG7vV2T/wtESoFNUVNZ7SOVG/9c4JYpWFOQJ9z8Kx33PV13ZpqGOs+pegPmTi7SP3KczNnZmXDq6gzS9nXxw+L2oza347fTwgLSpPX7A2oRyhA4r67T6xaXPjYqOm93DeuUsbsTO53bK5HelsA7oGbf6heddzQqeEpbNdsAQELNVzTEnwb5ylbgm8rt+XDpwwN38v6ATozLl3d7dIBR2rSZhxO8AfjC2YTmplKuSvaZZPzLqUs25X+DnsO7xSGqEkSxlEiDOWxh14c76HUbrTdrYzbPZsGvJot/QV0jdX3aHIMCMRnj5eUvNE3zftmQCzCzeRXesSXwAk0oincGVYoQiHl+RnPSac0yHFz1Jx3/b1uODLdTVx/ZI8plVXOrZvnNSzG7w83/2Mzvc/g1c64Bfhx4/AzTbhq+Tglz/rWofHu65olPTCX+M6WImCqu2oZ+o95OHm9HJj7pmj4hpScW3H+kgCftbGIDIkQRCqAeDtGy/HRQedhXsW+98JjnN8VNOYI22fFHmuX/x4AsRhqR1czJ2ZHj6jeIyZ8C16x7owpNc1tP9MSLFxfvOizyB0d37/6D2pxoaSL7TpO52LTX9sBXktGIELMMEcHwf+fYf2pj/bR2PrwK7LXS2GOdpqHjfgfwPszXxfkVWAzKhcvLvzsbi2eW8tje+hghyzbZ8k6bIJkBlkPgqV6PHUy8ZJePA2/cgM6PxE3bFHDn86PRMm32p32fAXYuiSCXEWrXuunXBX5sA1pUZnd+f9++auHo0d9+xZNPcnhhgWF/QJ1FNNXEs7CbVRUVYTklklnrkYq0Jpz7g7QJlfkprAbBlb3u8tigru914eZ6Ioen+xegxLHkPNftFs+LkFJ7o1lcJISAx7gO/EKEuqp4vKoogToEBkA1HtMrefDiXvdpR/ZND1cgW7Xj12xzFGP4G9mQ6xGAEDGU1CQ2nrmHgIVAL8sQTyzVDSIk1N6E6X8B3rSmOSpCLXLPiX4/C2af2X30KHNLSwz7A8adgqpTUIeAmUJyAg2mCtpGT1Rg1CQWx+PWcYN14WOBJYRHDfZPFW3tRoG+OsvyNyf8ZqdVzmv6MMYZAQFIIQTHUQfJMjh+vFW23QJJDbijKjQiHAiBOiUyIJt45wAuYu48Br5vLWKRzZLmsKBHJpnOTRQEXAw71R4XJa4skZUl3zl+DMXZ1y2oWpOqdrUbxHST2MmrijrL7npm797m4qefvqe7ssL8saOAUBY5w34f9TYsfWLQpxiXlFkEVZIZBw4epG4aouqWN7GY3/m/ybP9nlpPNSLMavw3qOhE/qxrXzqMaUXN1Ms9BYy3ogZa5RqyNjVqxrGqInU6XL4hhD1N9lRm/0/WyHmfAG+0BzxtHMqyDJPQ4+bdtMlhXBV3IwGugXxpiW5Z8vjKCl50eMWOi6hWhi1rioxc/VpMvibO1atDiaBmZMPh3c+df74MhsO7dx06BDhFWVKUJQAWAs/N7eD8xWNYkTOa6aPudIqCIs+JsrVVXItkjRsNbWXCfMzIRLXZGHtypxSWS2EmnKVuQVpRNxqNcTMyVUbbiMfpeax9q7Sx5LV0nopcQIw0eU6T51iMLReIICpYG4td18lDgImo6YXQRh2n7mB775Jj1+L8140L0xakzy53Orcszc2RNoRuUwgo3ooab71ORNixcyfdQR/rd5DZGeh3kUEXBl100EVUX1MnI4iwKyvIdBInmkLgLejk2QeSyhd1spazfaZi6jTJ/LVbXPUrJl/4gQ2NoqlelVUV8ydPMn/yJDOjESlGREF0axG0kWT1F6vgi0vp7m9xWG9qipDVNY3qnc/s3fuucadzmoFPzZ/HyKDTAVVGdUmWReoYMIEKdo/dXp2LsisWRBHSxlIMM9zslkb0DpAQfFpMci4/50ZT1ldxvrvxZRXDTd3lZXYfOcLuI0dYOHaccR5pY+JnHriV+2uWNBF2gqJuI6nr68z94Y2AqjvF0tJnD+/e/a4j5513asxtOCqZEUTZQSSOGg6vlBTDMTEpuP5Mrjq7kBcEFRqfWvMTr9YNKfKf117vM1VZgvmsqKDC2T+6RUxnG1Dc1wXY0CzL/2xjyiyaXVd3O28c9vssDgYszs4Sm7Mr3GkmCiea/TDIvwX+M/BtVB40tztI6doYYwKuBx7c2F+BKoTPDjudf7I8GGAhEE7jQ/hUdATlr44dI504wbKlTozhlxeygiCnQMcFt4S7J0Fu1Jn+79LrIQ4B7FxFzTmVu6yzEp1YNs39onoMmJ9+naVE2encfWDHjitXur1hdzQmG62cdlh1h5T44T2750zDr43H4/cg0lYnTGPkTbN//pJLvj648EIO/PVfj1eWln4qFMX9WUrXqFnL2SJkVUUSuesHF13UvOSpp+7pTGL629GU6yqgiJF+t/tJEfYJ0uqD6Y4tUfX6S/2m/kcvPnjwq4fznAOqiBsq4Wxk9bo5z9bJ23gnHNC6qlcw+811L0QA/6F8PL5/Znk4CJZaxbYNxdRwZG6OA3t2X7yn2/na+Z3iPdVaTQKkuqZTFG/duXfvfbHfpz8eM7e8vDK3tHR9SOmxtGbTPpHjxfLy3Yd37rzl2Re9qA2GbSPn2nScceHMDDY//0+7Md7iEyV8SpEaNfb8rDfXLlTVV7tVRRwOSU0i00CgLdg61+dcoF/rH2u5skJTlr8ehKfWNxUE3tgZjx8JTf1m8G0PWMwYdYqfWx4M/mdpfkXZTF1/WuGWEmFm5m0hy77kTQN1za4jR7jw+HHOP3SoWllcvJ5u99sb5aWaMep07hz2ene4+x5132RNMakQ62TZ3mvOO+93ur3eJ0fNhqJbQCT8rfc611zw7DOPLBw8CMDQjQxrjQZ5IYq1Bf5Mz/Rj7cqjLizQhLBSWvPOWFUPs4GzTfVSTel+wf/EVb4ozl8Bh2lt//PBX+8qN0W4euJbb+xPJvKOUBRf9KY5lbCezFMDMcsO7RiPbzg4Hn+11+u9RsxWFXRMCVJ6n8FblwaDP0zuD6j7AUROAvPJfV+WZdfmeX5T2TQLGwNdbo5b810NxZtjlj2TQgASi0XBsUGfzBqmEcQtioo3li6vkjBJtLTJltNKHVmTYp3yfJRelyQCI/tGZvYuVO/edKFFEORGcW6cTHAICMIk7beFBHDA6pqi339byLIvWl1vK0OLEBgtLh7SGK/ph/DwkvurN1UrwwVlUfySuP+Stsng44jMT8XSagJk2k8UK0c0yf5H2Lnjesr6JJNCXIDn5uZQAsFX4yebjEN3K08DZmusNYkm1RPVvBUOThR5TteUMBoQSQmZlGW7yz3uZILfedq6dmfP9i/bzSuUsd9/R8yyPzpzSBmaPGdnSsfLQ4feVC0sfL6An1iXRIC1xa/CGmPgVPh34tC44/WYbDD4Ut4f/NyorhdD3YqfPCWqkHGy1yNvmnVQb5F5+saZ9klREIqcsB1eIpDsz60uV01ZfGNdTRt9vMuRH6jzW6byEl1rFZwNuZPgO508f29/fv7bS0tLq1x1JkruDMfjI+7+9wV+09zfjzsawunLO1a5fZJwEfGVuv7ERZe+8tbBy1/O39x3H5m3llcS4ejsgMB6OTKNbE7Hq5rmCTqdP5dJVd2mKWkjtvnOnTyfEtl2wKtCVX+te+jg96LZS6cjbV3CJ/JnHuM3tao+JO7vRuSC7ZyYDTGd7we4q86yXzdV85S2XPTpKIRAEkmYfSCo/iFwazK7USYBj81c2RY6tfX1QpbSF8YzM7cdGQwev6jVD6ttY0oc6c+wWPTImmZj7KRQacdDhN5g8J7Q7ztbhEcmGKGqXPXUU7xicfH0Nr1IejqEX3w6hq9NU0pb17O1lsLS3HD4r4bd7qeborgupLTf4CrgRUCBu4jICNUD4v6Imz2IyFdVdelsAD4TpZSYHQy+JTG+5diRI6/P8/xaRH4c9x9y93lE2iidyBHwJ/MQv76s4cG5Y8ce1TwnFUV7E1Y9VgeUxd4s4pv/qUDABKEx+04sso++/PLLv0mWbZ8AmoSoeeIJdtf1GfdzAr5ezs1cm6O34v4T/x90tv9uXZoOKgAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">BBIN</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
                <li><span>|</span></li>
                <li>
                  <a class="DefaultLayout_menuA__Eilgx">XỔ SỐ</a>
                  <div
                    class="DefaultLayout_menuSubList__mx2Ni"
                    style="">
                    <div class="DefaultLayout_bg_menuShadow__Rjze1"></div>
                    <div class="DefaultLayout_subList__-8hVJ">
                      <div class="DefaultLayout_subListDiv__5oE8l" id="76">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened3__sPxlF DefaultLayout_topLoto__mR0Sh"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="GPI"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACUAAAAlCAYAAADFniADAAAEYUlEQVRYhc3YW4hVVRgH8N+czqiQ2UgJ6mAWYaWWgpmVZPnQS3Sx0lKTLg+lhfWgKAaWhSQURVFkZgUVdFFSzC5UFCFdLLIoJbQLhlNYhlKW083J7OFb271n5syZc6YR+sNhrX32t77132t9t7UaVm08VZ04DuMxEadgGAaiEW34Gd/hC2zEx/i2ngka6iB1Lq7DBRhcxxy78Cqewnu9ReokLMZMsRoZvsdWbEMr9qf3AzAaJ2NoQb4Nz2MZvqo2YbkbQlfhERxdULwOa/B+ItYVhuAcTMPlifA1uARz8VxXA0tVlN6LZwuEVglbmo4XuiEEPyS56Tg9jYempPfuekmtxILU3yW+dCa2dEOkK2xJ46clfbAIj9ZK6n7MLig7S2xZb2Bt0pd93ByxI1VJzcS81N+GS9HSS4QytCS9mbEvSPMeQtH7TsRn6C+WeIKIN03Ci36vY+IG/IOfsK8LmeH4UISXVozFN7T3vrsSIbgxEYLrcUcaeLBOUj+KFXlNeFtbQaYlzfNimneZtGLZSp2Bj5LwWmGQRbKLayRTDRuxMLVFrMHU1J+ATdlKzU1tG5Z0GPRran8TX/UH+nRD4GD6HYtxYvsn4m1ciZcKsktE7GrETRmpQZiSBNaLKF1E5gw7cLXatzBDM27A7eiLZ3CmcCRpvpdF2LkMi0oi6jYlgdVVlJdxVJ2EYCfuFNlB0vFQB5liYJ2UkYI92FBFeYPqGaA7rMby1D8f5xXebUjzw9klkThhc+FFrWgWCXtYh98I9Ksg/wT+Sv0LC//vxuepP6KclNDZlmrBY5gkdwbC5o7EdhFONhfebRUh4rT0MUVswWQcX5bb0y89INUsbKSSrY0XLl4ktV8UgXReydbUNpVxRHr4uwekMkWf4k3h1iURDFt0dpx+wtszgkVk8zeWcSA9dBd7KqEhta/oHN8qYZx82zrm1CxmtpWwNz3013MMqFHuFvnOfNLhXTb/3pI8x43+D6QOdC9iHmak/h6RD4sYk9odJXyZHsaKtNATdBXl+4no/bSo0zIsEck6wyBk5crXZXHCmJ8ITRYJsl4yM5LSvsLQs9x3jIiDRXt9Eis66JksX5APMlJ7RWiYXiepgaltTr9q2CmqzAcrvMu2dS/eLYtouh7XisQ8Su2BdAP+FMVcEQ3CzvYl/ZvwusqHjVG4OPXXYXfmhssTqUYs1b6eqoabxXbVYuhdYan8PLmCPMFukmfqqbioRoUH/yOhKfICb1Xi0S7r3yaP0I/Lc2KDw4Nh8iNWq0J1WyS1XX60GiziSEl+OdGb5E7AG/I7idnSoaEjKeKs/0DqjxYn3JG9TGq4KKszvfeleQ+h0l3CfFF6zBYlaoZ98pTUU0zFw/IVWikOE+3QVSU5R3xBEUPEdVBPMEasxpoCoXvEEasTqpW3CzFLXmcNxlvCS67Q/pqnEoYmudUi+RYD5Czc2tXA3r6f6iOy/UgRFHt0P/W/vMnr7tKsiHfS77Dfef4LtTMI5Eq5HBsAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">GPI</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="3">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened3__sPxlF DefaultLayout_topLoto__mR0Sh"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="KU XỔ SỐ"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAtCAMAAAAQuiwzAAABEVBMVEUAAAA5n9g5n9g5n9j/pxr/pxr/pxr/pxo5n9j/pxo5n9g5n9g5n9g5n9g5n9j/pxo5n9g5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9g5n9j/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9j/pxr/pxr/pxr/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxo5n9g5n9g5n9j/pxr/pxr/pxr/pxr/pxo5n9j/pxqnntYWAAAAWXRSTlMAUCP9hvr2FwsFDqKcWWRPBPc/PBAHh0MI8/KAMSQZDdi/rZdqFOfk1MnDkpGNinpXE+3htrSup2hhOZ9/cVJMSUcsKR0L7efez4lzbTjXx7eWeGAaultNHyQiKA0AAANoSURBVFjDjdbXWupAFAXgFYoUUVFKEFBRBGyASMcGtmPvDd7/QU6iQGYNyeC6UpLvZ7OTmdlArhQvHfc0rXdcisfjqTCEnKWMT+Y07XQuZVwsxR9gZK17sjDOiQ5K9NZj5fYIcPXFHPghpNGnzAZh5Dw/ELLDfHogJqnkNxcndJOvisIh8/t/5yP/7HSkZ0ShqeIzMn8ds/SCrY4lErIq/kPmG2En3Q87fuZexddlvhZW6NP5QJn4XZlfj9n3PQYHvsX8LvEemZ/9rf5B0sXV0KV3Q2e+SHwZiBCUghmt4KzjXgSu0ip+H5ib5Df7lBDpKBPfUTXnRObjpu5mPQbKnQjkfXTt8oP4tMS736bqzFdBWXsi3ifzPXknCPkBqb0qfkfNa3Y6C00R2FLxmQqwSXxjmo7ohihsSBe3xItPUcT2+hS1ztVP8hUvbdbEK3RF9Qo+myDeQedcZBS878+8ey+I6fwhKB3ijwKIvTjoxwBckfAEv5IUAG8ZlAV50QbX7fV5AOHa4qqs82nqvQNFp+rbBr/trIeM3WwKfwRKi6pfcuAXTR0h8685me/Qdr8Pyi3xK8yz/vtQrnPgtGm774BSZt6298s/+uvwvxcofv/MEu9HTZnPFez14/Fo0mP+XsXvyPyqW6Wb2ab3P5FV8Im8A899531ujw6MQwWvzzjwXPvDgfSNVqLPxOvE81GYeR/xrCPHz/vxzBJ8W/Tee0T9m3tz4wM0gl6Hm8Ap/6aa3+JvqPpii4qnNNcMiJzxIgr1KSWrOXUaFD6rJ5ejp9JKMu8JABrzwnRMebN/c5Ldw0FTT79HKyt6fSCla60emUeK+YOI/apN62aLnjbq1YGc6jeAkgOf22b/0YXfnHvF3ncrOwOHtLlK5jHvZn97dTSI8Y655KDfXMAIH1YarIT6nPWhn+YJPnDLLC+4GhFnAh+z2sMzfpmHwMqzjZ7/wk94Abkg5Oxa8hs5mEkU+TzxTbY/0xkaNSeefe7PZ54msbUs40mPb0QUFDxcs27JH76f70WvOCsEdKFBV57zwFhYVvEIajW+oTBcX4mVVt0rDAuXnbuNLSM32f2LBKDgOUHXaarxaN212HgYTYPn7ezPzLP7W2zUZyYByqkmxnYuC/tzqzlXb3RPJGgdH9EL/atdXIBT/gP2U0j1J1W0LwAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">KU XỔ SỐ</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="420">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened3__sPxlF DefaultLayout_topLoto__mR0Sh"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="Xổ Số TCG"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAG0AAABtCAMAAACcJh9kAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAwBQTFRFNDQ09Hd6+sLDd3d3+bW37igs+KGj7SMo7iov7z1C7i8z////NTU1//3+7SQp83N37SUq7zE283N2NjY27SYr//7+7zI3OTk5R0dH7zA183J1+vr6S0tLTExMNzc3ODg4Ojo6Ozs77zM4RERE83R3QUFB7Scs/v7+Tk5OX19fPT097zQ5/f39SkpKRkZGUFBQPz8/WVlZT09PRUVFQEBAUlJSjY2Na2trVlZW/Pz8+/v7qqqqeHh47e3tkZGRV1dXTU1NYGBgYmJizs7Oj4+PampqYWFhUVFRZ2dnPDw8Pj4++ba37zA0aWlpQkJC+Pj4urq6U1NT7zs/7zA2lZWVgYGB7Sgt1NTUQ0NDkJCQ5+fn7zU5ZGRkVFRUtLS0tra2paWldHR0kpKS/eTl7jI3bW1txcXF+bi5ubm57zg88vLy4+Pjzc3NZmZm8lpd7zc7Wlpar6+vSUlJ7Ozs9fX19vb28/Pzb29vsrKyuLi46Ojojo6Orq6u8PDwpKSkXl5enZ2d+be5xsbGXFxc9oCD+be4iIiIe3t70NDQu7u77SkuwsLC7jE18lJVhISE///+//r57u7ufn5+8E1R8U1Qp6en8mFl9YaJ8EFG7zo+8lte7TA1/eLj9XJ08URH+8zN7jU67jY582Vo8lRZoqKi+sbI/uzslpaWWFhY+sXG//7/96Cj7ikt70FH+fn5oaGh8ExP95eY2tra7jA0/efo7jE0/u/w+9DR+9PVXV1d/Nze/ebn82tu/Nra7jI23d3d7jM3qampioqK7jE2+K2v8UVKyMjI8EhL+ry9+sjInp6e/Nzd8FBW8VNX+bm7z8/P/vj48fHx9Hx+956h4uLimJiYmpqa9GdrzMzM+KOmysrK8Fda83Z496ut/vHxvr6+7SUr/unq7+/vcXFxc3Nz2dnZlJSU+ba2/N3f/NnbaGho815jsLCwsbGx+8jJ9o+R8UxRqKiopqamoKCg7jk97jY6829y9G5x/vHy82JmiYmJ9oWJhYWF8ENGW1tb////f0tJ8wAAAQB0Uk5T////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////AFP3ByUAAAfcSURBVHjavFplgBQ3FJ4C7QAZ9vZu73aP3nHGHQd3BxyHU9yLuxQpULQtUlyK193dXai7u7sbFerubsMkk0ySSTKZ2b32/djZzCTvy0te8t5LnmFHJQBGr+tjGN0uWwlA1LZGJKAhluEjq7AH+A/QHheAGFpXr2iDDC1trye0VUZIWp852nQjAnXIDG0I5VQI7LYyhFIbjKWltumjTfWYtEHlnjK0lujTKV55aHpogLQvITr+vgxtBqleS96ANNBKcNvl9NVGGdoE+r0DfpWIikYEayGVlqWD2Rr98MvRkdBaSDspRSuQDsmUCGiKCZCiqSqBkGge0zpFLwLRTghQFglaL8qpSwg0X5VX6ZdDQqDtw7L6kJP5UxnaSKAc7KFatC6KcQLt1BtWJ6CY2Q4atEPl03KQboccIx/qxYFoq6XzspYtV2ypBK4Nn1XLvj9SOq8/BqBJVbw7NdRjRD17ocj7/IBWZQ2tznlQPZQbapBZ5+CMkGD5wZapfUBTBVprZYNivaezr7JxhRQNhBoMvYES6GQZmqry5rBu2RHasaT/SjMRLFg8S0ADmorhqFjO5SU/WoAqAjOQYjH3CRjDqBhL8hyIBq3QV6kz/DTODEnjYe0vfSxaoEEby6NhS80ZAGMI/BI3Q1MM1p/Hsehq21VUOIPxJ+BQdGdqtoNfzEgEW3RmWLxNJKlg0ajDA3gFMc3ocKU+fR7kCWdQt9SvnLDQrFleM4/y8tzfPMTXeeaRl3m0FqtxgJmmfIrG74TadeZJEbzuvPJiUkI/lfzmWakJIABVeAW9DjnM5LepLQQNWoyUbwtD9lJOJyG0+1WfAcMCU0tcNAh72tWFpGimSWQs2/BDC1y0CXxHYKnIed6SLtoxTuMKkWdHFw3+vYt3J4F2vwoiMpYTPaZfu+CGMJCwNMp5xtJHg2M5WBQOQLSN3HtAVCQei3FbLyrFfX2I74jFAoTjZfgYoqW8ANPGA640M6AVZvegB6dcCJBtsVf6CAlhyDpRI0W6iN1+2Vm9+EWgWuK+EkZT1IFL7tbDpn0g03HBAPxSfsc17GGUKAUwXP7t+8wZUACrXokHMkgHxrntG2v0BHphfWF/e0x+7V9kOecb9hrB0M4MRKMz5c2iXE8KBMbDDIn349S8T8XlD5tsaQjweVW9PeTOhy11IqS9PhvIbAA4c5LCjLtW0rK0aHzLud/xR5ESiwPuOWNE3DdxlgsWjFYKGwf6cTr7hhlsx2gIFU+S5xiQPgzUeo1a++bSgYhrwrIsT0IGDb+pDIf2VCjXmaAVJRDvowTZnE7ftDMrJ8uhnKzy8vIsl3Jy9nYp51c0Qa2cf4jQtxz4g+o5DWDxZawmrmCJkhRiv0ymJOPNjKmVD60EoVkytB2Zo8V4tFTKUvrs9YBmUjT4W1SM0K6SbSWNMweL0+UNfxJFCG2ADO0f1KAsmZ2d3dwh55FMZierp5VlJ8uqly6t3hN9X1SdTJaVOTWch1MVVmsOKzqPEU0X8bJZiQS3AjxyVsDluvUbYn1j64XXFX6IaF2I8dKh/RZidXsrS4VWEqLvb4QRrq8hKH2IXVmY/ZCbl5WRxaERIUaLae4aJKyHyZTyTh0aH3k8t2TJOTeGQustvFobNJQxVk/wzL0jnUXRU6jFXlD+2InHjobmf4POC8LzZp9Hhbsd/X3EjzYMBdMO0+u39e6MTrW2qTy84yXdvYRFo8JdZ8pVRurhKbxXxOFdrvlp8FUuKT2Dapz6LJa5cUjvtZQLg6fgoYyLwj3ByWaL4X2AZz6boBXIow7E4yz8MhcSoyWP5ppysAaopjzq6O9FVPxw53tdB7bv7MlFe4vHStrCbKoiKpuPWvfjo0U52rXcoqAixLmA6m/v/dE0WrxB7AaM+ZujlueGQPOa7jSJItUqI2HfEO/PR/kXytBekc4a4KP8btIoX3mC4U0dWDC80fCtWw9vNHzBk6jKrm/fQ+7zXxjuRAbsCvEEoy17guEL2mpgcbDzp4mp3eq/p5EPBjuO3Jhs4vv/k/bkCXv2VwfAfUVGc5LvtISZnNncyZPdUHWqhjlkB8D9Lk6h7FRtVJQTQ6A79mLAqjQnhnYdeVHjv8kmbC4IEO98DqyOYfEmEaWTcNLrCPMNfybMnfTuFYDXlK6OkRyL6dwhFEHbgARv4zN/hfDTz17PqwPG817THAGfQ30sOgImoUBzQt/SPzFzNZ5PYagT+uDbh9t89jv384ADIKYxCQlXCzcrqaCbFf9ZzAFhbla8kNSKcGvkmgcQ16I9LAGzFLdG+huxxyjaF2GujIj3ukJ625evhCsiuvEZlvDuCLd9naLfZLZjhGhwaZNdmd9kam5puyu3rkRat7SKlA4KuFCEGkChJke8gbbXSwdiFrfgn0Z21PGBN41i3zeUjs1DgZkDP2SUOSCMzTxNVsSfqqyI/DSyIpZFy/joxc1qbxlUT3XGR9cQ2SwraPWp0XNnbo6WzcL0b3M6mTpdo2Xq/M9ZSPQi2QKRM6yKhb0nQvZYfrTsMZJYsSpqZhzxnDrafEDipzk+lxjfp6Wd9ZcCbITgJ+Ltg6pMsv7IBT+ifrboTmHq68to7J9+tuYMLltzuQytymYTDlpnlonaP0omal3mWbYrw2J9Uk8ZxGv0UH3qL1/ZoflBUKeHZBIp87umteB0FrcviJDKs1uAAQAdWD2YWDoJ4AAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">Xổ Số TCG</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
                <li><span>|</span></li>
                <li>
                  <a class="DefaultLayout_menuA__Eilgx">E-SPORTS</a>
                  <div
                    class="DefaultLayout_menuSubList__mx2Ni"
                    style="">
                    <div class="DefaultLayout_bg_menuShadow__Rjze1"></div>
                    <div class="DefaultLayout_subList__-8hVJ">
                      <div class="DefaultLayout_subListDiv__5oE8l" id="174">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened3__sPxlF DefaultLayout_topESports__fDRkH"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="SABA"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFYAAAAcCAYAAAD7lUj9AAAPOElEQVRogc2aebDkVXXHP+fe+1u6++1vNqYYUEfQYaKSOCxuDCCbg1QZQxYsY6KIJCIaTYnBxJQGtzIYJSkti6FMKalULIkYISxSCggDiERAgQg4MMzA4Kxv6dfLb7n35I9f95t+PegfcZzyVHVVL79zz7nfe+4533tuy+nv3kxfRCAEpZsVDIoqFKVHRBDAGMFaQXXJY4hAWQZKrxizVF9VUYUksdSTmP1z7bcZIxcC9wJ/V+lX4wJ4r+iQAWOkNxY4KzhnUK3s+qAUZaDbLVh79HJete5IullBGkc8+sRz7JlpsmJ6jPPf9GryomRmrkO7ndHNC7p5CQql9xgRECGOLHFkWTE9hjHCXQ/8nCwrsNYs+tLNCuabXYyRAQwEI4LhMIoxQlmGsxc62cMico2I/AD46uH04XCJO4y2BPiU93p56cOD1shLgZ0Dvx8FvFhVVwIKLABPAj8/jD4eMjlcwDaA61X1TBH+1Yh5F9Df6n8AvBfYoKpj3rOYYkRoAVuA24ArD5Ovh0QOSypQ1f8AzhSRa4F39b5eC3wbuA44FfgW8BXgemvltLGRdJ215mzgYeBi4D5VTjkc/h4K+Y1ErIgsFkLgKuDNwFZVvbj3yAZV/S4wKSJXq+qPgDOBl1MBfIe1pkoeVcReBlymqm8zRu4Hur8Jvw+lHHJglapKW2MoS382hPdX1d5cEoJ2QtDjVPVOhDrwflW1Ap8Q4SaQPwbdjnIQIwA+VxVsiUH7oP/Wihv0X6TKb71IWxRV8CEs0i0wi88OSj9KfQg4Ky+xls+HIKjqPaC3ioDA18RQD4EPG5EY4UpVvUSVL8svAUsB7wMoGKu5hkAUOYLoIt0KQQlBpSi95kVFDQ+lVHRxkAL+6vHdoH1VEMMFSeIu72n2y4im6i7t0aMjVfUaERKFMDiYAFFEoao1Y2RdIrLciNDpFlfmRUmSuHfGNbfBGtlSBt1ujHyDoFctdLIv94BZwn8BSl+ZWDY5Qj2NUZSi9Ks63fxrRiRS0J6jUezD5ZNj9S0vXjNNNsTFf10xRhZfIHgf8D5Mqer6oOQVgBhjxPkQHnQTY7UlA6jqa0GORRZBMwJzIL9o1GNQTm518rN70bdUlyp6Fj8Aeen1+OPWPLVnf5Nmq/vXzlqsMVcg+vGyDOSF//vR0ZRWO2eu2QEUkcrx2fk20+MNjlgxQRxZrDWoKiJycl6UZ2k/I4gQQqDdyX8x1khZNjlCu51h7K9fm31Q4tjx6vVH0WrnOGfpdHMef3oXIH81Od64HNRXbogUpX8sid0Z7shVkwOgQhTZS62RS/sRb63Q6Ra1bTv3d5LIUavFZ46NpkNo0gVuV2WlCL836FhRBqbGG3kSu8Zss7PeiuxQWBFH7uT9s63vPP70rvk4shhjqNdiZufbFEXO9GSDjScey9R4gyR2FKWnD2Sznb1egyI93EKAKDLXGWTrjuf3027no6rUQ9B5Ve0UpSfPS4rSLw2E3tYOQUGZDEFHEARhb1BtD+b5WhpT+kDsHHlesnJ61JU+nC6CY6BWea+3j42m+9z4aH3AUFiTJvEXnTXLVLXdW4XR8ZFw1bKp0W+Oj6RufqF7aujlWwCqXHtHp5tvssYckybRQ6p6YFCQ0nsfx27d6uUTBA03BdWjY+cYG0l/uHJ6FOkfCXu53PvAxFiNVcvG6ebFQTm/0UjO9V7pq4UQNEmie9I4OrdRjz/srD0KkViErhG5u1FPPjhR1mdG6skgqClwXuTs+c7aVwDLFU1BWsCCwJNB9XOqensFWEC1Sk1RZD88MVb7gLV21eCuVVWstReCvtyNNpKec0qSuLPi2L1VByaiCvV6fEXsHEXp1zpnjx3MAUaEovA/HhtJSeLIKpoM2EIQfAjrBIwYA6o/C6rLjBGMSB45y6I1rXJZmkYstDK6WY6xBmOX4Lp+KmmsHcpDIsg/qqpds3oaHw6kflXWnnLisV7hwiRyIFB6PS6K7FfHx+sn9QtyFSeCoiPASlXWquo5RuRPytJ/w1rL+GgNEZGy9GNjI+mUMWIHfZcqP44Fr/vc9NTIogfWmt91zg5RHdmm6L2qSuTMudFgGgCcNd2ZufY14mF8ND03qC6FAWZE5FHgz3qNGK9Kai2EQDJoSwQiZ3nosR2sPXoF0xOjlH7p9jVGThEhGrIRgvL7VqSlcD3o2NDvsyJC5CylD0fFkbkrjmpT/U1nRNp5GV6nQRtRZO+GwcDST/qgNxpjWsEHSh+o1+KPRc6uVrR/2EFEHs0L/xequq8owlZXT+P+pGrAqdVE++EgKHqPqsxXnSV943DBMta0kiQ6xpf+ROfMB4a3LUgTeFpVtxlr8EGLEHRbEjta7Xz1rj1zi12qZZMjPLF9N9+96zHe2kg56fiXsG9mAR90gN7p6dYMh6t8Ly/8DT6ENE1cGPZBRP5dgbIMouhlkbNTfdLTK5TXifCQsfLKyJlhDj3uYAqlJZHFiChQD6qvH+Sbxsi3ROTudidHVQ8k3bzwx/kQ1g80wKoHnL3LGCHLyhUIGw4ir8h05OytkbO0u8VBTEGMWdHtFuNRbP/LWXNN1i3OyvLyasbq+BDe1KgnqYh049jy0M+e5Zkd+0jiiFvvfITnds2y/pgjqKcxeeFx1ozFidtQlsPtRHPnzGwLY80lxtQn/GKUC4r+xBrzcDcryLJyotFILjSGA0TSGDrd/NvWGKLIXtTNi4GAFYBfAHuMEbrtgk63oJZGG5M4OlY19G1gRB7QCmBEBLf1md0AjNTTM6SKygMeK5kYubuWRhSFf21elCuGiXcImgXVYI3UfgkpT8vSn+CcuVWVZ7zXTXHk3t5sdX9a5OUrQN6zZ//cPz+/d54nn96F94HxsRr7Zha4/d7HaaQxa1ZP0mxmRLE9qZbGLxr0UVU1iux/lz4gQU/dN7OwxLgq3wNKVSX4cLwPIeVg+ZKIXEVH1yyZvirO2geTNOoWhWd+vo33SpaVG5OkWOwxi8izzsjtfWCDgrvtrscAZcMrX3zeaCNdpCQhBNIk/sn0RP2R/bNtulnxqjwvlpxoFM2TyP1hmkTbFrrF1VlRnmzkoKqCD3pBp1vcOjaSftIH3WxE3orwUTTcIGKu6GTFbfv2L/yvc5YkdngfcNawbLLBI0/spJ0VTI83WOhmJzVb2fCR70lVHiqDT+PInTBYeEMITIw17hSBnbtmqdeTNxtZGjy9A8Y4Qgw8J1UfQgCjqiaOo1tqWUxelLQ7OdaI6+bFG7RZjRE0kMTRjydGa83FFCSCO/rIZQQNy2fm2+vmFjpLVstac/+e/U0W2llkRM4y9qBo3ZIm0Q2Rs3SzwpelP0CdloQNb59b6Fz21Pbymonx+kciZ78+M9syoyPp5jSNLgpBb6yl0aZWO3t8ELN+I+bRJ54jiR1HrZ7eaAZ2lSAU3v+PKhjhdGvNyiH/npuZ7/zAWcPcQof5VveMwW6/qpLE0ddrtfhje/fN592sHDHGmEo1xHHk/Mrpsadm5lrs2dekDAFn7ZG1ND6hny96vnx/z/5oSdC5PTNNYmc3AlNhOH8qW/LqSuaoyJnXDDlNLY1v2bWvSZYVr62l0esORrS/gGJD0E90s+IvfQh/FDv742Y7+/pzu2bfsWxqxIrIu6w1DxhjPgh8R1V39zSJI9fI89K12llt19651xgzUFwUxMgNvfdn6ZJqDs6ah62VmeZCRhTb9c6YY4bnGIL+p7NmR1A9OgT9AhABHoiF7JH5hc6HQCh7O1mEjfMLnUFWkvnAjZ1OTl6Ui+C6Z3fOUkvdOXFsCUtO/sw36skd3gfyotwQgg6HYqvdyW9otroEZUO96xgqxrMiPKHKiQDGyMXAN7pZcYeIbPI+3ORDWPH8nvlzlk82rp6Zy68UYbOIXIHqkyLSLUtfzDXby43Ih9IkaszMthtDS783BL25t7tOHfyhd/S9LY4szXaGETk7jmxtqOm0a6Gd3S8I9Xr8twLnDY7hvT4Seoykn+LEyLmDz4hwrzFma7uTk+fl4o51UWSS0ocNRXspXwxB7wuqz482anSanXO8P9AxUiBydmtR+p1lGV5mjLyz1cmHcGers/Z8H8J9qroaRIKGbwryOmvNzSGEs6wx12oIO/bPti8ofbgAtAPy56AnGmPqqrrNluaz1soPs8x/oQJrYFLwI8TMqoY1FKxbYl1EY2evn+/mVS8BPb49dKQFbrTG7AJod/I3DEZOUC0nR2tfTJKI2fkOnazAGBmreilLZEqVFcDuKLKGXmPKichLVXX9cEU3hi1F4Wl1MgecVjWvpT8hyjKsBe4yRl4EjL4AI/i2V90hIh8BrgWwYpYBN4egbzEitwGrjDEfLX34SnUAkptE5MuqfH4xj4rgvSLCKSAMmTlehNNALgHi/peqihG2LJtsPNNsdWm1C0R4APjTIS+PAE4C3mJEXg5Viuv1fd9rndmeRA4xQkAxyBTIEX3+C6DwSiM8qMoDIeiFCHuhupp5By/Q8BaRH4YQaLW7bwpBjx4GToSGCK8ARodUF4B/Aj7T0/g3etfbPXmJCFsU3t3Ld582Rn4HeI+I7AaWD9ry3lOW/gxg/QuwuW2q+n2qe7NFUeXZkXr6Pky1KD4EgupXBG4e0t8E3Af8TaWnxJF9yhpzkSCbVSEsFkoAthvDJ6w1TwPPA7sE9gOrrZE4juxc5CyRszhgQYTrVDE9oBNgtwj3gGBFAtV1ScbgWW/pewuUwKMicouqPjQ0gU8Bu6nutAzVYmwGzlfVzcC3RGQL1TXMUjpU8cRNHLif2wU8QAXSl4BLRThPlVGqSd4PbLbW7Ow3lHunydyIbFK4GPRUVaaoLjknehhsL8twx6oV49c2F7rN5sLBtz+qGiLn/iGO3Wdb7WwciESkVno/2WikW8dG08L3+sdywgX/cqB11pP+ndVBJOHg65IlOr2CweA2HtI7EfgMcPqQ+uPAj6iiZzcwQxUky4DjgfdRLd4VVGll+wF7lZ0Q1FEtLiEok+N1GvWY/bNtWu0Ma031Z4oeXRuYbwSUxojmhWf1ygkWWl2aC12mJxvU05i9sy063RwjQhw54tjRameLcyy9Z6yRMjqS0gf2cP6vAKpoeiNwEfBuKqABXtZ7vf0FdJrArcDHgZ/8irHL/6dPh/aqoSeHG9i+bFZlszGyUYSTvNdjRHg1sIpq9z4lIg8DP1XVW0TkmV+1W34b5f8AcgvbC3W0lwgAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">SABA</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="61">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened3__sPxlF DefaultLayout_topESports__fDRkH"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="IMES"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIEAAAAaCAYAAACQAT/QAAATc0lEQVRoge2aeXRV1bnAf/uce+/JzTxIiEAYw0xQiQLK1Ai1IpLiBFRFi4rPh/hakVaf+qiuFoosUfAtFagitoBU8An6Hg8VRFGCaJGhYchgIJAQMg834733nO/9cfaFGLG1q2vVvrX41jrrJvucvb/529/37a04D92AXsAl/H3QAJwETv2d61yEfxAo/Tt4elrSpPvSk+ek+s1Mw3CHlSEYCpQSDBOUUigFhgGGIQAYpqAMhaEEZUBD0Cl6taDh1eeO1fx3/vUD8pQ6jyx4+iu6LXyZpNvm/IPZvAidQXVQjAfoeVuXpOseyei62KeIdmwHcBUrjgIlGAY4tmAYCgxwHHDtR0Ap15KUwkCI9xoZD2cm/caLMgduLwgWTB5Q8H0weRG+OxhAr/u6pcwzbYm2wwKiEFE4toCAoHDEcB/HNQBxwHEEEYU4IDaII4gbHFAO5pxBCY+kR3svG/C/BabXJ3gthdewUeHW75Xhi/BNMIDEeI+R4TggAo6AY4OrT1ex0uHdub8d5b4TtHEobBtsW4ECv0clLRiWPBJI83gFo62G6P59ibtu+vfK8EX4JhgASrme7YggaGXbCtvWEQFBtNIdx32P6DnnjEG5UcSRc9/0jfP2BhKUx8SuryZ++kOYKWnfI7sX4ULgARBHoTwGEgrRXl+Dxx+FkZyME2zHrq/B8JpYycmIYYChCDc1otqbMePiMGJiEHEQEWxboQwwbAEFHpQP8NgNdXi79yP2+rsBUEr5AB/QIiKOHosB2kTE7kigUsoPICKt+n8DiMZNSjqknTgi0tTpm6CIBP+SACK0RObqsWjABJpEIpvcuXXjgWYRCSmlYjvy0GndWKBdREKdxhUQo9eQDjRYnEu0kA782SLSrJTyAFGd+Bb9vqXD+hbgjayvlIrT8gt0IjFO/wY8AI6tUOEQHr+P3o88SfOxw1Rvfwd/93T6PLOI5qOHOPPKc0R1T4dgM/GjfkDsFaOp2fgywcqzeLt0xXEcDMM1KBswlGDbSgAjVN9Iyl1PYsQnoZSKvuaaa24eOHBg3Ntvv12ulHoHSJ85c+Z1ubm5dUqp/SJyQjPUIycn5zrDMJRS6gOgNDU1ddqUKVO6er1ew+fzGY7jCEBra6utlPoUOJqSkpKTk5OTduzYsUal1Fsi0vYtBtB39OjRVw8ePDheKfWpiPxZKRU9ffr0O5KTk63169eXanpOK6X6pKamXnH33Xf3eu+998qVUnmzZ88et3379kql1F4ROdNh3czZs2ePPXz4cINSalPEEJRSVnR09PUzZszotnnz5nKl1HbAGTly5K0jRoxINgyDUCjkhMNhsSzLNAyDQCAQVkrtzMjIuHzcuHGXWJZlejweBRAOh6WysrJVKbVPRPKUUgkTJkzI6du3b+yGDRvKlFK7Hnjggbtt23aUUrm4pXsTMHjOnDnjlFJq9erVvweYuueygfJxzy7y55k/FhGR+txP5KMUJYdvmSgRKJp/r+zLiJYv+kdJ1RuviIhI04HP5Oi1/SRvZIrkTx4sBZMHSNGUAfLVjf2leGp/eXd8zy3A5SduHU64oRZt+EO++OKLt0REpk2bdi/gBybU1dWdaGhoODVs2LAZQA/97diqqqpjtbW1RcB4IH7evHkPybfABx98sAbol5OTc4+IyN69ezcCg0SECz3AtYFAoFRE5LHHHnsE6AqkPvfccwtFRKqqqvJN08wBYk3TzGloaDgVCoVaJk2adJdlWTm2bYfLy8sPA1d3WDNj6dKlT4qIbN269SWgV4d3g/bs2bNBRGTPnj0bgYFAxs6dO1/7Np5aWlpqgB+++uqrv73Qe9u2wytWrHgKSAUuO3r06HsiIqNHj74D6Ltt27ZVIiLHjh37ALgcyNyxY8drIiKbNm1aAfT06FCB4ziI6XNN2bFRHgu3XHSh37JXBMdWZ9ev5czLz+DvP5iYrGvo+ex6Sub/hFDVGbyplyLioFAIojOOSEl6LqoanR0SCLe1tQXS0tIyd+3a9dTQoUOfUEpJhDbOh0fD5/OZAIcOHXp3+/btn1mW5TVN05g7d+4vs7KyxgE9AoFAuMP6nfGdiwIvvfRSdmxsbHeAefPm/WTJkiWfAn+aP3/+/1x99dVDRo8ePWP37t0/GTNmzIn9+/ffFx8fn7506dInd+zYcbBHjx7929vbG9PS0jJXrVo1RSnVCBQDvebOnfsQQEtLS1uEcaWU1bNnz2FXXXVVjojYWVlZP8rIyHirqKjo/T/84Q/7ampqGmprawNTp06d2q1bt8u2bt36YlNTU1tDQ0MLUBYfHx8NsHPnzrWHDx8+oZRSqamp8bfffvv87OzskcB/AUZki7EsywAqb7jhhjX5+fkZgwYNmvTCCy/c9Pbbb381ceLEnx4/fnzHbbfdth44AzD1k6ED5cNuKXJo5s0iIlL38U75qKslB3+cLSIiwYpyEccWEXGK/32ufJqAHMi6VAJ7PxIRkebDf5Ij49Llz1mJkj95kORPHiBFU85FgiuKb8kkXFcVUWjmvn37NomI5OTk3IO7P44tKys72NLSUiMiUlFRcQQYA4yvrKw8WlVVlQ9MAJJ/8YtfPCwi8vzzz/8K+BFwPTAlEAiU1tfXnwKunTBhwiztbRuAod8SBbIbGxtLT548mbtly5YXRURmzZr1AG40SAd+ePr06S9ERD7//PO3REQ+/PDDtZqOlMGDB8+ora0t1N4YGjhw4HQg87PPPtskIuI4TvjNN99cDvTR+Ibs2bPnDcdxnGeeeeYJTd8bQCbQDxgLTIrIBpiqcY0AhmzduvUlEZHhw4fPBH4ITAJutG07dPTo0Q/0dyPy8vK2iYiMGzfuTtx9fwBw3dmzZ/Mcxwm3tbXVl5WVfanX6A94DdfbXIcUJ+KtStf+7n8Nn+dydNZNAKrP4hfp/uBcWk6VU/ivM2n67COiM7Po89JWzOSuhKorQBnYjiIccvOXcEh1CAQXjAS+6OjoxKKios/WrVv3bGpq6pDS0tIVgNPa2hrQyZQBSGtraxhgzpw5D5SXly+tqKhYVl1d/VxsbGz3xsbGCqDd6/V2TBi/EQmUUj0WLlx4ZVxcXPeVK1e+NW3atO0ATz/99J1AT9zWd8PkyZOfbW5urrjqqqtuLi4u/uTaa6/doD0nHBcXZxqGYe3bt2+TUkq98cYbd86ePXvsqFGjbt29e/f6cDjc5vf7fYBHKWUkJiYOGDVq1E0FBQUfPvroo4cqKyuPjho16qaUlJQMja8MCFmWFQWQlZUVB5zVj62jCjt37ny6sLDwiYMHD/7s5MmTTxiG4WlsbKwHwnw9UQZwgCogkJ2d/WullGlZVsILL7ywDggA1YCtBSSuwnW7GAXiGDhh97UnMZmy9e9Q/Pi/AdB70Yt0u28uzcVnKZg7k6bcD/EPu4Lez2/ETLiEYFXFhWT/l8AwTdOMiYmJmzVr1q5PPvlkfffu3bMKCwt/7fP5osLhcBCwOzKpGYr1er2WaZq+kpKSfStXrtwIVMbHx3sBQqGQrQXRGXrNmzfvnvb29volS5YcB9qKioo+7tOnz5js7OzBGk9xXl5e+Y4dO94CWLZs2ZtaaBVAu23bREVFxX388ceH1qxZs/SKK66YumrVqqWnTp36fMKECX/0er3RupoA6P+73/0u2zRNa8mSJZuBpvXr1//RNE1r9erV2UAXXONq7kRnmVZi0LbdvTk6Ojq5X79+4y+77LIb09PTRxQVFe1euXLlTk1XZ3CARsBetGjRuMjg/Pnz7zVNMxW3inDcSGArHNtBGV5XIz4LEPeQADCjY7BSfZz5/WoKf34vAL0Xv0jPRx4hWF1N4UN3ENj9Pv6hl9Pn5a14L+2JHehckfxFEMdxxOPxWEBo/Pjxr+fm5r6RkZHxg7S0tOEtLS3nLN3v93sAXn/99VXJyckPJicnz0tKSnqwd+/eTy9evPhTIGDoww/TNE0gVSl1rX6ylVJ9Zs2aldmlS5dB27ZtWw/UAGWLFi3aCLBixYoZnI8G9aFQKAxgWZaJawRNnDcs6datW+J99923p7W1tcbr9cZOmTLlOf1ORfZnoHdOTs5PKysrj65du7YYODl//vz9ra2t1VOmTLkLd/sJ8k2DDYpbWZixsbFRADNmzPhlQkLCzYFAoLS9vT0wceLE/1y7du0RXM++EAx59NFHx950000P5ubmbly2bNl/pKamDikoKPilxhtvgNsAUqaPYGWVi7mygnBbiHBTE9g2wcoK8PjwdU3n7KZ1fPXYgwB0veN+8cQnEQ6HKfr5XTR+tB0rYzAxl48l3BxA53YYXi9mXEKEKE9MTEwMQFRUlMn57SDZ7/fH4Xr82TFjxqzdv3//FoC4uLhLcPsKyrIsD0CvXr26AO1aiVW4XnMaCEaMYOzYsTPr6upeCwQCvw8EAusbGhpenz59+qTFixffCzBnzpyduMlc2dq1a0/U1NQUZGZm3nDnnXdeo/GFExMT4wCSkpL8uHW/47LkVZZlJaWlpaUADWvWrHlxx44dr+Xl5VVcf/31KQDR0dFRgGfLli05Pp8vfsOGDW/iemwNUPP++++/aVlWwrZt224BegPemJiYWAC9pUUiieH3+6MARo4c2TUQCDTfc889T/t8vpiSkpJNzz777ATTNCcBHi1DPB6PAfjuv//+8UuWLFnW0tJSPWbMmPULFiz48sCBA+/27dt3TF5e3q+B3h5ttHjjE2g5UcKXP76RYFUFVvd0gtVVHLjlRsL19XhT0hBl4kvrScXmjQQrziDt7Ur54/D4Leymek7+6mfEZI6gvegIRsIlOG1u3ydYV0fbV8eJGpgJ0Jifn/9VcnLyofLy8lat9JqioqK9dXV11UAtUAqYV1555eqDBw96tSACQKikpCRQXl5+qKCgoFwrvhrdNAHaAE9paWlrWVnZl5Zlxfp8Pr8OpbbjOMFhw4alKKWM995775WampqIZ4eAyuXLl7/y0EMP3T1+/Phe69atiwcCBQUFpUOHDj104sSJBm10AE5dXV2ouLh4T35+/mmgbt68eTtxw2tJfX199/Ly8kNHjhw5BVjp6endSkpK9j788MO5uEfszUDx/fffv3PUqFFj09LS0nAT5IaCgoL8mJiYpLq6uhDnI0NrYWFhWWZm5qGSkpJGoHTz5s2ycOHCJxcsWPBATk7OxOXLlx8rLS0NFBYWHvP7/XFnzpxpAy6ZNm3a8JqamsLHH398hZZh84gRI14sLCyM69q1a18gQQFTd/Uf+I4yDJRjE6qrwYz240lIACdEqL4Oj9/CGx+PwnZPF8XGbqzF8HnxJiShcDBMA6e9GWltwpuYiOHzcayx9Z3pX5Q8tX+AdSDphlvp/exaDI83FjcjTtCeexzojpuphoGj2hDigb64+2VQf1cFDMK9+1AFHJVOjSCllIlbf/fq4ElOh98qIFnjyteeKUAiMBSI7UCXDxiCe8fiDHBc3E6hAjI0jhrcJkyky1gH9MDdUqqBcqCPVnKFXqNddyUHa/4CwDFN03BNQ4n+VnTXtCMdXwEpuFWFH3ffL9JOMFzjKsGNcoOAS7XhFeAafF893wGKdccQFILCwJt0iZsY2mFQCk9iMkqBODaCwu0BKjyJKShTIY6jE38bw+cHKwoxFGI77hEk4L20F/W7ttN6PA/NaKkWUMSLa4ETmqhmEbF13X1CCyiMu0c7WqitmqkLJX2iv1Gcb41GoFmvF/H+Rjnftm7RyowB6vV8Wwu9QY91xFep6WoFWvTakTlncQ03Mn4a16Cq9ThaYSc1LW16HcGNFBausUagMx1BvVakjR3ANQT0fF+H+VX6+4CeG8aVa5Net8LdDhy3KaM8goNbznkckEiXWum8QbnHxwYG4raD3LMC5R4gOQKGuAm8GIqmoASAsO2YhJraKH99NZqgKlyvCYqIo5Rq1YKTiJC0ITRoAYEbiiPZbotm4Gt9eT3PUUo1aWF4+HrZZHO+lLI5H9470hURlKOfWo3zXHjW3tnM+WQuJB3ODzT+do3D6YCzPZIsajobO/AV1PxXaeUGOySW4U502Jw3troIDXp+ZWS+Hq/T84KaTlFK1Xfgvc2DbhgqMJwwGB5AucfCyhAwBSW6b2DIufMB0JdJcBDDxW44ClFuf0Eh7Gtq+hKojou3cawUwp9uoPVPu5yorB98LYSLe2jUQif4lvEg573pgqAz6m8YyF+ZI1ow7Z1eXWgMEQnjKue74L8gLd9C5zcuXGgD+660dZ5/ofVsbaiAazEVJbRvE8E9Cg4Djj5SdhTKVrrL5r6PHDk7jrgXSWxtIMK5Y+RwGM6GQrmrimsPAA0ej+CLj4bGBlqP7L+QPC7C9wgGcPbekpMvVdqhvSg3friBzY1E7kUS94TznKHoIBW5ZSQO4Ch3hiHUBsNH/uVQ6XLcRCjU3q5ob3EIYUJU/D+ax4vwV8CDu2dU315a/NvfdO923SDTnx2nzJ44YigTlDIwHEGZIMpBGe5lU0QwlHt/QOnw3xSyTxe0tX26oODMu0FHanBLuHDkTqPqfAPgIvxTgMJN0JJwu0eX4hpG5NTub4HIHBs3ApzGLZ8uuG9ehH8e8OAqrV7/NuPWy1H8jc1/3J2kXa9VjZuRXjSA/wfQ+bTN0k/n0uq7gOAqPZKxXqiGvwj/hPB/7pULV1AwWp0AAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">IMES</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="104">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened3__sPxlF DefaultLayout_topESports__fDRkH"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="CMD"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAE4AAAAjCAYAAAA6wDyZAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFEmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDIgNzkuMTYwOTI0LCAyMDE3LzA3LzEzLTAxOjA2OjM5ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMS0wMS0yOFQxMTozODoxOCswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjEtMDEtMjhUMTE6NDE6MzErMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjEtMDEtMjhUMTE6NDE6MzErMDg6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ZTEyZDJmMDUtNmU2NC0wZjQ4LThlY2UtNmEzZWJkOGQ2NjhjIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOmUxMmQyZjA1LTZlNjQtMGY0OC04ZWNlLTZhM2ViZDhkNjY4YyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOmUxMmQyZjA1LTZlNjQtMGY0OC04ZWNlLTZhM2ViZDhkNjY4YyI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6ZTEyZDJmMDUtNmU2NC0wZjQ4LThlY2UtNmEzZWJkOGQ2NjhjIiBzdEV2dDp3aGVuPSIyMDIxLTAxLTI4VDExOjM4OjE4KzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pvzk4IgAAAtlSURBVGiB7Vp9cFTVFf/d9/bte/vFhiQllZpKEtBSiYhEzAwV+UgnUAWd1pEBTPGjmZqOivGjTpNOW+qgtqIdRkctU1GHyhQ/sEoTCQUExErFQCEzBAJmwAqEzyWbzW7evo/bP967u3ff7stumM50OsOZefM2755zzzm/e+7HOTeEUorLNHIS/tcG/L/SZeAukS4Dd4l0GbhLpMvAXSJ5nB8IIfyfowGEAXgB8NsvY6IAhgBcBDDI8fC8YQBFAPrtBwC+YX8zHX1Sm+e8S18AINuy4RzyOoAop1fMIc8TBWAASACI2W83vRmUBRxHY/bs2bO0urq6UZblKkqpxjojhEgAREqpGovF9rS1tb20aNGiNgAarCg27d/+jo6OO2fMmPH47t27V82aNet9AKqw5E8NxeMm/Q7UjKfdJhIo1YYOtC2N/W3FFlgDYto6aWnrbgoA51bUFhU/8tGLQmD0naBmjJOXYeinzr9QP5d4/aT4oQ+2QBBGg1I9h29skCg19JN0KLpX+/f+Dwc2tO6CBXyctbsB6AZceOfOnQtramp+n7aLyDxDNBr9ZM2aNc80Nzd3A1ABlC5btuzKSZMmlUQikcTq1atPHD169Ex9ff0H3d3dlTNnznzlz2+tu3D3ksXbqE4UACKIEMp0hyjeytr5AD6HFQkGrCgCAHpuRa0oXXXDFUKgaD4AkiUviMUwNEoT/RSEFAHEh8wZlI2gxzuKBEu/I0+cs9j76I3tsfZnfq0e+vg4rMg33AB0BW7q1Kn3uSnr7Oz8RU1NzTsAjOXLl1c1NDQsKCsrm+Xz+cYTQnyUUmPZsmWnTpw4saGysvJ5URS9AHDLjJu/D+BTqiY1t76FYMl8sXTcC8a5Y0OwBgQA9HMragkAxVe7ZDJAlJzClCYAgBqaAUrjIPC76clFxDfqB8E7fnsNPly+SD245RiAAVgDx5aEFHi5gCPck0WbN2/+SX19/T8AeI4cOdJUVVX1sD110x0QInq93isrKioejkQik0Kh0PUAoGlaEoBn2CggQmlw3pM3969takd6pNmUDXjKrp6ZF4FctpvGGWpoZ0AECYAJQhQiShVZgqJUFbyt9SX14JZF4AaOswGAe8RRSmnS+bGzs7Olvr5+DwCxt7f3wYqKip/l86CoqGg296cBQHLjZSSOvvJGAFthrZNsylIhWFoiBIrn5pNHDuCM88dejqxe8g6ngyhTf1QuT5xzpzBqzP0ZwpJvWrjhlXn9a5s+RHpD05BeG3MeR3JGWyQS6aipqWkHIG/cuPGGQkBzobzACf6iObYNss0vAvAH5z4xFYL4zQJ05AhpIgIIAigDUGJEvi4a3LLqwoUXF6zSTx583MntGXttEwDFfpgNKWwKOsdRShMNDQ2tAIKyLEfr6up+WYicC+WIcqqCX3xF6dujFj5fC+sYxIz2iWOqpjgEWTQ6KRs4wVpnOTkWzfLF1+/bRBPRTRkdeLzXhhb8ahIAv22DBxxeBQHX19f317a2NhOA2dHRMVtRlAmFyLlQFnBmvL/D7O97JYPpiolzbfuY0X4hWFqXFjJOGxdPvgpQE4URWy81WEedQVhntxgAaF/te8spIJaMq4Q1eDLSwLlGXMZoUUqN9evXr4UVsoMTJ06cnUNmJJSlkxAi6H2HP8v4poRuhOWoBEAJ3toymUjKdSm71MFO7dgXfwdI3qnPuoS1wKuwDroMuCiAWGzzH/aCmhccNpTBAowNHpuu+SMukUh0Nzc3H7OV6oqilBVo6HAOZJJH/layZ+dRmMaZFJMoVYV+uGKybbAsjaup40WMiyd2CP7RIWdXeYgdzFVYUReHBeCgGe1LUj15PMNQSSmz7eWnKgFA8gIXi8UO28waAEoIGS7bKISygSOCb+hAW8xM9G/jP0vlk2+3+T2CL3wd3xbb9FwHBLHQaGPEUiwdQBIWgCwCDZjGYKZdqeBioA07VTNI07SYrVBH+kz13yYCAMkju/7CfxR84e8BgGfsd/1E9tey79TQjuonD2pECQVHoIM/E7KHbRIacvmVLo+L9lM4cNTK9Rhwpmmarqf+fGQYRq4dMKUq1vZ0D0zjdOqLKJV7K2v9gVlNN/FrmTlw9iMAMhGlwAjUOyOdT+ZNAAJEKWMZourg13AcQ1DoVBVFUUI6xKmqqudHYCwAIB6P7zMM47yiKEG4RCwRJR2AbA4NZGwSgXk/v9dTdvV8zh1D3b9xA/JXPkZCHv+MxkriycwkqBq7gEzAU7/zAidJUhhciHd1dW0eiUXxeHx/IBC4R9O0c7Isj0bucxcgSgSAoh3vzJiuYtHYB4kvfFvKGV07FN/1+hmMHLTh+MPK5FvvAjLXb/1s75ewBiirj7zAjRo16npOyKyrq9s2MDDwz0IsjUajnwQCgXumTZtGFEW5RlXVi3DJgW0SBza0HqB68rAbgxk7tx3WuWpkwFHTbZko8d/y02ohNObuDHY9eTDW9vRRWBjx1REKgOYFzuv1XrV169bZSDtsNjY2PjQ0NNTjJmOa5uChQ4eeDofDj8iynNixY8fbAKCqKtto3MgAINL4xV0u7VQ90PYerDPliICjmjqIdLagACgmvnBl+MevLvRPX/oeiJBRSdH7Dv+R08MylFSiP9zRItU2ffr0RwF8DCts9fXr1184ffr0wjVr1txfXl5+lyiKJaZpDqqq+mVvb+8Hixcv3tDV1SW1t7dfP2fOnN94vd5yAPB4PGy9dCMTAPRT3du9jsTbcj7xr/gnr51FdvU4L3nGVDWVPLFtAYgg2yZQCJ4QEaWsLIjqye7+Nxu32noSSFdHUsC5RRzhS+iyLE+IRqNvNDc3XwELUHP79u0DlZWVL0uSdEtLS0udx+O5KRAI3FtdXf3+0qVLx0YikefmzZv3GgMNAERRVACYoK7T1QSA6LtPfk4NrTfLoXj/ZwB8nBOFkyiVE6+/lkjKFCL5phDJd0Mu0GAapwe3vtho6+GPK3xpKedUpQBiPT097/IfQ6FQ7cqVK9t7e3sffuqpp6qqq6v948ePFwCYzz777Kl169Zdd/z48QcSicS6xx57bJOjnAQA6Ny7bzsAkchSpl5CvPbmkBpVc+Bsu1Ne7dnZBmv6WFNHEMSsfgAQUaJwVKwLIZqM745/+saSoS/eGYK1jrJDshM416kamzJlytru7u7AhAkTHhBFsRgABEEIVlRUPNTa2trY0tKSpNYBkRBCiCAIzvSHgh1sk8mv9u7du+qO2xfsAyASiTijxSCiBGqndQB0/UTXTrFobBPsXY0m458Nbn7ha1iXMEnk2p0pVamhESFYSrj2YZYGaoLSONWG9utnvny7/83GjwEEYEWbyj1J2y5WSgdx/u8IIYRVJBRYc3y4kWPCwxf2Lee9sKc5rDzRcLSztjisEWb8jLy2QwRWch5HOh1iJCB9I5dEYRsIy0V9sHw1bVk+l43b39iFFc0VcezMZthCgAUiq2fx856NAMvjWE7HpyjsbXIyLOL4igMzWLPfSQ4sv81rcE6xqBNs+3w2D6vSsmksIZ2kM39Ta5XDbxVWZLH8NWHr4n0ddqqyKcNqVwwwdqZhzhvc3wL3doJGOH6WZDPnGHAsSviR5S9JWKbAbEra7alSj6MvFtEa0sVQNrBZ5zLOPmYDuyxiA5T3zoF1xDphQPIVUB4456Uwiz6R+836dQLOVxx4nYaDX+P6YQOqc32wweD7YnaJjidXzsoDpzme1J0HL+R6WYN01DEHGBBOZfzosWRYcLyBzKoEk+HbGQ9/HceMZsDxDrJ+2Eagc/p5m/jBcepz+sv6ZhvBiO9VnaCYnGInH/8mLu9cfbJ2Nx5GDEySh2e4yovzyjN1W+Wi2znA2R3m2FWdCnO9L5UK2eVy8biVhNza88kPp9sZDDnpP0I1sNUZpNQKAAAAAElFTkSuQmCC" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">CMD</span>
                        </div>
                        <div class="DefaultLayout_icon_new__k+IaO"></div>
                      </div>
                    </div>
                  </div>
                </li>
                <li><span>|</span></li>
                <li>
                  <a class="DefaultLayout_menuA__Eilgx">BẮN CÁ</a>
                  <div
                    class="DefaultLayout_menuSubList__mx2Ni"
                    style="">
                    <div class="DefaultLayout_bg_menuShadow__Rjze1"></div>
                    <div
                      class="DefaultLayout_subList__-8hVJ DefaultLayout_subListTwo__P6WWb">
                      <div class="DefaultLayout_subListDiv__5oE8l" id="0">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topFish__sallV"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="JILI"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,UklGRioeAABXRUJQVlA4TB4eAAAvK8EkEP8nO7Zt1YrW2tfvxZ0ASIE/YiQ9UtD2vrI1DViy7aaRriwFhuGX1jGrm+0yU2KQBEu23bbNBUWCpGQ7PfnLWrLlbKn33tQIwA0DAEET3N3d4RtGruAJXrL2ik5MdZ/cJwuANcr/P0ZrYhNsgVVQm/irsBA6RN+CbhJjTca9iNcROEM5APb9iEhLU1VYNcGoeuA5iuEyZjRDa2gGZmiG1lAN1FANzcBWNEMz0IaKylU1kbtI/+PuzNF2zGASzIG6FGu4ZsEfAYaQRaC4xCUYOSIlEEmyBRGralFTVDMJmQy9yBZEc1k7TVHNApkNQ9Gz6E21qFVFg3gWDUMGrpF4RldwFTEqnXh1mCe+OZ/fybqaB8bDjpz+mwt0LpYiai2WEuRcTBKNJC2qR4DBzipz4KPwsbDWuDfhC++B7mBsWFsFX6IXnJ90s+rnJPPRLYGebd1nZzpTrRQ9BhRAAQUGoAcUSEAEEqAU11OADCigQAYKUHlcIKd+El3JEZFDmmdMGqe3EfVUA52Gytna4t+6jVK+6R5A/x3bilRaF19xKfbZz2KqJuiqapJt0eqV41/Y9uWvNv835JdwddrgHZkcboMeoS5CkTDfnfXehTrUkcm1B70IWMAcEbDAMfgv2LfCXSYXu7N0xz5gAXMUvEeQzSAZyXcmAGUKRwL3FDIiHFfykPBYyR7wPCh9FsoINs+3LOaJyTx5czBOHo65f7xIq/5q8bSTEuEHkChIEhKAVEGG0AGEI3j5e3G+e39IXu7Mxbp4O7pBw+s9M+MgaNs2bvmz3vZTiIgJkEeSQAvt+BdP2LYtU6NtW7s7WobGl4w6Gd3CTdzdilAUcLtEsBKC3T6/hxHaHYjb7d7u7t49yz1vb87jOM+q87ouluUe3fe+R/RfoiTZcds03pPgM8CjeEEpf4BvbdvXp9m2jSk43WUuronwUb+GqLteriwkIX9L8OusYPmncrobVawnxSrImbq7YFXgst9x/P6xDl6y7xH9dyjbStxceJGYLmCWJvYPfP//56attm1HcUHC3jx6L+4dvwwx5Oi997LV/sN+HBBD1lIkFIqkxDQTxz123A4DaUeHvNbMb0aj4Wh7x+8X0X9YkK22rQ4QE/sVQMVOGfn/ov+q2v/99x+kTJGTmC6JAVOMSrfU2ebNt3QJFzRg5ar8iYmmOTOLeyWxWXB60qqWkyXLdhbktIxRnnxLWWYBA1aOCnTlT4Qmp2fv3X+EByUx4L4ZNlUsp2d0tg+LNvLR/Xuzatfmy7dUCc8U6OWq/EnQzOyj2/sPHOS+Ym3vPnYd5P7b94zrAbq9/2AX95XAug4euNVthqgCiM63RAmbMgv1MlX+BDA9e6Ov85kFbNmaz7ZHWAsQI5kAWF3Z+831GcPkzPVveiurE1FWU4TFqu7035iV0yAi33h0XolIa4m26qo3+m52zxRGROWFJLw9wiLGcMv816rysjPZfaT/8dZt80uAv2KJsmUkV4itIleTa4EYGXcRRwKo6hs+Nmk4NsyqBOKAi5q4toJwUy7F5gaOzBisfFUqHpKKuGUxsbW2tYXrTLkteO7Q0JXJgoioXI+IyngNsJpcRXLlCmD5MlIG88+LPuQH81u+NJWXn+kjQ3u3LPmQXPSnRR+ILQaWkly2HFixElAda6TDMQ4k5gZHr1TgyijnJFK7ztBmWytBaKsh6QTKqw+NHBVo8n1dEkn6Kp9WqGTXWbaeXKNt7bqwbS2AlrnBkX8WhFW5OnicGPP0ACuWA8uWkouBD/gn44/nF0zl5efY6MAXW0U/XkSSkcFyAMppHGtjcc9tNXw2MHq2Yurs6EClodX1dLSuLdoiAzdAkk68b3jsknD2+EBlknS8IGmiaK1XtibC20PJJ1E5cPxCQWMbVbkTxo1UpHuA5QCWKn1AmhGtfAxskcrLzhnhxwA03/vwhx/8CHk8Atdz4SXnBkYnTpyeGB14PSl5qDbftogXJEm6qcAPWH1oeOyCQfJ9xU35BJPKlaKdq9evtsiEgBwSEwVgVfBGTTYE3RiN1kf0ApH6kKz88fN8cdGCVF5uruXGhrq2zFfSdn73A1K7SKFXWz0fbjLWMzSWuwyODfXEalyTihPtrdZWO6LjpxF4zvOHj4+fNVzOjQ51tTl+Ki2HOanDSNYYtEzEdS3YNzSau1wQVuVhlmi1FoXEmufxYuXCd6TycnMpNzbS/8WWhacqnycgkD9UG/VrFKp1sh6cRGzu8Mh47spVjo8cvlOdcHwvcBM1jLdG7RoQtM0NUvCd5HN9Q6MT3xqumjIPz1Un3XQAL0ky3+b1tLdn2olkC2Jz/SNjuasFYVde44XZ9pgFafmyKD0P07vlaVV52Tk5MTrcv/fphS2Yf2w2Kbfh8hWw2rYQjrnpqOzqHx6bOHnZpGsGu+fNqpi55IHq54FM5jcv7blO9XOdfYPHx3PnKgAr3zeqzAXWl079kXEAhrUAJDK969bKZ32my7xS0IBFVZ5oDbFurd29AiKLD+VF81sWnrYqLzenT+bGR0cG+ro6P1/AY1QqVx+wBAoIRu3xRNWdfX0DI2MTuZOnwZwZosG+fXeqEjWu+o3NI8csiYBwWj/r7OkfHh3Pnbxg+GdUvmbnqs6Ib4iRKgDbiTUtVV/u7Tk0qMq8VtCARVbeEmsLKR71hUsAJfNpH275PKrycts7Mtfnn3rcTPbzG0xUWB2F2t477rr91+O88OeHn3peanbOSnd0+FDXnVhCPsaJlKPfh7T5HD7X2Wv2qxmgU5cqEJ1vq/ze+K52Jqw7O7mly6i88HfTe0Gm+VZZBSsxc8qxokf5ifEjm/qHPr/RNfPQvf/G66/qyf558aVnIGGDtqfnzjv278P4L/7076deMCXjG1crcPUUZYyG+/aaho5vjlzKjrEN8Gs9yeSLnoHj4zmePCUnXp589WXUc6zA6mxrD432jH/y54efeuElNc33Sys9g3FzYL3jzp69JnTSJL6n8szF51wzD7+9/Yaa7AtP/OvcxWdU4HsAfg7gl9J6eu/E/n3GzX9//IWXX+cbeFfSPX8K4MToQNdziRrS9VP0xEiqBJhK03VIdvYNj5nxAa5UIF++jvK077mWOWwnQyWOX/jXky++qgZczlmz5AxuHt8L7L8TvT38pW5StO+NqMTFJWYe+pdNAK+/9PTDf1AkdmJkdIyFPHMD/ejr5V4I+QffsBK4cAqQ+4VnBcf10ymkUSuWVhZ4ota9/ccnTgFnzADly/ffkEnXC9IpEgDpewgBtK9bs8f4w8NPvySFxbtlXOWXnoGxhzCvpb5+AAM55sdGOWKSJnFxqZmH/8W33gBefv7RP118Vj2xwmQRhYncAJUe7V9PGe84LhyunDUM92pksGvr2SBGmk3mEqjYd9hw5uLpCuTN18JPwd6zqSDLsN1CV1amWU4rPfPxPUofgAceIgdyhbHREXPl+4nimHlU2od8RzNx+lSXMSTwENkP9PbQ9v6HJS6gLwo1CaqxTosaAQkMgefayLU8X74WLrxAVE9rv2bDjOaIeO+jr/wv4d+39SgPQGLCcnLa2TOX6JlHqr328vOP/dlAnciICYWGif38rSj56rqqSOqxrq03URPQCOWBugAK3xbyeyC4ADxf8iWtkyAQNogfkcoGUq+Plb0w2Q+TEhMoFJVTdWeBS9TMI9ZsqdOsqcqknSS4/3YPST3WaaMmoJmAcWl8DygOD0b6NIB1Egjc0EMGrcek7UFlaKSiquvU6VSEXfIpmUzFjLah4uCURuUOepAYvjksG2Eiaq+Xyx7J4ghI6dNXDBWmgjDTgQ0kg9ZLSTygcFKkK6pqTqeSn6YiLZGMVXdaJh8U6ofv9OLBp3l1g9Lf2Eyh1jiAovBSANJQ0i6rZeEm0e82ZWSra2LJT6Ms8WmCjCsHpnFSRb+JOwEfPtUp3NAkES23vrQ4VGJRV9cI0NuHoPVB/tWHVE8MKrF4gowyiloniQFxl5+Ast5kZLkMOAAUSa0IDRABqkkp+oKn0jaJKSPTWR1LzAwdbbun0YDFhL8GxVuAeFOJAFQrP0TiGqX+oEkafJCWA22Zztr4zFDd0b57WD60sN+f2tJMESA0lgrYMAKlwEkvZ1jJwaG2jmmJGfIAi3QnBgR8JC1Uq1xoKCnNEewwqBM5aKbHfE6ZVM/D08xXIi4JI2Y+oKGfJoAcB/r9ZH3mhbKh1FCzM2M0QB4KWi5P5iYmAUnR3lGtPkimLo0wGNVGuxU08pTu+E2e6oW3So/ZtdGLtEKOzoAdMVkAJuDI3e2dSjLiELeZT6koIJ/zU5M1nsq7aCoZakW3mo6NRnkGLc8xCkxRUp6VJFAXbag12rFbPZlOATp8hFkKjRGgdKT1AvaWuh2Z3ZtEhaAVxjg6VixMqZRnLTkT6AcVHGQRY5TwFWhKvaJugQUA9pbdm000xqCZJIsYlHbApBabCWLWA+SLLAIYNeEjERoP0nIPXGrSishb4Lp/s/udXxkFz/RGOCRxwKR5dkhFWApCP+jAEDBKjuVzPjIh8tJsKMGzlasSq1erjVCt8GsTjTJYNxojwBBwQKdLKtqAZKymKptpb1OhjGB0jPkjZXsmkTHu6zfSvgcuGSn9HApY7a7dm3/zFzk6Dwbr8AiwE+khDEN6mtyypyIPNZoOkOkRFR5aOoxn1QuVUz8vKFJFkoI9FdSgZHjnXTVHH7ydqNiZNqUyPafUTEGtHUCGO034ATLZIPKhvZlosIgXRQqBNcWopNp3fyPRTgTNJLLMtMN6XbVnxGlRH1mXKqe6NIoOZjqyFRI+NqIDYTat79DsuaB6NW0WFEdA0vonhUrY9fa7MusMVAStAlWkHN1hy1ZFXx0tFGS7wU5USRy+sXybsNE0KdWQJKHWA5J+UTiBmnATV6LoN7/904+fB6oC9nkVq8lOO9pc6hhpJLW0JllNE/CwXc1/hDvSeaYq0oEvFrModF4kSwbqz0wtaf/wYzk2q4NWzZpamBBtJDPMqlX+uhmForoWJryoR69MdkfEPZo1tUrSK4pkliHIHawzkdZ7v/vDT+VIRO3FwfqspjZGolq0OdXNDJUG7YdaxCTK9/R2eZzY1LFzR51132EpFGsphpoQGUBcIiUzP//LF182hTJoMcYTcZe0U8NMsCutImM+ro3FiZqqz8u3Te76Nu/OaAcAUv1rBiDcXgyJDDqQwU4xS79TU86vkYlLgnVDPEEtY8na6iOsngoqdwiSWoImPvPwJ3meeGf3TuOsJ2niHUYdANqLQ83od2SsSBQxNRiwxTckHChpkWTDZRFGRG9RaUDLaozHfKj/oVJQwd+pdi+h1qDRq3i9k4EHgPtVT3J3h6zOh+V9jJ8xfkrEXdlKiPqZhlU1MVW1G8r3uZydR4sTD94P6ZAkIGs6JHHIywBzpL04b68Mhg9Ua9cOUc8ZoXuaCZeksrhsn9VUmc5QcWJSdfSuLOsU0rwcyRf0yuDUZInVrgQ/iKidDyK+7z3vfpfALqfGiPsNaaYDZKsEHMqrUKy2pjqbHipOmdDtAU4UxlRTPFYlSBYBtdjlXpUYAh+MQEOEfZTLb37JLRocAPhIUNa70/K27yT0njxRxIhqB4XPnXZZqxLh+d17+PXoT5jHzOg+2VDfwOijaVt3bFd2ZCu7ak6n/JHxWsf7c+SgvDe/s0Kal88rqkiWuNN2rEqgfj6EAN61IN0GI21EBrbTmmwXTqcAP0n7SkEvd5NAm7oRBLouFh5X+XDcEUGu8vWddig+hAx2LpSxZaYhaY43FsALAOvOxlq2ItWVMxm7RPhdjZVxR6TutOmdQ0KY37drKpui62OIKIfq2Mw6ekqpI7pLu30eJZP+Yo6r/LTrKn8ofJgk/JC4FVojog5/zcDWbQoq0S1IegFwWp39rBWkjOM8mlICOGumVVNnTT3Jj+gGhAr5IUlohLg84r6+zmULuk+eqvdVR+ojekbd6af18c56p8ubY7zc5b4aGxK//Hdl8zRy+zYoVFXzRH1Et28yrOMdoHke3co4a4bjI0QEhiFytom1J5TmAOhZeQKxR0p8nMHN23Rzur5817vvyAD9uiy9alX+tnWdCcxBWR/dVIuCeub8elTCFqzTmgIRceEJeoHi2hbdnpyPIyIEbqpqPhqoK2Sd/bBD78PqjtmP3rbdxnay1JkAR4YHLNdmiCbAEl5PXDED+RIV3FFkkwJg3ckT2qJyLTJI69XkrrXrjtmnsmq8pffYEIDM5VBpClmPea/AihkWgRUq+Poh3Z4Sm3QD1tEqmw81LKtCutauK1Afi8qsbOi+C9nsMksJ6e9l8CU6cuuToyOIo7SeE9YPEfkEl1+9xXqntQFogjq6ug4Yrlo32Ty2rXO8m1yVRUCE9YmQKFoGm2hpJrVw8tVdJzs5SsnEGlEiOTlCOefy1YtnPcgoBNesx0bLeqGq5gdQ7C1b1p4X1HjXG82qAdSneTjBKyIkbs3AIZS8uG+tj2ysyQRH1u37F0whn+QCIY2NANYch5qsD8de4K718VIVCmC8epZreFwb5Siv80MEl/AJ4+MA/M4P1DIP5Q/WuIVJWl6jVVGIlic3rNIFOxiObsCaAFynR7um5GjVaGb78RovAdTs3vUbTvH+Fe9XkUbGeos98xD+DtJliRnz5LKCTMsXz7shrF6/wU0Nx8dsacbqDVCA1cZsf9epgWnu8XrpPr+o2OujI+PZ0sPX3TA+8evwkTGLDA1Pb2NyZRUxXNed6sWzJmcKP4n4hS9OwwbV7KoBwHV+ZLSrAXuwAJep0cy5wuI1Xtck4RgvAlS2F15xY2JlNTm6VX3wrBc2i8DW5h7D1nt2z3MSkytKLI1m3QcvBJDD0tX2c+t1cwAsU6NdpaxaDXLZHGkOZY93th6vK32dB6Xc6AoiTiRKwXYYEWefwJ8flLZGk2pgfNKubjdCsMvmrPZ1t/qZO20FV9mNtMz1hmXWeDdAjde1bdXobnvOepxD60V/p6c248pnn8Copcf2QVZWV+SyPJ51gzpnWtY17WoHYq60pUtcSC5ZOleaQxDj3WBt27keeq+DcmF8iaZoObXheI3TkBk3ZKZejTXLj6s9IxBK6eVHl1bUZJniScevsfzHRBzlJrl02VzVAsCVJFcRJFcsscwLBFesFCyxbRV5GhSz41NLND2V2rC9xlO1sxoiIoTjSB2C7cDtjC/L2iVEFsftaoAlCUtWqLCKBn/zpAlXM+ap9oXFf7xq09LM0kv3QdXeiC8T0VKccxx2dgqdcUPUfeA7G3EIKcgSyyPwGTOSLkaqmlGKvVA1D1fbWm2tXNKizbf5jde9aYl55eu9rpXy45siVSnTiChnteusFobzetUen5E1iigwhumxXMmXousmnSUuV3uYT3JeC77TSlL1SLRgvrQA6PE62NuWlOhe+E6nvwkEcBRydkLGl74C5/fVq5aH6axescamZR7i1LRU+grQfn21zBPfWIir/vPvp17yQAvJMvmPd2WrtW3nla/37EHF2ogrIpvfielX9cnJugIIwTFjdGpJkGkoxGUTaQZliOORZCu5RGq98BuqGU/7gith5QJbUONd0mJt29mBAt17QTE3tqnIDBAAgeldnchDc1gXr0QQUWKbgiyO5eHuWRLHI5a0LmmFell+w3L+4adf+sgDS2gpLfDxEiBsu12xksYtIIuhSMbhlwTRJ6ew7IAnKPFnEJknoW9VApQw92muiNyQFgRYn6+1ojAPQhV8xrxGZIqR6L72irn+LZFkCLMkzlmiARARh0GbMT4DejARcQ+FYzzleMrx+HXdYBZWiCtC5oFliHCQ5+vBqLGAiKDWwEFEodYLiBKixwuaNhyVrYgZxiIinLMEkdrsMGhU7cmUpP/O4CIKxzixjhvUOXMiULhhhug2UQYnrEq9HQGcR2EQCG2LC0AiAjQ0XjkhL6OrTnYAqpRGnAvDWOTCQCmzRKy6iEPBd5LxTYkiIvCQY/LyN2ql/ABWjYhklgZkiFXFa7TPI4AMFEutFZTCf1pOyBtZbj5ufgoxHQWmn5YbLQ6J/WbgdmKbUr1FJNsW/QYgjYgSnUduwGdq8ODaPTUyRHwjcYWQEYlIRGO8cqR2UbYSRpoZKE04PBhwcSmKaLcI+/o5aNXK+TEw3hXESNmVepMAGULB5WWGBhlssZ/cf5syBEA4ZYiQDH3xigKR2cv7dmeQYdvbRGpI9PPA+7TEKD0EjvkacRtxMNzDbSLP11ltopvrZ4hI2BAossTMlF2tt48igRzhGYCkaItXJjJ6/L39KycbM28DA7EqsSCf4YnLYnpIPOFtkO1L96QR/p4xseX6jVa74RezMhBFE4iB52cKeLasXy6IBQZ1F8iXOPriRZQjeC9eXdk3osHCQGQZABQkjZx8STd7fKFGO27ekgHEjCULLl+Bk+pVoWrEq4ZIggcrw087tdbuefibM7WKtQ6ZXwgVqIM7RX+n29MaLyKiQK/7DHzo/IaVjRkymyMBSQYwHAwRqIhC5npfMLQbbDNIcz6FRIIX71hgKVk6CkqFpCmMRiToQUPJdj/8I8ILv3gnZcJSk1wkofT/aJUDfmcPjfESESKjVGvC7zFcv5lPDEw4rsRGhUgygJZGMXCEEye4fhcy1+qc7LZAj70FFZHbROemUPS4te5V7RvwnEI9TsaIg+1J6IepL6/dwk1fjFVRjcQdpwy+gBAhXkVlBI3nL//6l7tv5jtxIyPziIgA9SMxAzAfpClUELabsQ4z16nnu+xwqTBhpPkWCfE2GYkbssA+vLhk3cKQ2W2Zh0Rmf8sNGu3d07C7rrz6093CTcoQCnc7VIQc+p079vVf+RcQIsSrFDGgfnH1ZqGTjJGZET0SBPAwegaZNFNp5hp/ebfd8N2tmJn+lCDs+iNxk+cPrePrUp4bT1a2R2KDrOPVW7sHYZ8IX9+3OqmBwQaqQqGlA9WMUSLnXN573tUYL0H8wMvGBzFT7PQoKQmgUnuoJ/M5nvk6zFzj0qWP2S7+stdMS/ppxuinOrbf2H7o5ScM4Twg7JFbx+Erie+ehXya+rCci5E5L4n1U6Ei1Ahx3ugv808+e3rjZXh+aQXMpSjrPHJ8PRmAU5Akc52H202uMUNIB7y6NI1OpbYdlDuGcHkBcg01u8It5KLu2UPP7pvgVA1CVROwE4RmrJWCs57OePmD61WLy2aGdxwMqQgRccpeRUPmogqZa+TRPtQtNshlQwONTilA311jLCh5ZMSyTqXGF30+DWnxeiUbE6rHCxRF5/nOiaJ/2OXPebyGLN5oVCtO0hQup+UVER7K1VI2tqAl8/ScJHOd718/5uq7VmJgZEQjY63oBz4lDBUjIjOW2ipWgZ2E/IvDWqUDXkhGRvynRb9xpi1eIvhrHCMjni8kEGMeoitz/n8kmWv8FahlJ5fqC5dwxPECz0kYcGIO84yJjuV69Sazo/C7l1RzMRi7OLOqHyAiM+4G4OOecw3xEjAaWGXwJPw8R8DYg1Pxyroyn5NmrlOOmLYataprZ1MDwwT9xFhz+cOaIeQqS87sxzuFYiUAdvAo/FYifjFlCFN+hPMo30c8g1yl1jzkY0pHvBninWXgVH3+I9KLOdl8RWQuu17gDSNz3Qrva+HaW4k428HolIOa7zIInuHgMSNGyaxVLPObNXA7V7h7Sa3qdOL9gRaJJbf4uwI7muMt+bWguhohrOVKUB9K5roV7KwH1ZJjbXWSE4N+x6vVg7JkyjHRwP4gnsgWbLcCPRXD0912o+ax2Atb0SVv2XxQtNoHGuPNF+yiX29gULatvGoqrOQ0jMz139YCd4FT8yulooN23qk1qO7nDNAx+rF4KtnJ5i3HLXtBHXhqtwTYA1Nu4FfLpehSrlRhU4P7PRGI14sab7nCcm62qFFTTazMM2m2cBiZ65azw8eI1KYm3+EhgmwbNc91rAKRRWQ7RZcVIWDxQA+fqr1pyVuaxY41DVInArfkeKIz3jpSq00gQOVUmjyu4WQ+hJ3gx6nVICKeLZgNvEoZkahKPgZCEeB9Jk4VL3xg6NTSIUSgqY9D4tUTK1GE+Ih2aSiZD0NOjx8LO4DsEuzeiLU6IhI1SagBIh6cRWhp3XLQE+P9F5JhZD4cOT/ZfyyItLlaiGKjCeEcP4l2Qw69nEgnH301jcyZ/syHKE+O9yNXg56+jh764a4e9o+eng8h3sOTqK15eKY/8yELnR0fMnZOzg9UKnT66G16pLenQYYVL3ztHCEs0pz5v4o8OgUNfXa0v8Mn6Z39g6Pjs/NHb/ufSv7vP/+LFQA=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">JILI</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="111">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topFish__sallV"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="PTU"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="{{asset('media/logo_DS.png')}}" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">PTU</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="1">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topFish__sallV"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="3D"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAtCAMAAAAQuiwzAAABEVBMVEUAAAA5n9g5n9g5n9j/pxr/pxr/pxr/pxo5n9j/pxo5n9g5n9g5n9g5n9g5n9j/pxo5n9g5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9g5n9j/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9j/pxr/pxr/pxr/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxo5n9g5n9g5n9j/pxr/pxr/pxr/pxr/pxo5n9j/pxqnntYWAAAAWXRSTlMAUCP9hvr2FwsFDqKcWWRPBPc/PBAHh0MI8/KAMSQZDdi/rZdqFOfk1MnDkpGNinpXE+3htrSup2hhOZ9/cVJMSUcsKR0L7efez4lzbTjXx7eWeGAaultNHyQiKA0AAANoSURBVFjDjdbXWupAFAXgFYoUUVFKEFBRBGyASMcGtmPvDd7/QU6iQGYNyeC6UpLvZ7OTmdlArhQvHfc0rXdcisfjqTCEnKWMT+Y07XQuZVwsxR9gZK17sjDOiQ5K9NZj5fYIcPXFHPghpNGnzAZh5Dw/ELLDfHogJqnkNxcndJOvisIh8/t/5yP/7HSkZ0ShqeIzMn8ds/SCrY4lErIq/kPmG2En3Q87fuZexddlvhZW6NP5QJn4XZlfj9n3PQYHvsX8LvEemZ/9rf5B0sXV0KV3Q2e+SHwZiBCUghmt4KzjXgSu0ip+H5ib5Df7lBDpKBPfUTXnRObjpu5mPQbKnQjkfXTt8oP4tMS736bqzFdBWXsi3ifzPXknCPkBqb0qfkfNa3Y6C00R2FLxmQqwSXxjmo7ohihsSBe3xItPUcT2+hS1ztVP8hUvbdbEK3RF9Qo+myDeQedcZBS878+8ey+I6fwhKB3ijwKIvTjoxwBckfAEv5IUAG8ZlAV50QbX7fV5AOHa4qqs82nqvQNFp+rbBr/trIeM3WwKfwRKi6pfcuAXTR0h8685me/Qdr8Pyi3xK8yz/vtQrnPgtGm774BSZt6298s/+uvwvxcofv/MEu9HTZnPFez14/Fo0mP+XsXvyPyqW6Wb2ab3P5FV8Im8A899531ujw6MQwWvzzjwXPvDgfSNVqLPxOvE81GYeR/xrCPHz/vxzBJ8W/Tee0T9m3tz4wM0gl6Hm8Ap/6aa3+JvqPpii4qnNNcMiJzxIgr1KSWrOXUaFD6rJ5ejp9JKMu8JABrzwnRMebN/c5Ldw0FTT79HKyt6fSCla60emUeK+YOI/apN62aLnjbq1YGc6jeAkgOf22b/0YXfnHvF3ncrOwOHtLlK5jHvZn97dTSI8Y655KDfXMAIH1YarIT6nPWhn+YJPnDLLC+4GhFnAh+z2sMzfpmHwMqzjZ7/wk94Abkg5Oxa8hs5mEkU+TzxTbY/0xkaNSeefe7PZ54msbUs40mPb0QUFDxcs27JH76f70WvOCsEdKFBV57zwFhYVvEIajW+oTBcX4mVVt0rDAuXnbuNLSM32f2LBKDgOUHXaarxaN212HgYTYPn7ezPzLP7W2zUZyYByqkmxnYuC/tzqzlXb3RPJGgdH9EL/atdXIBT/gP2U0j1J1W0LwAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">3D</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="55">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topFish__sallV"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="JDB"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASkAAAA2CAYAAACbbm94AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAAbvklEQVR4Xu3deXxU5bkH8DcRyMaSgyzKziABFREYkKW31V5HW0WrtM1ta2trrQzYqlWv5dStWEvbKeBS9xGxLMoySCCJJMghAdGCy0TErtd2qr1WLSIjDiNLTPLc33PeGTKZvGeWzAyGm/PH7xOTj/rHeZ/nO+e85zlnBBHZsWPHTqeN8o927Nix01mi/KMdO3bsdJYo/2jHjh07nSXKP9qxY8dOZ4nyj3bs2LHTWaL8ox07dux0lij/aMeOHTudJco/2rFjx05niaA3Ms4ltAf/r9fzDtLuvBC9hjTkh8iPvHpSiF5BXuoWol3I77uH6AVkR4962l5wMdUXEG0tDNGWohBtRmqKQ/RsSYgqkQ29QrQeWdc7RGv6hGhVaYhWaiFajjx5coiW9AvR4/1DLQ8PCIXv6R96++f9Qy/deHJo8+yTQxVX9g2t/Hrf0Ppv9gvtvHpg6A+zTw39bc7g0Dtzh4b2zh0e+mjuyFDYPSp0ZPbo0Kc/KAs1XzU21PLd00N0xZkh+q9xIfraWSG6bHyILpkQoi9N/CO5Jq2k8ybPoc9PGUbTzxE0eZqgCdMFjZ8hoziwduzYyU4EgMlG1gIpAlIEpAhIEZAiIEVAioAUASkCUgSkCEhtB1KC6gpWACkCUgSkCEgRkCIgRUCKgBQBKQJSBKQISBGQIiBFQIrI25/o0QEyS05FBhE9Mpho0WDae/sgeu3agVT/3QHkv/oU+vvcwQSkCEgRkCIgRUCKgBQBKQJSBKQISBGQIiBFQIqAFAEpAlIEpJqA1ONAqthGyo6d4xMVOB3L63kNaSD1E4lUoQBSuzNC6hEA9SDy24FE95xCtBBY/WYI0eKhRJ5htG/eEGq4+lT60zWD6F+ZI0VAioDU20CqzEbKjp3ch3HJVvoBqU9TRGocwkBx+gGpo1lF6tc4m1qA/AJQLRhOR24dTn+dPZj+MXsofZAdpAhIHQRQmo2UHTu5jQAs2cyFKSD1PoDKpxe7S6S2FHEuyAlSdwOpnw0jmj+CGueNoLfcQ+m9OVlDigDULhspO3ZyGxU0meW1vAeSILUKEfRiN0Hb8HPLScAqX5CR/wuqA1RbexI9B6Q2A6caZBOAqkRWIyv6dgyp24cT3TGSDt00gv73muG0zz2SQrNH0eFrRlNjZkhxLlMdWDt27GQnQAVAZDsN+e8nQGq2idSufNFYXyze9w0Ve9cPFh9sGCbefbrPnn8uLaC3lxTTPx4rob8/XEJ/vr8n/fW+3kdpVe/FtKrPQiC1CEgtAlILgdR9QGopkKoFUgcSIvXTEUTzANUNI6sP/dDxq8a5py1qmlO2qPmaMYtavj92EX339EVAahGQWgSkFgKphUBqCZD6cxKkXlUdWDt27GQnamQySwmQ+sQSqRe7jzAv9V4RYl/NIPHy0s+JPU9NFXtWOrvtWNxz35a7u1Ht/EKqvr2IKuYV0VM/OolW3HhK/VuPlwla01PQ8lIBpASQEkBKACkBpASQ6gOkvg6kfm+J1E9GEt3ieIpuGiXoutGC5owRdA3y/bECSAn61pkCSAkgJYCUAFKCvjxR0AWTbk6AVJPqwNqxYyc7ASrmJVo2c0WCy72/mUDxpd4uId6pOlP8cfV54m8V54o314z70p8ezac3Hiqk3fcXk39xMb3sKaYX5p9ELy926LseOVcceHKQoJXFQApAtUdKACkBpAR5Bt9tidRNDqIbR41GBF0LqK5OgNRXzhY4kxL0xckCSFVYIBVWHdh2aQDg0fgjeRWXupxXInk5kpdwfDi7ItnJwXH7fSR8DPls9IUewrwB8XwkfMeUsw2pN0c8ondQcTkdCe8BPods5uBY1iI1yCZOiaBnkWqkCqnEhwJnI7Khl6AKZD3yTG+ZdYgPWdsHHyDIamQVPkQ4TyNPaVgvZAWyHFnWV9DvIuEPmqXIE5EPnMd5PZHHsKaPRsJr+zDyUGSNH8Aa8zpz7sda34fci9yDNV+MLEJ4/ReiTn6DeJBfDxb0K+SXnCGCFiC/QO5Gfj5U5i5k/jCBWpG5E7ljuEDdyNyG3DpCoIZkdGTeSIF6EnQL8t8OQTcjN3FQV1xbP0ZuOE3Q9ch1yI9Qaz9EuObm8gckPnQ5bmR25MPyB8jVqEWux6uQ76EmuS6vRL5zhqBvR3IF6pRr9ZvIN1CvXLPlyNdRt1y7X0VmoX5njXfT5eO9qGUdteygS1HPlyAz8eF7cSQXob75g5jr/ELzA1nGhZzvFPSfyBcjOQ99cC7yBc4UgX4Q9B/I5zjnCJqB8BwhZxoydarMOZFMmSZnDDnOSCZNl5kYCY/2cM6eITN+Rk6QWpYAqSVmk+3MFy0vFIj3No4V/6oYJ96vniDeWXvqPYEn8unvuNR789Fi+suDJfTH+4pp90L882NnTPnz0qniT49PEkeXoXifRGOokOKC5SLlolwweIUlUjeMulIWEoqKC4YLIh6py7HIvHjnYgE4cphThVRIiVJ8bKRspI4vUh6EUMdyf/UrZweBlOPEREq1+Z1JXsvzK5HaaSL1LbPJXhKi8flSsbdqgvhw0zixv2a82OsrbXh3RTf617Ji+ufSEnrbW0JvPlREgYdL39/31Gjx4dOniXdXjhUfrUTBPIlGWYLijkXqwQhS0SJcMKQnCrFJjdRpvzQLiIuJi+oHKAgugihSvNiXYTH5DIoXghfnvMk322dSNlInCFKaCVRbpAhI6TZSu/P6Aqmjlkjt7D4witSRbf3F/k0TxMfPjRMHassG7F9XSB+uKaAPni6mvSuK6b0ne9I7jxXQu08MqA36ANnqsSK4Zox4b+14cXAFCsOLhogi9Qh+ctFy8XHBcQHK1KD4VEhVSaSQa1EkVmdSvJiti7TDAqnU9qRSR8qD42WY2RWJGikPkDKAlAGgZLYXyGxD6pE6TqEXSOkAypUmUh4AZZjZiGzoZQApA0gZAEpmHeJD1vbxASkdSDlzhJQDSOlAygBQQYSw3gSkCEj5gZQXSLltpI4h5bRAymMjtTvva0BKPSe1s9tu2WxoxJfyxJG6weJg7VjxiTFGhGsHXfHx+u50YF0xfbSmmIKA6sMVPemDJwpo38phd364bpLYt2acmQ+A1N51Z4umpVzAaIQlKGb+hOWim98GKM49Fki9YBYQFw4XhtWe1KVYRF7A8yddhbOqzO7upY4UA9V6icxRI2UAKR6MJQAls71AZhvCz0XWcQr5+UgCUJwgkPIAKS0FpBgoMrMR4bm1isjs2jO9ZXiGzYes7SNn2XhMZFWpgTizhJQDSPmAlBwzeQA4MVBtkSIgRUCKgFQQSOk2Usis8X4FUi4bqd15DyZA6n6z2XahOXf2EIe3jhSHjdPEkfoycbj25KWfbOhG4YpiOriuhEKA6mNA9dGKEjqwtmzSgWfOEgfWnRHJ6WL/+rPEx77TRQsX9/0o5mihtQWK86t2SN0MpH582rPy7h4KhIvDCqlLJvTG4t2FBUs0gnC5EqX4dA6kCEgRkAoCKT1HSMk8XerKECk3kAoCKUoDKTmCsnCQH0hpXRwpvuTzAqkgatkPpMpP3I1z9SMuHcvuvDctkdrV7RIETZgnml8sFkeNYaJx62DRWDdEHK3t9daRqgI6vLGYDlWU0KF1PSm8uojCq/rsO1RR1u1QxRhxqGJ0mxysOV00Lkex3I7iUwPFaX8mxUjdMOpdFM2TNLdsOYpjOYpiOYphORZ+ORZ8GRZ6JRa2Hkjtx+IlGuZs4IOoRCk+nQsp+azk5mJvDpEKAimtg0i5EQJS1EGkCEj5gZTWhZGS4W2L6J1qG6m8YUAq0QPGpVGkWnb0Fk3GqaK5fqBoqjt59Ke1hdS4qYgaq4rp6IYSOrK+hA6vKaLDvn5rGzeMEI3rh4jGiqExGSKO1A4VTY+imH4aKTh1fmeBFKFoCEgRioNQFIRiICx8ehPnZ80YjKhRis/xQcplZhtSj9QVlAMpHUj5LZAiIOVJA6n4jXMNSLmAlFeBFAEpvQNIlZtAqZEKACgPogOpciClAymfBVIEpIwOIOW0kco5Us7PCqnvJUDqeUTeqXopXzQ/PwA4DRFN2wFNXd/rm2p7UFNNEX1aXUyfVpZQI86mGn1FAGuo+2j1GeJoVVnbVJeJIzVlomUxFxNO6dvjFM1fcoRUIw6k69iBVKEUn+ODVKK7ey7Er0CKn5l0dRCp2Lt7vHEej5SRJlIakAoqkAoCKbe596i+u+cAUn4FUvz0gTsJUhqQ0lEnAQAlR1buRO4YHkTdeBFXBCknasgwoyPzRhqoJ08cUh4gZQApA0gZQMqIQUoHUn4ghbpD5qD25pQFgZQXSDkUSGlAyo269AMpAlIEoDgBIOVFrbqSIMUjCAaQMlDLBpAyLJDyACkDdW4AKQNAcaJIuYGUH0CRGe6BcycHgZQXSDnTQEpDdCAVMD/gOU4zQQDlQ1wRpJzoK8PM2TNkxs/wqLDpaJYrkXrZRIrvWMkm3NVdtNSXipY6pF4TLVtLKpo3F1AzkGp6tpiaqkqoCWdTnz7Tk5o2DhneVDVcNFUCs9hsQnBGZRbczyOF1z7DUIjt56QyRWqaidS3yYmDGj11VaEUn88eKY4GpAwFUkYWkHJkASkvkJJAtSIVBFJOIJVsBEEDUn4FUoEESLmRIJAi88OsLVKybji3DfcAKZdZQxwdmYda+gmgaouUAaR4WJiAFN+gISDlAFIBs95+iLRFioAUASmuQz0GKSeQCgApWZdtkZLPmHKtfvNMTwKkDCR+41yFlAGkZJ1fiFyAWr9gkoaa9wMpAlISqFakCEgh6IXPT/GkgJQbQAURAlISqFakCEDJTJzuQVwASl6lnD1DZvwMQ9AeAJONvJ73bgKkvmMi9Qr+vZ2FwKmvaNkOoLaXdm/ZWnig5blCaqktopZNxdRcXULNG/CzovSvzZWDRPNGXBZWxgS/NxmniBaePr8NhcbFt0CZm5TDnNlB6hnzVDUaFUrx6RxI8QiCFtk4j0WKgJQzQ6Q0BVK+NJDSgFRQgZQLSKU6J+UEUnx3TwdSOpDSgZQOpDQFUgwUmUmOFAEpfweR8gMpWW+JkSIgpQMpJ+oxCKQoBaQISHlygJTfrPnkSBGQ0hMg5UbIBCo5Uhy/BVK45Ms844CU+s2cL5/UhAwwG/BVNOYL3DQo6noUe33PqUCKWnAJEkWqBUi1bMTPjdojLVXAqHJA2zyL1KKoH0PRzo8U3bFPykjk72/lBKnontTE6bMQeR2tQik+nQcpnpPSFUh5MkTKrUDKnQZS5UCK4pAygFQuhjmdQCqYJlKyhtJHitJAioCU36zH1JHimnVlGSlZ86khRUDKoUDKCaCCaSIlgcoRUtclQOoNs/mijbgdjVKHS4t6NEt94Xw0EJn7JGiaFjSLiVQlflaePKulaqBoqeovU4lU9xMtm/oLWomiXoKifwjFGkWKizEaz6BZKEr1s3s3O14BUptQNDVAqgbFUYOiqEEx1GDha7DgNVjobVhYfse5NVITpm/BQTyR9qRikXIokMIlX4eRcgOpYBxSASCVzgiCR4GUniOkDHMroD1SPsQV2TjXUDfliJEFpPhyzw2ktMjGuRNAeS2Qkh+aV+FsSu5JOSIb504ApVsg5csBUny5Vx6zce5AD+gWSHkVSBkmUO2R8iEu8wrEOU0DUOWIcTyQqkyA1EKJFJqSN863A6htaIJtDFXhdtpacAwps1nMl95xc+DyoRINUIlP6Y1IFf75WYSnmR9HkXNhP4FwwUqYZHFyPIP+jcs9FVIHzGK6YZS82zK3LNGclEaXTvhZAqQO4QD2RNQoxadzIcUT5/FIIUmRSnUEIQCknGkiZSiQclkg5QJSLiDlAlIuIOUCUi4g5QJSyCAXkHKhDlyoDReQcsYg5QRSqI12SLlRK1YjCN4MkAoCKc2st/Z393QLpPhyzwmkVHf33AqkKMtIBVDzGpBS3d3TFUgF4pBymtsi7ZFyo3esRhC8uUZqvyVSr5x0udmA3JQ7e6B5gNN2NMm2olI0UnPsmZTZLNVIVa+dVIWirgJInGpkE19S4OfSSIFzYfNjMTxXw5+q/AnKn6SLTn0AhWn1qpa7EHl7mAvGCilebL5te7F5a7bOAik+gGNOYKSMHCGlIxqQSnfiXIWUZoFUKnNS0Y1zAlJGDFK6AikDSCWbkwp0ECk3kEo0ghBQIOUBUolGEPwKpFxZRMqNmk80ghCIQwppg5SuQMoAUq03m9ojxQnkCqkpCH+llQqpRjSfdgypF4FUHQOFZtlW+AU0khw0bHMmhVT1WkhVkbOnaj6DwiWGD78vixR7LFKPoHi5kO9H8S4+5TKzUNVINaOweqHA5GwLFwwXSTxSfLfkqwCK50d4buTLE29MgNR4G6l2SAVNqLKDlNUDxpkgZSiQKk8BKb2DSDmTIMUjCPFIlSdBSs8xUs4kSPEIQjxSrhikDAVS5SkgpauRUn+XXjq5JQFS/mMNyOEn9bl5zGbqcaMSqWpc7lX1Ol9e3gGnKFArUfRc8CqkuIB/O3BGkjdzXofIguOfP0LhWCHFL7u7AIvCA25fnnj9/9MzqWAHkLJ6wFg1ce7N4eVetpFKZeK8oyMIyYY5dQVSrs8YqWTDnLjkSxupVCbOLUYQ1PCkky0JkFpgNmEDNx/vR/HrRI6Fn9RXIXUEKT7WLLxBuwpI8V6UNVJXmYVrjVQD3RopOAaKJ4ITXe7xIjNUchp3hwVSYRzAkhMUKX7AOH5Pyp/BxrkGpLxxSKU7ca7aOHdbIMUT5zqQ4olzHUjpQEoHUjrWn0cQEiEVsJHKOVKBzoRUN+RgAqS+JJHKk5vm3Dzy3Uc9gFTYAqnNkSaRDcFNwO8qUiPlRCFXo4Dl81xqpFrojmEDzWLTARQ/usCFw0WTaOOcHye4dML15uKpkXoOB/FEvbvnViDlzQApuUar+wTikAqmgZRbgZTXAqlEd/ecCqR89plU1z2TuhAhC6QO0av5heZslB9IcWO1InUBkJIPwbbbkyr5mtkk/JI1bghuhLZIDUCBz0JhVwIpLuRE3xYTRNGNNQuOz6C4oLiYkt/d64uFvTfJnFR55MC2xcgqDflOxGXGH8lnh5ShQMqdBaR40zwWKf4aMmeKSPEwZzxSPMzpSBMprwIpdxKkXDnck7KRkki5Pqs9qTsQK6S2m2cLfOZgDnGaOMk3Se7o8esESF1HlSUuNMXFaIiZaITvoAHuQOE/ioI3UOyHUeCpfqVVFYpuHAptJoprJopqJoppJpCaiaKZCaRmojhmoiguQjFchIW/AQvOb0E4YC6s9cT5WzQp5kCrUIpPQ75hHpfoWaY80/wskNKBlDzerUgFgVSmj8VYIeVKESmcGSsfi/EDKS1FpHgEIX5PKgikANQxpFR397wpINXRifOuiJTq7p43BaQsJs7V+KSaZxArpG41keL3nnPzPY+GkUBxdidACo2RtS8Hbf/64Iwfi8EBnzxtIk3G6Ws0KpTi05DvVSBVHoeUhgRziJTHPNbtkdKzhFT85V66SDkUSPEDxn6ssSMJUjwnxS+9i0eKH4uJRaojc1I6kJI1ZCOVClIdmZPSEQlUFpHqgXyMWCE17RhS/Nwen0WZ7+Xu3h+N1YRmOh5Ixc9JZYYUL8i0qfNwwKMPT8qoUIpPQ75bgVTQhEoi5QBQPkQC1YqULwOkHEDKhWPsAVABRB7rtkgZOO4AKiOkHFgjn2LjPJ09KUaK5950BVLRV7V4sc7lCA9zMlI8zOkGUgaQSudVLVYT5zriiEHKgfiAVCYT510RqUQT5zriiEHKgfhMoHKA1FSEzLRHaj8iL/X4u/h40/x5s7E43zAb68RE6hYgJd+Nkz5SGhJEYpGS4dfZcBio9ki500BKJvWX3vmBlJYGUqnMScUi5ekAUvzSO68FUnKdOZm99I6f3VMhJZPdZ/e6KlL87J4KKZm0nt1TA5RKbkOskFp/DCj+yY21w2wsjvcERCqABboQC4KD32GkOOVIOkj5TeBzg5QPSGlAKldv5vQDqY6+mZPjyQApA0gle32wniZSHZ0476pIcW/oaSKV9T0pP2KF1LVmUzJSvOfCOHFjyeY6eAIh9W8s3u1YsO7mAmWOFMedIlIMlJYDpAJAikcQcvVFDBwDSGlAKp1hznikeAaOhzkDaSCV7hcxyNe1JEfKB6TKbaTSRorD75NKBSl+di+rIwhTEAmUCqnX8oebQO1GeD9qR48oUmeguQ7j9zCaieekwmigMBonjKYJo1nCaJIwkAqjKcJoiDAaIYwGCKPwwyj4MIo9jAIPo7DDQCqMQg6jgMMo3DCQCqNIwyjMMJAKA6kwii6MQgujuMIoqjCKKQykwiiaMJAKozjCKIpPUAxhLPw+LPgeLPQyLOyVQKoIiycXLHtI8YyUA/ECKN6TikfKj2PmNo8bA5U5UgEcYwNA8ddaOXGsoxPn2UbKD6S8WCcXku2vtCrHGnuBlPw6q/ZI8Z4UD3NqWH/5kHnq3xbjBFI+C6T8iBtI2XNSHUeK+8WB8N09FVJ+JDrOk1Wk/gexQupFEygOv7GzLVK90Vz98LuGZtLQSBoaiN8WyRPQvDeioUk0IKWhKTQ0hIZG4GlmDYXPlw4ail1DgWsobA1IaShkvj2toXA1IMVFyvsQGpDSgJSGouNXbmgoLg1FpaGYNCDFT6VrQEpDcWgoCg3FUIqFL8SCy4WW3xYjH43JPlKxw5xOAOUyI+/uyWOWHCkkcrdUzp7JTfPEd/diH4tJhlRn/XJQXuvoWxCcQKojr2qJRSr2HecuM3ci8lUtsSMI9jvOW5FC0Asde8e5y4zTDL+qJXYEQYWUVwVQsqxGWoFqj9QsRN7Vex3/vjkjFWmsaHNxY3EzcSNxA3HjcNNws3CTVCLWw5yywLmw2z67h2JFwXKRcmHy2znvRvHxLWUuNC4uLiouptRe1XK8kIodQZCxkUqElNUIQjaQSjQnZSOVHaSsRhCskNJVCH0VuQgpifkbZwayE2kLVFuk3kNav4ePz6T4kZhoU9lI2UjZSHUVpHgEQYZf03LOVE8KSHkUSLljEeKMN9GR2Y/UIbXI65G/qdOK1LntkOJwg3Ez2UjZSNlIdRWk/OiN+BEEvtSzQsqJBBVI4aC2AsXDmR+a6KQbidS9x1CKzRsIN56NlI2UjVRXQkqOH7QfQYgf5uS4TaDaz0n5gFSbs6gtx9BJN3vEeuU3yHD+gP+3jZSNlI1UV0NKQ28EFEjF3t3j792LnZOKR8oZi5R8ULhj+R2QUgPFsZGSsZGykep6G+fyG2OskYqdk4pHyo1EvsH4DTE7Dp1U04TchAAjG6mksZGykep6SEmozpnqTwMp3peSQMUgtSyCTqo5iDyGjELkmZiNVPLYSNlIdU2kZL+cM9UNpPjrrKyQCiA6gNIQCVQMUpwxyI8RvpP3JhJEQsgB5G2kAVmKfA/ph0T/OxspGykbKRupVJCKnZNyAig50DlpOkcDUHIMgYFqg9QM8X8K9Oj+EuBOsgAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">JDB</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="0">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topFish__sallV"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="FC"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD8AAAAjCAMAAAAUlSINAAAC91BMVEUAAAD/eyL/dib/fCD/dCj/fCH/fCD/dib/dCf/dSb/eyL/eiL/dib/eyH/eyH/dCf/byv/bS3/fSD/byv/fSD/fCH/fCD/fSD/fSD/fSD/eiL/dSb/dyX/diX/dCf/cSn/cCv/cCr/byv/cyj/fCH/fCH/eSP/dyX/dCf/cin/bS3/byv/iRf/fiD/jRP/dyX/eCT/eyL/eCT/ghz/ay//bS3/ay//cyn/cin///8ZGXD///gABHJIJ169vcoAAGD///wAAGfo6PEACnM4H2AAAFsMDGkHB2UAAF1zOlUVFW3///rV1eW6utT+/v7Y2NolJXcAA28AAGL9/flCQokAAGn///4AAGsAAGSgoLoCEHgACnQcHHIaGnEXF28TE20PEGsFBWQ7IV8AAFP///fq6vL///HDw86/v8unp74AAXcAAG0ICGgAAFf4+O3r6+zn5+nPz+FxcZ9fX5lWVpJDRIsgHnELEG8sHm4EBGMjFWJNK2E/I2BoNll2PVOORE6yUUP4aS//dSfy8vju7u/f3+zc3Onr6+Xd3dzW1ti7u9W2ttGtrMu0tMaQkLaNjbGGhqx9fax2dqNnZ5tQUJIvNoc4OII0NH8tL30EFHsQFHRGKGUQDmQNCWQFBWBZL11wOlkAAE8AAE2gSknHWD7VXTnmYzXsZTP/byz/eiP4+Pv4+PT9/fDh4e3z8+jZ2efm5uPh4eDMzODS0tjMzNTHx9G6usqbm7+Wlr6Li7eWlrR0dKdoaKFra55YWZlXWJRSU5FJS45TUopHR4c9PYYAAYQYJX4kKH0ADH0SHXwsLHspKXogIHQACXIsHWc4I2RIKF9SLV1/QFMAAE6URkyqUUa3U0MAAELAVUHPXDrfZDTmZzLsbC7/byv4byvt7fbk5O7o6OTf397Jyd3AwNi2ttKmpsivr8SursOfn8KamraFhbOHh7B6eqZtbaZOTIwiLYMYFXRhM18NDV5PKlxhMlpjMlgAAEyaSUujTUnIXzrhYTfZZjUhPZDoAAAAOXRSTlMAj+uS7r2TWu/uhHHo1YtDGgXx79/JrqmknpiTY11MMiogCfrCun1qSDwUDvjk5OHZzcy0l4BYVDRgHV1tAAAEHUlEQVRIx5WVVXjTUBiGg3VrmeDu7m4tkgVIl1EotFChXspgaztgY+4MZ7AxYBsT5kxwd3d3d3d3u6DLSU5Slhveiz05+f7v28n/nPMXIWnertL/4NG+Y02ETeM6lf8Ht54NXdj2XjejogdzERUVdYHr/de4W13bQ3uTWxqrbBAHMpsmI4NLUSlkMffq0f4Gcbagh35DKuA3P9jinTS3guLn5x8Upvj4pxrlr3RtULpEObAiwtVHCkJnCSsKSuGGQ+rMO+2Av2XZJ3WIkJNVoQWnpdzSdHlWWQ0Q4JKQZUnhrgqMuDxdyEY6h35ariryaAUCev/ElnL7H6P4YS/W+v5yf/pxoTzGvRnw141RvVJy+nda8MUSZjkn23sDvfTVRt4VkPZWrSdoJ3sxRYEjIctwuT+jJOZ8PzAFLj9ElDQEx3fGimPz4OuZYtwbYjIameQki5nYOxCmpcqLG4D+rVSHTIFt3oSaRkAM9lOPaP+efJMOT2Y6eTJ7Bo/0C+KxpRPh+2cBIhboQSp5VUi+QT/CvA3WrbVFu1Yn/fXiFIuZj9xzWUxjN+pxKnl2qEWnFxlEaeMoQtKtsXU9SX+PXBurScuyx9CcPmPAQfKoHFzn2I1eb0dpvE/8aEgeoM6l54ax2j91/miKeev2E3J/paOl764XEAHmMyInNDfA9j1LsOMbWYdEMpZC4pVOiLY4lE2HglLeJgeLneyZmcXg+FQvwg6s4Tw+Q01E2tzy5IETHbcpGTTWQP3VnCttSfobFWJLJEIunhB48CQpbAwuEumMBEpC2E9c5CMkbWIVu7w4/dsDcCZZesos0pnNSc/Hl7Ntr8ynLfBX/iJbxO1PsRBM8myxSReBLpJMBLPhjbzQA1z/0siMzbBKuuDpKJoFR3LsTPICQo9GTJ40jVruQ282If0dfmOpc2FVYD6uwGisYaKtsLE7AlDxFmgXnlwxYwBofzy2n2nSQuJ8rA9NbGTYViHN7uvG0Yw9UZ5bCyGpH8du/2v51W5tq1F0+WZ7AZXjnzeuAXYwfW7wgN89RjVeyYw1tIj8LBB9BQuC1yVt85SpzFwhsso60cNjEOv0pqIlntDvUiwzzaKEB/PXkY/gK3HtbQHCDA+4/5mayLs1EEitPMVhWlrN/PftqPWaO4LQw+Mgc/nXqy66IQzNEsLV732BxNQE49artTqDipqCeMX0qUMpfHdgl6ohLBrdCcfCdifO9qX0oYEv9ymw0F916E22qOdzVKMdRqE9e7SwCuIUkJAnU6tldMVZlRwzXkqoD3+/m7r5hEcPh5wPX9kUcaJ/ndtXcqOHT3BQXnAhL/5e3Q6M3Ld2bX5VFq61WyD/4NLA3c3Vlc/nO9Sq3dt4dGSL/fo0rsKG17jTv/6antUr8XhArSJo6pT/F3GOK9Is/mssAAAAAElFTkSuQmCC" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">FC</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="157">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topFish__sallV"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="KA"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAAnCAYAAABjYToLAAANhUlEQVRYhY2Ye7BdVX3HP2utvc/7PnJzX3lAyANMIAlPIVKHMghaRJGxQ8e2Ugo+GKudtuI4bbVOpdpq66OdSseOnY7VioyC1QJSYQYEebciIWASTCAJ3Bty3+e5H+vx6x/75CYXa3XNnDkz55w567O/6/v7/n57q5lPXQdB0IMVABAISU5oZ0juUJUIyRx4QZUjQi8/U5L8Rt9K3iFOtuA84oNoYV+v2XvY9bLHpZ090l3sHNSRoYZGKWilOS6zREbjlcJ1UiKloBZjUOACrVjRyTJKASJ+lSUAXBwy+0ehl/+WZBYiA8EVX/ugnPXbKqVom2h9U9AaE5v/Cal9Uln/Q1x43AeZ8iGgtUKU+qVb/mKwIIBCGX2dKqv3hCT8esg9iIDW4F0BrACjUcETXEBEkMhQqVYuCJG5wGfug2QuH1Dqx07rHzlrH7YiPw7wqgf0L2BcCSbFS7QZNBW5UR+bucnNhq3eR5AmxCEjrFqNM2WwHiKNmZ1BzTZxuoT4gFpqobTGj08iATAGsb1SfXrqDQHeYOGjAVoOns7hR96PPqSUPB20WgxaFRcKqJlPXQc+FB5T+hREPqTy7IbOdHtsceJsmNxAiKuoYFGHDtB4/hFqZcETI7MLNBvrsLsuhfFxUAKz85jHHqH69JOoeg06KXknJ738ctSFFxJqVYzNUXv3oW67HRabOFVasoYnu7G6p+nt12JUU8381bsRHzCjA+9TWn1R0qwejh6jd/XHqL7xYqL+aQnggeQne+Dj12PylHzTBZT/+WtUWb5Q6P9u8QMfxH/9K4SupfqVf2X4vTes+I0GlnY/w7FzzkUoEVMiQ5jBvWrK8eXmI5fuwAzVPqzK0ZeUUiUEvAgDEYyU6lRrDarGUM1Savv3wCN3kU4dRqIyKresDjA4OEylWqMSApXZWfjenXT/6z8J1hHiEnFrkeFqlcbqUSqRodJswsMP0fnSrWTP/4yIEgnQQegSGnPB7VAzt7z7omhy8InQTgm9HMk9qlIitGYRr9H1VagAPkmxR44gaYoZXYc4j2+2cC8eRo9MYAaGIATs3BL5C/uJRidQA0OI8+QHDuGSHqWxdTBYQxZa+MVjKMCqQVriWcKzgGeJQA/fVfO33vQtPVy9FhcIaY6f7+HnO4RujuQ5YNG1GBVHiCohPU/oZYh1iBPwAd9sE9ptJPOgI1SpiuQeyS1iPeIESS1uYRGdZhgMCYaOVrSCYxFPC09HFbkkIp1ID1W34QW0wgzW0AM1zNgAfraNm17CzTjs0TZYjx6oYFbXMcM1xDp8My1CuFTGDMcFjPVI7opYOV7sIWAiQzwyQtJNafYSmjanHQJdhBYeD8QorAQ82IggMYWxCE7Ae0gtZqiKGakTdzLc0Sb54QXc1CLp3lfBBcxIlWhyiGiwjvae0Enx1vcjp4BSSmFKMVoZklaPpVaHXjehTaDX91ROwKAQwIngikKzESEsojWiDSpPkP0HCauHYWAV0kyhl2FWVamOnYKctQY7tUj2wgz5kXmSF6YRE4iGB4knh4kbdVQskBtC6giJkDW7tBfb9JopPRwJijZgETyWDIgwBCUEEQLSV0ypjgRBSUb3nhdwW85nsNsjf3Y3Ic5Ra9aiXBXp9RDv0YMVahdvpnb+Buz0IunBo6RH5uhOLxQxUCthKjVcasm6PdI0xSNYDG2gh6CBLhYNjKFZwONE4YEciJTKIrEhQUH00hHm4gnkM3/L+iTgn3yMZO+TJIcfIyQtkBjxAUkd5D2C9ahSRH3nJmrbNuDm2iTTc7QPz7Aw9TIKjSJGE5EgLOEQIELRJGdk9RjnfP6LtOIyzfdcTzvtYVC4fjvSoZcvifVgIqKGRr/yKtQ1pcveyNAHb6Zx6bvw09MFlA2IF3Rw6NYiLs+xzQQ71wKE+oZJ1rxxB2tetxHQKDQWaONRKARFhkWimCvuu5911/8unfN3otefigcChceM0j4KnTQzwzWCUugkIziPSAClATCrJhCvEecRG4gkJ3txgdzXqbSmsL15QqOBWj2K6uaQO4bXj5MsJSwdmyMjxiMIxVF1ECa3bmfsvLN5ZXqKAa2JT9uIP7APAQIQG51pAu2QO0QplHeQ2WUogOBygguQOXQM8pP9HNp1NfqeH7D2n77O+Htvpn7qmfDSLNLpIR7yxS5DI0NEukyGJ/Q3DEAKDG07gwio1utE9Rr1jRsI/VYWFdXZiZRRPclccUQ+x1hLOLmnRRH4QIgM1b0vsH/tuVT/7MNsXFVDX7KLxiW7aAB+30EOv/s3sfNzmNoASgRlDC5keHR/cPHkwMg55wCQ7D9IZdMGKuvWLffjGEidy/X8/ul2HEcEFMal6DxfMQlhNKI01bljzC5GJH/6cc4cGUSfFKAAybEjZK8cQZkSuFAELdJXSvr+8UUlXvh6AA59+1vUo4jamVsp9RXrj3hONyZXLdp2QhBB2YDK7IoNRcfE4kmePcTLN/whZ1xyIY0Q4KQptPfYoxy67DJ0pYqKSkjuipbVD8zjcBlQRrHuogvpzM/z4lNPYvKckQ0bqY6twZ3YNuhSKbI+tUigmLlczslaqHodvfsA+y96KyM33cCpwRcTbH/Z6WmOXPsOzMgQujGEpDlYT7AeL7JsaI+QAAOnbaQ8MEDzwAGee/gh8qlpBrdvo3bG6cv7KlSiXStZIgghaFTSgzxboVi11+Tghu3Ymz/K9noVtDmhprUcvupKwlKTaM16Qi8rxmsXiuNchgoEoAOM7NwJwDO3305cqzE6OYGOIxobNy37TEOmdb3UIfeID0WjzrIVirmZRaK3Xc2287dTCSfKQpzjlRt/j+SZZ4k3v47QTRDrwYV+FXsIAYfg+17LgdHtZwGw+bI38ZFnnqG6ejWu3aGxZRNx/0KALArN1IoGlEJ7h36NYvnQMGuff5pTYMURNm/7Bov/fjvV7VsJ3XQZSpxDWUF8ICiFk8LUhctgbOcOALa+/W0ALLTblBGGNm6iBCSAAqtLtXKnmJ08yllMtrIq41M3ktx7N8n996743IyPF9L3cnAefFgOYfrvRVOmr5ZQB8b7R7lslSjGWMvg6VuoD4/QL72unntlLsEFlA+Id4h9jflLMVKKmf3Hz634w4HfuJKBK99K+uKLxZ2V9Se8ZT1Yh/TVCgp6QGN8kvHTT1/+j7v+/GN89/3vZ3x8gvr4OEOnbcIBGsl1d2pxAR8ycYJkGWRp30R9sCimvGUrrbseoPvowyvgxv7iY4Ui7eQEVO77URFWJH4HWL39LFQUYZOEb/7+DfzL3/w1U088jnGW+uaNDP/axWTAaLWW6HWb11jJfR6yIjKw/aM8fn9XqaCqNQDmPvd3K8Dqb7iYwcveTLp0DOUUkllwniDHw7II1iCBFBjdUfhrz3e+w3f+7atsAdL5eSpxiUHg5eeepQZYCfu08iFRInnIHJLnqFIZfdLmqlwGr4jXjND+3t30Hn10BdzEpz5ZxELS6UMVlego4I6/a2DtBecDMPXMboaAGpB1e+y+5/vc+dareOmhH1IHTO7v0y/tfbmbtHovRx5YNYj89w/x09MnwEyEagwTkhwRmP30p1+j2i6GL72C1LUR0csgx9tQQLBACVh7bgE2d+AAEWAA5R1ffdtVPHfv9xkBhoz5k1TJMa06GZLYb0ruUJNr8E88yNG3X8H0H7yP7sMPkO7ejT06jYorlE7dwNK999J76qkVcJOfuQUPWJJlKH+Sv3rAwKpVjG3bCsDCvr2U+9/hPRWgAtS1vvnsNeN/f9b6SfQpm9dQLsX/YNP8p5LkRGMTiM1Yuu3rHHnnNRx6y+X4o8cwQ6sATQBe/fgnVoDVLtrF0CVvokOGoPEKvDrRwNvA6rO2Y7RCRFh48SX6D71wQEWpzqjSb49QX0ApIq3QWWYJQTJdil8fcveFdL49E1XqVM/YSjwxWRjfRIQkQ7KMcmOUxft/QPuBB1fArf/8Z5dVcyLLfdL1FTv19cVE8dPvfpfFPKPUV6yE2jegzHl1Ze62UtyQ+CCYP968vkj9krG+l983t3/6y2lqn8O6SIvaEimtVRCk35iVjiDNWbrjDlStRGnjaZjGAKW1a8kPHGJmz9MYYgLQJjCDpwdcfcstLE1P8eVrrqHkijmihrpjNfoKr5gt1BMmBxsYrVEvvXlXAVaOyBe6zDx3BAvUReGN3hCVzDUm9+8soS/RPqByT7BC7uZJAFMfZPCqtzB50wfIZ47x9G//DiUqgGIKx16K+BnbsZPpPc8Wg6JSDCjzSRfCX5ZRWF3c7PYkcPa6CWJjfh5s9vmXCUZTRZGFgAShvdRhqFHb0VD62rybX1MOYQcoMiCjRdI/TlNZhU8zPIICpvDsJycCuv0qjMBNVsrvmjClOw9229QxuP8D7OTI+rmllMIYjTEaFHuCl0/Mid05Hctl7YhbnZIjhgZl6mgibLq0POwVraV4pUAZGDTmZxNxfJ72cmf+mgn4tev/BVsBCWilMEphNQ+2jHwoI5whlehaG+vbvCq1AhUUhembBDzCKPq4Uv8xaMz5VRPtsb8ECn7Vh8OvWUb64ShkEps7qEZ3dLrJuM/dVUrrK5MQzusiIxrS8aj81KCEbxz12beDCE6EX/5oGP4XBJq0JmQe5C0AAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">KA</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="16">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topFish__sallV"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="CQ9"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEIAAAAYCAYAAABOQSt5AAAKCklEQVRYhZWZe3BV1RXGf2ufe3OTkJBAmMhDoUogFQhqiUMLvmjxLYNTO7W2RdShjbUO43vUUuuIio+idUYdpopWfLb1USEFW0GpFkFQAgiipYSCRQmUQAghN/ecs1f/2OfenBsuAdfMmbn79Z21v732WuusK8Fmj6PIWOAsoA4YBAjQCvwLeA94/2gABaQaOBU4ASgC0sBO4GNgb8EVoYACnjoNjiyDgcuA8cAIoCTS9xNgKfBmoUXSCxHnAncAZwKJXl68DngcmN+rek7OA2YA3wWqCozvAf4KPA2syBs5NiJuBn4F9OtFh/eAW4HV8c4jEfEYMLMXsEKyDPghjv2e0i/CnPY18BYADThrORYi5gPXfA38G4HfZRs9iRgG/Bk4vceif+CYzJptKVAPXAQUx+YdAs4AmmJ9FwLzgKE9MLcAG4ADQH9gNFDTY85m4CpgdS9ECM7cp8T6moFXcNe3M8KvB6aTb923AHMBJPjMOCylGmeOcWUagXuBDyksI3Dm2BC1VwCXI7ozwrwAWNJjzavAU8A7QBDrT+KIbcCRl5U24BxCWZfr8TSONxuYFWs/AdyJI7injAP+CAyP9Y0EtkiwMeE4NboIuARwzAu3Aw8WACskV6FMw3AuiiUUMAxAdDvOekAJEa4EXjoGvAaUJxFM1P4CKzVAJtItKydg9D8QzVNeBn58RB/i+odiaULoH/W+AEyTYG0KDOMxuiq2ZC6J8BYMjpSjSXaOAbo8d5895iHakJsjOoWEbTwGNIcXmsmovB3rfRrlZz02didwX9RqxbMnIbThWVDJ110AG/0ImYI1CyNifJTRjknLbAKBQMCXpSi3YPRYQlW+Xl0ekjEIjCGkIYcZys8RbcRo1vogaQ9/jILk3ruUwPw6hxHIDAnMKPENMV1Pi43Pwzdt+AJpz23aREwYwDeQTrqDCrxFhPJRtC5JKNcmxPfqEZ0c7cWqcBOBgiYce8mQHMN5u9boReKOsDPhHqMQyPTY7FUq+hTqQWCgJHDKdCTz77oVKMsgnqJdnmuHcr+oXInzReDC76ciudMeHNPo3ZwFqECXouU+eCGExumGOL3dr/dQ6qMVExJYOQ8kq/dqQT/BGkwSSGUgVChVl5aE0b4F8IH9SUIVCAySjpyxBUTP7tZPHxfEuUUFDhahHdHJmBgRKtCWguIQSYXZjVrgGWBONGsyGoU8UUD6xIjYl3dQVpC9JejBJNLHdxZniW2VPbHZYYLAnJZrCm+BIglLxgpr19XwVtNwAgz1ddtJdyXZsHUQlWVpLhmzlVEn7cRL+XCgDBt6YCwogzBSFyF2ILwPznr0UBLSkdUUh4f7n9Cg7R4EPlIcKe6ywfsj+sehUorooWhFPGc5HvjYXT0LGQ/dn4LAoF0G6dflLDCI/K/oibG1QYJQ4lnYNhCkTyfLVozh7jfOorw4g1phffNALEK6K4Ex8M/13+CMk3cwrHofl45tJpXKYAMPYAhhLrdoAXaCoBnP3dOE211BJ2yi65ZOgAROcWUH0A70BSqA40C2RTdyR26tcpmqvIkVsB5kovwoFYIF7Ug6S3NXwyByQfzVCQKJX341yRD/f+UsXlfDgLJDVJR2uYHIR1T0Sefaf9swnJZ9ZRRbYeo5Tei+MsTlA1nxEUKsgC/5V6E3EUXTHlJkQdRH8/INdwcdEWtwSRK4rHY2gWzB98haYS7cBga14vxdQq8XNC/BS6g17TEnM5jKdhauOp2PdgzkpKq23JBI/iZElIF9OyhN+TRuGM7UcZ/hpXzCjuJWuuf2AyoIpS2KPiVALVCJM+VqXGbq46xnO7AL4XOsoL4HxvYDyqLN+8D+WC7xAso9UU6QAp4F+R5Gu1DyrS4bseB8rDymcecvJAyh2Yg1YA2Cnps5WMya7cchhpONsbVHPLXoPX2Lu2jeW8GjS75D2im+DWu+iDCrCcyYSKGrgM0oTSjvYs3zWDMXa+7Dmoew5jmU5SgbgRWI3kgIBGY01hRhDQRmG6HsyeUIKm1Ycw2BcZEhMBNRNiBcXEDdctAbUHmL0O039wTGGELeJhQIBZP0z9jV0n/A+9uGlA0uP3i1qjyG+/44oohofVVpuvaBZfWs3zIEL5XOEEpjFhMrl6s1oNJKaIa5fkNuPO8xEEqCUCZg5RGU1Vi5JzZnsXN+HppOuBCrvImV+wgkG3JHYmkEVgG/Be4G5qNswMqjhd8rHyc0NB8Aa4DTg4OlqeOHfXnPRaOar3t25diKSTU7tnX4yYmRaW4qYBF1nnBjwugBK8xDdD2+h4bSEps2A5WHCHWhCs+hZjqwGXQrLoQdxKXh1SCnAENjVyv/40/l71hBLc77hxZJBQCz1Mp+VB52p6Pg6hHjY0cWR2p3FpIDfkX8N6oBLkRZrFZIlmTYa2X6tD9MXbR5Z/X1px7fMrM8lXndqqyyKv8GvgLGesbepCrNX7RW7Nh1sM/IX0xaPath0uqq5P7y2bgaRlGMsbVqZZx4Ch51wBbQ9GG0YipRarFMQJmOcEoP7reC/F6VuVgJCQEjmFSAegq+GY9yK8rFSOyruNunNOHKATfgCkMACxGdKv6rx7m5KmuAeg0NRf3baPeTk15o+uby5RtHTGneWzl5YHnHzOJE8KEICzsyyYG728tO7Arlv9dO+vC2uqG7qs8csvtKOlN3ZTqLEWMpIEtQLsomoihIwuZiu4bSnaw5eRn40WEobvxTlNkorxAYEEWyKTqAygiFb6MyAuiD6JcoH6CyEpec3R7DGwW6WTJ/GpjtqkVlLaKl6icoKuuEAa1zDrRU3fuXTTWmcVPNxEyQaO8MEq3jBu+uqh22c8WgZFB03rc2X4HKHUFLVa1VIhIE4Mloy7/MbUBZiWUWyju51Dx3YlHbMAVhDsLomNd/DVcqHNmDkIVY7sKyHo3SZ0N32MxGBqNgRRCeB34So3U+wgyAOBFg5SyUBcAwl5gYkuWH9lDRvqBjd/9FnYoE1qQGlKZLEv0O1NGZuiLcW3lyqAbxwizKcuBxDK85TJ4HftrjXN8BFkUJUQYoRjgB+AEwocfcRzDcjNIXZQ5wNS4MZyUEFqAsA7agbMMViIpw3yI1CBOA65AoDDtZjOFSXOg+jAiwVKryEtniiHX2WlTS5T5gAEJD5lAJKtYdpHNOXwG3iuFFdwrdaqpyM662cdRKcUwsMFMMT+TKAQpqqQV+A1xxhHW7ceW9JC5PKfTOh0W4LT5SiAiXgSkzcdWnodCdWeYWdnv2VuAZhAcQ3StZAvKJAJXRKA/iqlC9fdxngDcQ7kV0o5gIq5sIJypno9zP4RbUm3wO3InR13O42f30QgRAKcrFAhOBMeSX8z9TWIWwCGghsoxeiMhijkM5X+AU4EScCXcC2xU+QlgCbMrDK0xEtu/7AhcA5+D+Hugpe4CVCksRXgQOYWK4kfwf4gc7ygDogwgAAAAASUVORK5CYII=" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">CQ9</span>
                        </div>
                      </div>
                      <div
                        class="DefaultLayout_subListDiv__5oE8l DefaultLayout_notice__5mgP6">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened2__+D8Af DefaultLayout_topFish__sallV"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="SẮP RA MẮT"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAuCAMAAABXqRQxAAACeVBMVEUAAAAZGRlKSko3NzctLS0+Pj43Nzc/Pz9GRkY/Pz89PT1SUlJAQEA/Pz8sLCxAQEAwMDA6OjpBQUEnJyc3Nzc2NjZUVFQ7OzsaGhpVVVUvLy9XV1cnJycoKCg7OzsuLi5UVFQ7OzstLS1CQkIzMzNOTk4kJCRkZGRPT08+Pj40NDRaWlozMzMlJSVISEgpKSk0NDRGRkY/Pz8nJydTU1MnJyc7OzslJSUyMjIsLCxBQUE4ODhTU1MnJydEREQ4ODg1NTUpKSkyMjJFRUVAQEA1NTVjY2NtbW1JSUkbGxsaGhpXV1deXl5JSUkNDQ0oKChHR0cfHx9cXFw8PDxeXl48PDxJSUkYGBhERERNTU1XV1cdHR1EREQ+Pj5FRUVlZWUjIyNTU1MmJiZCQkJOTk4sLCxISEgtLS1aWlpvb29zc3NtbW1xcXFERER7e3t4eHhqampmZmZeXl5XV1dBQUFKSkpcXFxkZGRHR0dgYGBPT099fX13d3ccHByBgYF1dXV6enohISGEhIQmJiYkJCQ+Pj4sLCwpKSl2dnZiYmI1NTWLi4uAgIBpaWk8PDxoaGhMTExUVFRsbGwwMDATExOPj49SUlKIiIg6OjoXFxcuLi6ZmZmXl5eGhoY4ODgyMjIeHh4ZGRkVFRUQEBCDg4NRUVGHh4d/f3+VlZWKioqenp43NzcjIyMNDQ2qqqqOjo6RkZGioqKcnJyysrKnp6ekpKSbm5uTk5ONjY2urq6srKygoKAKCgoHBwe5ubmtra2mpqYFBQUBAQHIyMi/v7+4uLidnZ3b29uwsLCUlJTR0dG7u7u0tLTNzc3CwsK9vb37+/vz8/PDw8PSMtM7AAAAaHRSTlMA8ug4gCYSDQoG9efYwb+rq1s/Jx4a2NjNyrCnp5aVcVpMRS7y7enn5+Xi3NjU0c/Kycm7tLGwoZ2MfXp4d3VtZV9XVVEy+fj27Ozp6OLh39zazMu9ubi3tqKZmJKIh4NsaWhgU01IQFle4gwAAAmpSURBVEjHlZcFk+M2FMddZmZmZmZmZmY2M3Ps2GFm3nCWGe5ut3Blhk9U7bY7bacw13+SiUfwe0/S05MM/UUHvXnjYVcdBe2R7rpp37eP+ffqWw+R0xnlwWOO3QPUmU4vjGffOPCfa485POnJQILMX3zyGfv/O2a/M2645vAywQsqp5z0Tw3OPlmGJTI2mpifmKiv6eq5/zbU/Y+chBHb1nEkxaqEd+Rdf2uxb1IyY4XV+sT8/PLHSzsWv8hU94G2dc6LR/8xpZcSa4vfLe7Y+dHM8q6Vr4cR4or7/oq6mcfjmhn7urZreWl+ob6yMjHrXQlt627hDmhbt/CNmYmFWq32xRf1uVipFDPh1qalPwyXaUuPx7V4vFcaLywsr4wKIyZ3z3b1e/y9248HHBypr9Zru5Z2LYxipdhsLE6S8LkH/Il1AoegOoaH7Z7TM7W4Ofpidrahtu44dnNQx91+qffMUQdtNdznBLWxWqgvrzqmTVkoiuPxuIX2j/wDdTSRQhISYvcGDceJFdZImgRG46xAHHrok3sLcjotE3sfetgR15/AZ8jCeG2VxMOmUxr0huGEkrVxJvlHFB3Wp1k4HKd03bIsndIK4xFmrrT2xcTXhcJcHcxNvV6bWyvFh/HYCKCcBDUecxwqPIybDsXCCNY/fRt1HM9yRZ1CcFwnbZK0dNtZVZhRYWnxo68+3DHz8dLMzMzOmZkd33744Yfzs/W45MTMOJkl44hF2sOhqCbEgw/aXho5k0bCCKZTnN+ZElANJXsFzt4RE3hi+NH8x8sTCwsfL89/5KiCWJ8ZVxol00Yxan7CyeJhijQ5QSK2o/HqtCxRCEZJY9NBnh8zYBLVGkN2wkM+a1RHi7PhLI6She8G0dJHUmYnbZfiFIIgOz/9bCeCAZitpfvq9dvLLKso8ErcCAqCzsDyJ2nS0mZZu1isK63lUQItmHEcmy/4pQ9TmXEmZlIYkkW++vLLzxEExa0wyRD9i35j3cMTioWhUse14en8br4hr4s26eD013LSK+3EkB0/fTrv2OQM7fvlOZ1qaDiKYvTCp99PJEAooShqqwT/2y45gpcTCII3DRYt5jvTPIK2XJwamlJjzTQnCvrw458/myiNk+NxzTJjiGOSWAqxskxhJZvScQYLo5TCE69tsS5KChiGMzk+wsh5o9tU4GJIpIYDlloY1RZiVm3ms8+/XRrXRrVd9ZpGN3qoPOnRKA1nJAtX4AythxMEcehWqkl6aQRDGT/gBsaMgGEY7UCI1bWBiO1acXo1MvbpN998/63jrKzUahM4PXCIJCfwYN0xROdYiuNxHSOIgzcz2RlJXsUwKhGqVPKVQDDQzlfyIUknGyJdx8I6PTBjc7OzscFsAaiewEqoj/4wnGJIy7IpAh7QUZZEBCJ5FmCdliQEOhvGg4FgpxIMBoxK260ylN2D8bC3uBjF6hpFauZabDxWGp+T6AbpZWZhF9FIkjTVtMh5IKAEobwvYF1ByESKxs3gWEoSXN8oR6RyAAUhKFolgRAEELnjzmDgOA3wi6Ukx2SKHK+apG3HHSvCwByKZ4m0dypIky1e8BQM63G7I0tmrjrFLmiVyaFOIhylYTCMmWHNjJtmfKhpJEVGxIYWxiISZeOJFNXraWDScEvii8TFIIvw0XRSRWlkPLk70UhGfXowXaFQLAVne1bYDoOMAChAJEUBV0iJRkAlDgJhcQdNNuIUpWN2kc94xLHQnarLC2UJS9iF8idGU4gGpzs4ySQQc65E2qC/TlE2CZ62/oYxk04l0DA1zBa+/NKkZweDHopjnpr2xbOgV9VKi/NkPEHbI6wVdN0puRdPYM7Sjz98NhOjaMRGwwCn6yBXaqOvPv985xqKodqArn/zaY1ejZX0LNn32GQbuxk6QsgH1GJZRbMJpFQ3MbwxrtO0M6sko3J8Zo4SaQpsORS1GNr8+DtNlZW5VRzRHbL01aKFjxwdscUkJ7rd7EvQYUQnz2eKXh9FGLCcFo5k6ZSFBLtRudrlYw08g+E4juBMZFgvVTutcjDAmmBPa5ZGShqJ45pU7ivp6U7kWuhq2ZjOZTiOkFkESUkRKUUnGKbi9j7/5aPEdFTTRA7FEAQT0UY47zof/rgr3QVLhWFYhM2CRKWLPMey0Y128STocmKs6/Y5mC0KaoZN0SmGVlJRQx/N9Xpkptun6AxwC1XYMJkbi9fmBgPS64hgc4ct8EXYtMCyMBxcN9LHQ3sTgW4gzcFwROL6qqpmBI6BAwSaZYCPSqCJZjnMwikxYontYhgDpYxo8FmM5RRF5FQVTigwrLanDeIRaG8vlDcEDhZZhcHoiEKnVSYdUBMRllUicK6VwDIwIzFcChXacErZKg0lU4xcFGFYlLJMJCLCcr5reIdAF/J+u01kNmERiQESikwxIIubLUWuOkkjQlMQCIJG0+3+5nBYkQt5CSkdwbI0zUiSpIgw0c0b0QuhQ4iWUUmqWzBFYUG5wLDupMJxMOgXIHC8PNZqRnMRlG0TLCjkRNEgMEmGWQUYByjAT07njdx50CFyM9CJCul+ZrMdl+kTvMQ080pChFmE6ERw5rIjT77uuhdUC60adATmWITvwohYBs0BDUwa6OWvdwKAdbww6eZ9gpDTar/fVwWZqHII3MkXUzTDb/AU3v/tsvA+grMbQQUEH/9JlLaIXF8tAhywnymqU+uVsdze0FVgB3Zdr+wBnCwTfDIZ8hk6E5geC1amm6ilbF9LrkVRdb3rhiqfVBldHJvctF7MFItqWpDHNjpGdW/oOb7ldt1ytJn0eJ73ypPR0OOnY4xI+G6uiKPM7dC2LkFRcBZ3gnIKfeDwzmSSB8ktLQjAvtfeyLdDj0E35oJT+VA014o2m+VyM9oKuftBZz7KRhiGziae/tPV6oBTMJxWlASGXXAfdERw0zhBAFCyXK58kjdCl0N3+gGjG8qF/FyrFW3lclVjM9ke+NYpx19y0stnQn/Ru6dcwEj3P3vr5jFxvt8sJz0Aak7mopXdgPU8dFxwqjLt+m4o5Fdz1aofPB/6Dx243zm/X4rPCk42gSaBfT9q7M63/dch6PBKvuuHgkE3BHC+294H2jNd40ej0VYrV/VD1eBG16juB5J0dz2fCwanwMd13fZp0B7quECoCsbhh0JuyJ/uGlvX21d2B3KBLU0F2pdBe6y7x9wQALnAicnOeuWDrcJTwaFojAEZlRP3h/Zc+xpTbjAwBXyY9D/ZHs9tlW6n3e7kK6dC/0u3jQEXgBtGyDv9j7eSm0586OGnbjgb+p86+8S9tvTEOxDQr+UfN4Mjp2AZAAAAAElFTkSuQmCC" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">SẮP RA MẮT</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
                <li><span>|</span></li>
                <li>
                  <a class="DefaultLayout_menuA__Eilgx">ĐỐI KHÁNG</a>
                  <div
                    class="DefaultLayout_menuSubList__mx2Ni"
                    style="">
                    <div class="DefaultLayout_bg_menuShadow__Rjze1"></div>
                    <div class="DefaultLayout_subList__-8hVJ">
                      <div class="DefaultLayout_subListDiv__5oE8l" id="102">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened3__sPxlF DefaultLayout_topChess__pA89V"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="V8"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="{{asset('media/logo_V8.png')}}" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">V8</span>
                        </div>
                      </div>
                      <div class="DefaultLayout_subListDiv__5oE8l" id="1">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened3__sPxlF DefaultLayout_topChess__pA89V"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="3D"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAAtCAMAAAAQuiwzAAABEVBMVEUAAAA5n9g5n9g5n9j/pxr/pxr/pxr/pxo5n9j/pxo5n9g5n9g5n9g5n9g5n9j/pxo5n9g5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9j/pxr/pxo5n9g5n9j/pxo5n9j/pxo5n9j/pxr/pxo5n9j/pxo5n9j/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9j/pxr/pxr/pxr/pxr/pxr/pxo5n9j/pxo5n9j/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxr/pxr/pxo5n9g5n9j/pxr/pxo5n9g5n9g5n9j/pxr/pxr/pxr/pxr/pxo5n9j/pxqnntYWAAAAWXRSTlMAUCP9hvr2FwsFDqKcWWRPBPc/PBAHh0MI8/KAMSQZDdi/rZdqFOfk1MnDkpGNinpXE+3htrSup2hhOZ9/cVJMSUcsKR0L7efez4lzbTjXx7eWeGAaultNHyQiKA0AAANoSURBVFjDjdbXWupAFAXgFYoUUVFKEFBRBGyASMcGtmPvDd7/QU6iQGYNyeC6UpLvZ7OTmdlArhQvHfc0rXdcisfjqTCEnKWMT+Y07XQuZVwsxR9gZK17sjDOiQ5K9NZj5fYIcPXFHPghpNGnzAZh5Dw/ELLDfHogJqnkNxcndJOvisIh8/t/5yP/7HSkZ0ShqeIzMn8ds/SCrY4lErIq/kPmG2En3Q87fuZexddlvhZW6NP5QJn4XZlfj9n3PQYHvsX8LvEemZ/9rf5B0sXV0KV3Q2e+SHwZiBCUghmt4KzjXgSu0ip+H5ib5Df7lBDpKBPfUTXnRObjpu5mPQbKnQjkfXTt8oP4tMS736bqzFdBWXsi3ifzPXknCPkBqb0qfkfNa3Y6C00R2FLxmQqwSXxjmo7ohihsSBe3xItPUcT2+hS1ztVP8hUvbdbEK3RF9Qo+myDeQedcZBS878+8ey+I6fwhKB3ijwKIvTjoxwBckfAEv5IUAG8ZlAV50QbX7fV5AOHa4qqs82nqvQNFp+rbBr/trIeM3WwKfwRKi6pfcuAXTR0h8685me/Qdr8Pyi3xK8yz/vtQrnPgtGm774BSZt6298s/+uvwvxcofv/MEu9HTZnPFez14/Fo0mP+XsXvyPyqW6Wb2ab3P5FV8Im8A899531ujw6MQwWvzzjwXPvDgfSNVqLPxOvE81GYeR/xrCPHz/vxzBJ8W/Tee0T9m3tz4wM0gl6Hm8Ap/6aa3+JvqPpii4qnNNcMiJzxIgr1KSWrOXUaFD6rJ5ejp9JKMu8JABrzwnRMebN/c5Ldw0FTT79HKyt6fSCla60emUeK+YOI/apN62aLnjbq1YGc6jeAkgOf22b/0YXfnHvF3ncrOwOHtLlK5jHvZn97dTSI8Y655KDfXMAIH1YarIT6nPWhn+YJPnDLLC+4GhFnAh+z2sMzfpmHwMqzjZ7/wk94Abkg5Oxa8hs5mEkU+TzxTbY/0xkaNSeefe7PZ54msbUs40mPb0QUFDxcs27JH76f70WvOCsEdKFBV57zwFhYVvEIajW+oTBcX4mVVt0rDAuXnbuNLSM32f2LBKDgOUHXaarxaN212HgYTYPn7ezPzLP7W2zUZyYByqkmxnYuC/tzqzlXb3RPJGgdH9EL/atdXIBT/gP2U0j1J1W0LwAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">3D</span>
                        </div>
                      </div>
                      <div
                        class="DefaultLayout_subListDiv__5oE8l DefaultLayout_notice__5mgP6">
                        <div
                          class="DefaultLayout_txt_maintain__JXkR5 hot_maintain"
                          id="NBBSport_hot_txt_maintain">
                          <p class="DefaultLayout_icon_arrowB__-2KBP"></p>
                        </div>
                        <div
                          class="DefaultLayout_Darkened3__sPxlF DefaultLayout_topChess__pA89V"></div>
                        <div class="DefaultLayout_listLogo__Y5rG1">
                          <div class="DefaultLayout_img_logo__M66hx">
                            <img
                              alt="SẮP RA MẮT"
                              class="DefaultLayout_ic_logo__sbq0A"
                              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADEAAAAsCAYAAADM1FBZAAANnElEQVRogbVZW2wbV3r+zpAzJGdIipR4UXSxI9uyAyPeOFnAjhLUlvMQIHnYIEEfsukWSNAu6qc8NC9JCz/lJYu0CILFogE2DRYogsLbrReI2jSxkwBZQWvYsSLTtmxFN0uWdaFIkRwOOfc5pw/koUcMZTuX/YGDmTNzSP7f/3//5RwSfE+Zm5tT6vX6QUmSuhKJxEa1Wr0WDAbBGEMmk8Ht27fhOA4AoKurC6qq4p133sHnn3+Ovr4+DA0NYWBgAKlUCoQQeJ6HbDaLAwcOQJKkiCRJXYSQDcYYGGNwXReu68KyLBiGAV3XoWkaXnnlFQTvV+kvv/wy7DjOgXA4/ItIJPL87OzsXlVVYZom6vU6GxgYqKbT6d8PDw9/Tin9n3q9Xg8GgwiHwxBFETMzMxgfH0d3dzfS6TQSiQQURYEgCCHP87qj0egTfX19xy3LOmSa5j5ZlhkhJClJ0pgoin9wXffMTrrtCOKDDz4IS5K0P5lMjsiyfCSZTP6kp6dn+Nq1a125XA6WZcFxHJimCV3XyeLiYlcoFPqlKIq/fPzxx68PDAx8xhh7IxQK6bZt49y5c3BdF7FYLBuPx/9BUZS/lmW5EIlEvFgs9pNAIJCdmprC9PQ01tbWYJomotEoMpnMz5977rmfDw4OjgH4WSddSaeH77333t5kMnlKUZRfeJ4X2LdvHyKRCJuamsLKygohhMAwDBiGgXq9jkKhAE3TYBgGBEGAKIro6+vDiRMnVo8dO/aPnuf992OPPfZAKpX6+97e3r9Lp9MDu3fvxt69e6GqKpuensbm5iYBgEAg0KKNZVmoVqtgjGF0dBQvvPCCBmDIMIytu9Lp3XffjUUikU+6urr2OY6DWCyGra0teu3aNcFxHITDYRDSwF4ulwEA6XQagiCgVqtB0zRQSrG5uYmbN2/2j4+Pnz527NiYpmnZ7u7uI67rIhKJeMlkEvPz8+TGjRuC4zgQBAGMsVYcBQIByLIMURRRLBZx9uxZaJoWe/HFF8dd1z3o1zngn7z99tv7JUn6IJlMHrFtG4wxVxAE4cKFC4xSSiil0HUdlmWhVCpB07SWxRhjSCQScF0XtVoNjDHouo719XVsbW0deO211/rn5+fZwMAAdu3ahdnZ2cDS0hJxXbcVuJ7nwfM8uK4LSik8zwOlFNFoFLquY3l5GclkMp1IJPKU0kuWZeGjjz7a5gli2/Z/9vf3HzYMA7Zts2AwyFZXV1Gv1wXHcUApbbl6c3Oz5RFKaWsoioJgMIjV1dXW+lwuB8Mw2FtvveWdP39e+OKLLwRN01qf5RnIP+f3PHP19PRgfX0dY2NjGB4e/tfPPvvs348ePeps88Trr7/+RCKR+CcAgqZp0HUdjDFhcXGRCILQsrimaSiXy7BtuwXIcZzW4JaNRCLQNK1l1Xw+T86dOyesra0RznPP81pXbgQOiFIKANsAEkJQLBbR09Mj7t+//yoh5PrHH3/c8gShlD7JGEO1WkUgEIAkSXRtbU2o1+vMtm3Cv7hSqcC27W0/2q4At2IymcTa2hoYY+DptlarAQA8z2tRwP85/5wQsu1dJBIBIQSXL1/G7t27/+b9998/A8DjIIKCIDxBKRVkWUYymYTrulheXka9XifBYLDFUdM04ThOS3n/1X/Ppbe3F5VKBeFweJvyfE27wn7h3vCD6+rqQqFQYJZlPTc1NRUE4AkAcPz48WgoFHr0gQcewODgIIaGhhAOh4VCoUBs225RiadU27Zb1OFXPvzByeeKokAUxRZ9/DHUHgv+0UkikQgAkEqlwk6ePHkIaBY7QRDC0WhUHBoaQiwWQ1dXFzY3N6njOIJhGIS3E5ZltTjvt6TfojtRo/0znSy/k/jXWZYFSils2/ZSqVQPABIEQFZXV0EI6Tl48CBkWUYwGEQulyOmaRLDMBAOh1uZxnXdbV/OM4j/h9ppwJ/51+0EoP25f+5PHJlMJijLsgVAEACgUqkwQogaCoVgGAaKxSIopUilUrAsC7quw3GcVj3glOlEDz+ATh7YSfFOw08xTmEAEAQBpmniySefHOGe4MFaqtfrmVqthlqtBkVREIlEWunPr0Q7Hb4PLdrnO73jDHAcp1WXmlWfzczMFDgIVq1W3XK5bObzed7QgVJKgsGgByDQiR7fBUCntfdzTykFL7Lt32MYBvL5vA1A4CmWqqr65eLi4mFFUXgGIpIkCfF4HKqq/iCFd3p3L0/weuQXPk+n07VTp05dBO5UbMkwDCOVSv2toiitRk7XdTcQCATy+fxdFe4075Sh7gbAHwee523zgH+d67ro7+9HNpudXFhY+KhYLJa4J+zp6emVlZWVxb6+vj28yVMURQyHw0wURcKDqpOi9wPmbtb3Xzspz4UnklgsxjRNm75x40YZvNgBsAFoGxsbf5ibm4Ou662A9jyPDg4O7liZ263YqRXh9/4eqf2d67qwbXtbRe/kIUmSMDQ0ZOVyuS8AWAAYB+EBqI+Njf0xn89rgcCdDn3Xrl2CKIpMkqRvAWhPrZ2eccU7KcRpw/M/90AnAzmOA8/zEI/Hkclk1j799NMrTeMz/36CAAhlMhkSj8dHZFluPY/FYszzPFIoFHakx065fqd33PrtjWMnyvEiK0kSRkdHcfHixX9eWlqaBqACoH4QFICwsLBQ6O3tHe3r60vyF5IkEV3XPVmWhWKxeE/FOxUs/9WvfLu0P+N9GCEEe/bscXfv3n3+ww8//B2AdQA6AAi+9RSABqB45syZV3O5nCOKYsu9e/bsCViW5QwODn6LJu0Uah/ckpw6fgB3A8/XM8bQ09OD4eHh6rlz534LoAhAf/PNN1k7CKARKJuMsc0rV66cmpycvIOQUoyMjIgAWDQa3cbrToq3d7Lte46d6AagFeS8TwqFQnj44Yc9VVXHpqamrgIoAbB5HxfYjgEMgAuAFgqFuqZpV2RZPtHb2xvkrUY0GmX1ep34N0vtQHgqvBvX/cq304dbHwASiQQeffRROI5zemJi4veapi0AKL/xxhseYwzj4+PfAsFp5QCglUrFyuVyn4ii+Fg2m+0OBoOIRCLE8zxP0zRBVdW7bojaFb/XO/8hAQBEo1E8/fTTnmVZfzp9+vRvNE27CWATgDUyMgLGGCYmJjqCABop12qCCaysrFxyHOfBWCzWl0wmEY/HBdd1LUEQGKVUME2zdX51Pz1ROxCeQv17le7ubhw+fBiapn08Pj7+u6YH1gDUX331VcrXnT9/fkcQQINWBgDTdV26vLw8aZqmWqvVfppKpUg2mw0qiiJsbW0BADiQeyneKQ543HCJx+Ps6NGjbqVS+b+zZ8++Xy6X5wGsAlBPnjzp+T1+4cKFu4IAGh4x0fAKNjY2Vmu12pyu66PZbJaEQiGiKArL5/Nmd3d30DRN6rqu0AlMJ/4zxrZVaQDIZDJ46KGHNm/fvv3hxMTEacuyltHwgPryyy+7/paEUopLly7dEwTQiBELDa941Wq1sri4OLa2tjYoiuJgJpMhe/fuFcvlMimVSoRSSu4V0Fx4FeYSiURw5MgRfPPNN/82OTn5sed5t9HwQOWll15qAeDxBwBff/31fYFoB+IACJTL5alqtVoxTfNQOp0ONg9/XUppQFVVm7E73UA7CF4D/H1SPB7H4cOH3a2trU8uXLjwHwBW0PBA9fnnn/c61RYAuHz58n2DABrp10GjSupoeOV2qVS6ODc3d7yrq0tSFCUgyzJisRhs24au6x4Aod0rHAC3qKIo7OjRo2Rzc/PPX3311a9d111EoyLXnn32WeqnY3t9uXLlyncCwcVFI050AI5lWZamaZ9qmpZgjO2RZZkQQoRoNEqCwSApl8uUENKKE38QM8YQDodx6NAhUi6Xr+ZyuV/X6/WZpgdqo6OjtN0D7QVzenr6e4EAGvSym0AsAETTtOlarVYrlUo/TSQSsG0bkiSRoaEhrK+vM8YYc12XtJ+WHDp0CPl8Pnf16tVfNQGsAqiOjIx4/vrTfgDBwczMzHxvEMCd6m40BzUMY8V13al6vf5UPB4PGIaBUqlEBgcHsbq6ygghgv/oJhqN4sEHH9yYnJz8lWEY1wHcBlB+5JFH3E77ik5gZmdnfxAIAMDw8LBXKpXMJhDPtm3dtu2pcrn8lCzLQcdxoKoqGRkZIcVikTmOQ1zXRSqVQn9/v5fL5f5FVdXzAG6h0RO5yWSypXinM1t/dlpYWPjhIHp6ehCJRJimaXYTiOO6rhUIBJZM03yKn6jPz8+TI0eOsPX1dSqKonDgwAH9+vXrfywUCv/VBFAcGBiwk8lkS+GdWho/mKWlpR8HhOM4yGazrFQqOWgEvWvbtkYIUQAc5C3F7OwseeaZZ8itW7dIqVT6Uz6f/y1jjPdDdjgc/hZt2vci7WBu3br144EQRRGxWAyqqnpobhsdx1kE8FeU0gClNEQIwY0bN8iJEyes2dnZ3+i6/jWam5tYLMZ22rdz8XfHnGarq6s/LghKKRKJBFRVddEI+qDjOBOU0pzneX9Go4DdqlarVwgh/9vsSquyLFMe7O379U508oPZ2Njo/O/pjyQBAEkAg82rhMYpPEFjB3kTwAaafdkPkb8kCAAQASgAZACh5giikQCKaIDpfMj0HeQvDYL/hoCGZwLNe14svbt87r7l/wF305ZWh/kZzgAAAABJRU5ErkJggg==" />
                          </div>
                          <span class="DefaultLayout_listName__UCMW2">SẮP RA MẮT</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
                <li><span>|</span></li>
                <li>
                  <a class="DefaultLayout_menuA_colorO__gijt0">ƯU ĐÃI</a>
                </li>
                <li><span>|</span></li>
                <li>
                  <a class="DefaultLayout_menuA__Eilgx">
                    <div class="DefaultLayout_icon_phone__9PIKL"></div>
                    TẢI APP
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="DefaultLayout_mainCfArea__1lyGs">
        <div class="DefaultLayout_mainCfArea__1lyGs">
          <div class="DefaultLayout_DB_tab25__gcc6Z">
            <ul class="DefaultLayout_DB_bgSet__kL1Yj slider_dev">
              <li
                style="
                    background-image: url('{{ asset('media/0cee901428004bd0aed878eabdf524f6.jpg') }}');
                    display: none;">
              </li>
              <li
                style="
                   background-image: url('{{ asset('media/17646de5cb8e42dabefc54a7068bba62.jpg') }}');
                    display: none;">></li>
              <li
                style="
                   background-image: url('{{ asset('media/4bc0457503eb482c88b1e39fedf0c049.jpg') }}');
                    display: none;">></li>
              <li
                style="
                   background-image: url('{{ asset('media/17646de5cb8e42dabefc54a7068bba62.jpg') }}');
                    display: none;">></li>
              <li
                style="
                   background-image: url('{{ asset('media/4bc0457503eb482c88b1e39fedf0c049.jpg') }}');
                    display: none;">></li>
              <li style="
                background-image: url('{{ asset('media/56e743190c884eb494e1685cccce15fe.d4435fe9c079d7625637.jpg') }}');
                display: list-item;"></li>
              <li style="
                background-image: url('{{ asset('media/56e743190c884eb494e1685cccce15fe.d4435fe9c079d7625637.jpg') }}');
                display: list-item;"></li>

              <li
                style="
                    background-image: url('{{ asset('media/0cee901428004bd0aed878eabdf524f6.jpg') }}');
                    display: none;">
              </li>
              <li style="
                background-image: url('{{ asset('media/56e743190c884eb494e1685cccce15fe.d4435fe9c079d7625637.jpg') }}');
                display: list-item;"></li>
            </ul>
            <ul class="DB_imgSet" style="position: relative">
              <li style="position: absolute; display: none"></li>
              <li style="position: absolute; display: none"></li>
              <li style="position: absolute; display: none"></li>
              <li style="position: absolute; display: none"></li>
              <li style="position: absolute; display: none"></li>
              <li style="position: absolute; display: none"></li>
              <li style="position: absolute; display: list-item"></li>
              <li style="position: absolute; display: none"></li>
              <li style="position: absolute; display: none"></li>
            </ul>
            <div class="DefaultLayout_DB_menuWrap__49KBd">
              <ul class="DefaultLayout_DB_menuSet__kOozj">
                <li class="">
                  <img
                    id="0"
                    src="/Images/b1afd2ebd48d40289fb6307e1ee47796.jpg"
                    alt="" />
                </li>
                <li class="">
                  <img
                    id="1"
                    src="/Images/b1af741df1a94214a0ea3caf6d378770.jpg"
                    alt="" />
                </li>
                <li class="">
                  <img
                    id="2"
                    src="/Images/0b146edf4ba1445e8f3f11238d95050b.jpg"
                    alt="" />
                </li>
                <li class="">
                  <img
                    id="3"
                    src="/Images/25139543156a404aa98ddceb3a978f25.jpg"
                    alt="" />
                </li>
                <li class="">
                  <img
                    id="4"
                    src="/Images/8e0813cccb9c4fe681ae847694efcd37.jpg"
                    alt="" />
                </li>
                <li class="">
                  <img
                    id="5"
                    src="/Images/dadb9eb6e64c477fb4dfdaf881a3a768.jpg"
                    alt="" />
                </li>
                <li class="DefaultLayout_select__Xav17">
                  <img
                    id="6"
                    src="/Images/c26c500b571647c6bdc144b43f6ce6fd.jpg"
                    alt="" />
                </li>
                <li class="">
                  <img
                    id="7"
                    src="/Images/b8edd30b0d30441fa26e98daa61aa303.jpg"
                    alt="" />
                </li>
                <li class="">
                  <img
                    id="8"
                    src="/Images/2275315f45684891b9dbdad99a8fdf48.jpg"
                    alt="" />
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="DefaultLayout_runMsgArea__Ec3c4">
          <div class="DefaultLayout_runMsg__UEtgO">
            <div class="DefaultLayout_runMsgTitle__0mtY8">
              <div class="DefaultLayout_icon_runMsg__rXDw0"></div>
              <span><a class="" style="cursor: pointer">Thông báo</a></span>|
            </div>
            <div
              id="marqueeBar"
              class="DefaultLayout_marquee__ZMSzX"
              marquee=""
              style="visibility: visible">
              <div
                class="js-marquee-wrapper"
                style="
                    width: 100000px;
                    margin-left: 588px;
                    animation: 40.9541s linear 1s infinite normal none running
                      marqueeAnimation-4240482;
                  ">
                <div
                  class="js-marquee"
                  style="margin-right: 0px; float: left">
                  <span
                    class="DefaultLayout_first-span__ROGR+ ng-binding DefaultLayout_ng-scope__Sw0v5"><strong>Link chính duy nhất:
                      <a href="https://hfwm836.net/Home/Index"><span style="color: rgb(255, 165, 0)">HFWM836.NET</span></a>, đề nghị không truy cập vào bất kỳ link nào khác và
                      thường xuyên thay đổi mật khẩu để đảm bảo an toàn tài
                      khoản, cám ơn quý khách!</strong></span>
                </div>
                <style>
                  @-webkit-keyframes marqueeAnimation-4240482 {
                    100% {
                      margin-left: -1157px;
                    }
                  }
                </style>
              </div>
            </div>
            <div class="DefaultLayout_jackpotAll__y2cvf">
              <div class="DefaultLayout_jackpotBox__fECFC">
                <div class="DefaultLayout_jackpotBAC__wRpTf">
                  <img
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAAArCAMAAABMzFZvAAABR1BMVEUAAAAyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccoyccr8/P4yccq5yukyccr19/wyccoyccoyccoyccrF0u3o7fgyccoyccoyccr7/P7y9fsyccrv8/rY4fPV3/Iyccrc5PT4+v3v8/qjueN/oNrQ2/AyccrJ1e7n7PfN2O+tweZah9Hg5/Xa4vPQ2/B2mdeyxOejuePt8fnT3fHi6fbAzut6nNlfi9Lq7vietuLL1+/W3/KXseCIptyOqt5nkNT2+Pzr7/iww+e6yuqDotu8zOrD0ey0xuiMqN3g5/XP2vC8zOqZsuDp7vjq7/ioveWSrt7D0excidKdteLj6fbG0+3b4/SRrN5tlNVxl9b8/f67y+mkuuP///8ASRuEAAAAbHRSTlMABgoYLhSAJhANGz02KkkyInFDQEYfV005X/Rbs2nud1R0bbvdemZQ999S5cyjYsfp0pl8xH22y6+qiNWzqpGBcda/vY2GdcehmYuEa2Jg7NmllXSvpZ2ZlpN1VtuzkIuJfnrRoJyQVU/zsUs0C68pAAAHqElEQVRYw6VX91fbMBBuYsdO4r2TuM6EhIQSoEBLoYzuvffe+/7/n/ud7MQtHaGv9+BZutPpk063cuT3VMD/TMn/U6FYqVSKhT9IipD8RRXifwAqS9VqqVL8RVKslKSqVP7zXlhQguJhsYqlqiobNu9YwF9BoIP4BIEhqzgEJoIBcXY6QdC0VciLh0SqVI3HRBY0SpIklcowSKVcwggnsIiuyiqY5TKkINwAJMRg2PKzDy8s+7BQZVv/QOTqhqoasqwGEkxm80iVdZfoil8z7CAIWCgbEAOBJ7xc91fonC9XK4dDKqnaEtHArek11zQ9XcY2Ndd3tZrmj4gexAPPkmVLc33TdDWLEXjiQR7Vb9FyqNnlwqEcomS4O0TxwLxxiYiGe6bnmUsNotW9qF0n+tq6uELDzybR5jKY+66muftY2VgahWNiemKUCofyPEk2gTSOb66QoLU4PpmO3sYJ0VFlkVauj0LszbzGvXa4l4qHSeewSICBnwZ6BKRkvEONXeUy0X3nONEJ5xouUHeANEeNa2FYB8jlDUiWuxcbtHihcwKLNpQmHev76mzrcSSplh9uEnWTxFF6vQW+xDo1nKR+aek6IzXBSeK4T7Q+P99apgXlFNFxx3F4CKTl2LMrM69UkVRLM+ME5+s4nW0CMdIczTlJPIjaQGI61q3X2Y5A6hEp+O8ACUpbjBRqwWykkv2U6G5nY52o1TmLLXu7KdIikEaDFGkOTzce/y+S+gw7KVtNmMtp0raiPJpYrzs+fW6v3gU679bvA3N9Y6N1NrfeO2p2WpC1NfswSFrmcLf7/SE1t7bmgNTCu5911hrUiPuYspesCTc7heGPHrHZT4Z0sq3N9ohC2a5dIUHwrh1KaXM8zrx8qR0icpP+GTrJSAsTL7+bis+0R21e+VgtzfY9yfDO34LOnu95/hJC5OVJWjXNiCN3+Np3XURLFOExX7K/r8Pxb+SR6yNL7A+RGWfnCFyqamh+FPk1keU8kW90pB5kI9+rWTKGMkh3230OtHH0QzaCDivplipVCn+JWJDI2VWVE6dd5bQqhmpQrQYi19oYpaRaLtsxNvU8w7IOK9kB6s1fS18Q8EYSKC8V6biCUUkMJiQhvJHVXcvOqwbEQom/hT/Gqw37aCDdQgWcrixkJIb5AP9FKa1UgTh9Js+VUt6v02JJ1f1RXK/HcThwdWHlWVRB9TXUKoBmNQrlvNoXyoG+ShPauampM0rm7I4itxbKPZ4Py7Jwdc/QlBrX9aAsLJR3CZgdmOBBQEVBua0xBGW6IJFGX3ybVPuCJEe3KaczviHBB/jM6ZMV+AIST9K2Je8fxKrqQf8pT7gcMq9X6IaO+EqRrPZzTjLK/IZyDFA3dVuSbAORw30QQKUg83yeQCImABYhYVl5q8GRACe2U65tG1qbiO6ZslRM84IezjHSvNNSFEiua4ZqoIVAAGuyXQVOGsI1TKo24tnk7gLAgWpxmJuuznEODW4rOMw96GKJrg0SIroQ1oJK4SDSFt/JsyztyZDfbMesyYbl7Z/GZGUJO8q6f55T2+pr7lpqN1hAJ/d8ZCSiW9dW4Pqev3eJuaevR4P3PABPLedIwnrK1jahZvqad45SGo5cz7ySTVZ9zx1MJEuepu03ssndwSBExm3iPJ+iyfLG2vjBb5Cm1LwQm+4e0eIW1x16GIfX8LnjrA2x+4DrfvNj9yUgnvrRqjjgIhaPUYMB9SqMzJuoLo+U3QVUGvQH4O7WURp/g9Sbrw+iS1x7xKPd7ybLqHlOPz6PA4f9JlC79RBWe2HuAwKregB3RL1aTwa+v4QvuNjymNNRxDtZ1R88IqfFJEQVxwa9ReIK3lrA5v0Rl5EofgXWm3rkeiCznbSUR711NkSrM8+VsQ7Dt5MN5VRvm4DUceYZaSCn9Sp/p9a8cgrbnuiPuyfwBQk2oXjHrm7paFGPY9JtexYmblT/uD0x+bxAOt7WdC+8s5hxgdTifhFdGQPlSK2us8Gm2Hacs4RPb/cAkvcTkhmi3tNC7yhbb6PFSGuRrrt32S69y8J63Q5zzT8hzbXeUPZOzN7IrTeoT63nmqP62eydciRT183hD+/UdZg7yCI3zxGdlnK5iXUdPvmuoog7tZxl1hmHN7ldTiC/D4+AezT6zyHAnseE9VqcDXwgsRK4TQi7/W4D79TWq8XCr3kPpupfJN5jl+19Ihlf44+TnEFAteNNQBzvriFEd/q408IjXAkfp9vl7AKz+kMRIfyC7/rx+BYCJXyGnP1rLqfNcAQnFrSASA8Ho/eZZOWGb46yyAVqeK8xWUUX63Ui5FLDqJ2f6g6hi+WiWSr+Up9u3zXR4eBXDIYPHxJ9+VzT3Cwb+TXLqmXZ6Ar/1nnLw82LHNNRhOEzIwjQXGF+a5Pt8lTzPp1jJLtcPFhzR6Ymq8jFGidYkSa59UkzLCRBYHMm5XRrGYYMPi+DSMcZauIHa9XQM10XOdNAutVEGT/QR6DPQm1ANbCNtN/KWp+0SYKkUppUjaqU8YXIDoK0KULzI3SzNdxgqTa6gAO9UQB1/sU+KWvThmdS/NJKOOVPV5XKgrIFuS6oBMq7AGBNqHCgVBd+W91zPsY5HZkyc+Wp4DscpiAbGKDVqAAAAABJRU5ErkJggg==" />
                  <div
                    id="jackpotNum01"
                    class="DefaultLayout_jackpotNum__1J1ph">
                    <span class="DefaultLayout_jackpotN1__NSEOu"></span><span class="DefaultLayout_jackpotD__CDqz2"></span><span class="DefaultLayout_jackpotN3__zijlf"></span><span class="DefaultLayout_jackpotN5__AsPob"></span><span class="DefaultLayout_jackpotN1__NSEOu"></span><span class="DefaultLayout_jackpotD__CDqz2"></span><span class="DefaultLayout_jackpotN8__fTufp"></span><span class="DefaultLayout_jackpotN6__JenPd"></span><span class="DefaultLayout_jackpotN3__zijlf"></span><span class="DefaultLayout_jackpotP__wRz9n"></span><span class="DefaultLayout_jackpotN4__9Iw1Z"></span>
                  </div>
                </div>
                <div class="DefaultLayout_jackpotCD__MSMaR">
                  <img
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGkAAAArCAMAAABMzFZvAAABUFBMVEUAAADKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjL89fXKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjLKMjL+/PzpubnKMjLKMjL9+vrKMjLKMjLKMjLKMjLy1dXtxcXKMjLw0NDKMjLuycn78fH03d3KMjL9+Pj24eHKMjL78PDKMjL89vb46Ojx1NTXdnbTX1/35+frvb3w0NDinp7RWlrnr6/ciorz2trvzMzjo6PZfX3joqLbhIT89fX46urswsLuyMj13t7Va2v57u7z2trmra3ej4/swMDgmJjagID67u756+v24+PvzMzw0NDlqanYenr03NzpuLjswsLUZWXejo7gmJjafn7rwcHpt7fWcHDek5PosbH46ur35+fRWlrkqan///+GwTpKAAAAb3RSTlMABQ0HJRMWCj4ZHIAiMB8tRjruQysoSRFwZGA3MlZTS1009LNbWfdoQWtypLtQxHu24sV16dNN0Xjt3b2Rdsytq6GIhWnLsJh/c3Lcx6adl1jms6qTjIN65dm8mJKOhoR5bmRjVj+nmlCKYbKih0fu2eIZAAAICElEQVRYw6VXZ5vTMAwm20kzmzRpdlvSdddSoNxx7HXsvffeU///G1JSKNBC73nQl6q2nNeWJb3yrqXCcdyu1TP/L5zC87wicIsTgjKfWL4PAae5nQMFsqZKvLAwI/CSqsqBwv19i5Ik8cpOoQRJEy1PV3mBEwTaYbVZ/MerpmeJmowzNEAyn6bzSJreEDVpp1C85l0HSHCFJKsyblFR+ECWZUnWGgnAc0NUpSAIJFlWy2lBwKPQvKTqxpvrnw1dEnbmPF5vI5Lb9kTRs6yGqcoybhW1hhW7AI9tx9NN0xQblmF4ookIsomWDTSP7QPwyDY0ntsRktRg6wBjN247ru8PYoQwHNd2mcPsDOBqMWZtw0hwyPddltCG2sy1B47D8tYh2J8yPdghkueeBCjG/usrALDvjD8Y+OsdgIMvNrMIYPf02AG4/MEHOLkfBy+6DnMvomVnPUsjIHnS2In7OE5RDR+RwuLVASjlflEcr7SLrSEi1W7Cge1xCtCjsc6lND1TTe8brlVI3mokji7XjHNE6ocnoXe0dgrgRPM8wN7mPTxA1ESkw9C71+1GiHRqgjP7h8d6sO/ZdC8a1Wp1OBva4mrvKbysiYbdPQcw7A/XaqNRjw6xB3prw+jK+jYh1XGk3ypCgD2TyfQs9Gq3Ac4315r7UUWk/QXTeW5l2Kmiwfyij/tba043AIWQDsPhtX4xxmuq3HN2GEV9nJhMtkYAtRFZN9dw0WlC6jKTX52z+kuA91M8BEynR/CTo6MV0oO1fms8TkukwwAXwnBYIk2XIKXOTpAab/BLtdN1dFezDhu12p259249OkPeO0tfC/uo7alNto7MvbcB9ekWIZH3ViKJbBZwD/vhPqifPn0Ykbbw3o80L3Sg0woJ+BTGYxlmt1H9NSLOhf19cDxlqyOCC/T4cYV0L01Plgqtj2ZRjhmDmdsPD8Lx/vSXKL9bTR9Ms5Qsr4sroxxzyRvcPYQnOmMzZq9jijw9Dgd9f5My9/Jd23UxW/L8BcBTivc9+PXX88y1mcMuXsbKqAfCyovC6urYm5u2U1a5QVlvYsPAumTbLE4syygldrOQEi3aZEljVo2obIkNI46xAq+4J67MW1W0kraBdVWlspokVERNs6y1uqnNRExc8mOUMaOhaxpNG5Zoaiqqor6CNpB9AqSxALlBJ2s5INXURd1EbihZIeB/iCy2bYBrqc8SPIheikn7MFFU6d9HIppDBBVZR294DV0NFEEJaMwkFYWbi4JQyB/j3HYHjDnoAwTSxYbnNZBG+H/eEi1OGIstURcNhzlIZwqRLPqFSHShmMh6282zomi1WkU381nbsvA2GaNbWoHEm88B4JbPnEF+ELVPeK2KpL/tYCyhuugBj40PwEyOnMl891MHHm3f6BzEPa5Aiq9QHrW6rauUOonGCxXPv2zMkLjKh5WKqZdhPvzECosrlfZFRPeVwv0FSWtv4/5vTiZfMSMP5YaKF9/AI71gFrE1ulKqGofqC4oWp3WYy97hvk709BEceIMtDVlSE7XUjYps5UgWMKqdBUxM21MlirCsm9lt9IfCU8dkGOWtcSWSUxCB1GrT6e6bAHC02Q+jVuYmDV0XPQPTA6NK4JZWItZ6ANAbAVA9FlVNjO00ClvZwMC2hPgEE9lmhi6TM3l9EJZIa2HYPI3ani2EQqS25yXYgGzmruNpgfCXQ32EUnrHbMvUGs7mSbqJk9sDQxQt5waVJFj/kFCXxQWiPSyRwmxcNEfo99oWWj92Y6wgpeW+ay75fWn3xaI9QHK7G+sItP0jtrAKOu7FTqnjRXiqwmFfkzdLpCh38wjJBYhw4ZrtxB8uQyW3BqLELTuU2u6SMWxsjQ1dT/J9qB5rIhvApSx7dYioY3gciyrtVJCNdZjJS7f7jC6qRBoPButEYsSmcMNQlRVIieixawB1dP0QoTaGw3eAxIsNE85/U/9AGqQXfiC96/p+h8iXqAsuOZqyNKNYNJp5z7HaOW5/T7/ohuSZyWSD/qU+Fp8EE2buva0ua7M50glsAlrN2umy14H7zOSXRwQuIKkf89kge4jros28e6z8ymFMmciPjSSxKPh+RsRaxmK3NbsnWpF2j1W3TUiuzv81ymFEGV/kefEXpLZBZ/oZ5dOubWdDir0KKWxhW4DnH5H3LhDSYo1IxlXmUvN1vpVGG3Pv9SrvDVN7MGBxWZ0U9DUhTcJutz+hfKqQ+tF7oJa0ViGJi0iBOLiErq3Xakfpp99qXZ1HxP4+RUQdIyLFCL5uBhxVo24Z5VvN5ik8MDxrbpVnis6VX6ntJu8tQRJkzz5Oh8HTU1yfK9LWoR9R3plF+UZzeBL/vSUkQU2yOszlCDabdeLh4j2UDVSP6jVb9J6iWnepDKF//C45ejvfvDTL3M4Z25lnLryg9xFtzf+llt/KfD87QPm0meJyEoS6G5uLSDIxUecGtioW20a7y0RU67Ro/TWzsBqxWTV6HYuywlEEOb/wk+8kbeoVnzCH3bhFe/54hJJ8MXOFwLQcyhVVVsU2Q9KlRsdxqaaWD1EVKdku/xGpViTt+Gkx41wL6b2RxDEtI8M8z6kam5KwGHuSKdJrmFd4GZsHsXx0il7JEzI/Z42ffYKADG8RoTtxggQhIX2ZOnY6s2Vo6i1/XGN7Ur3wueqtH9DXg4r7yHzOhNXiakDTqCVScVDgBLSnVUppiKaV7aJUL/3fVI6UavB3dp83iKX8oPxSyvFK6N9P+Q6+tBrSjsAlxAAAAABJRU5ErkJggg==" />
                  <div
                    id="jackpotNum02"
                    class="DefaultLayout_jackpotNum__1J1ph">
                    <span class="DefaultLayout_jackpotN2__R8ZkO"></span><span class="DefaultLayout_jackpotD__CDqz2"></span><span class="DefaultLayout_jackpotN0__QrxD2"></span><span class="DefaultLayout_jackpotN9__oG2ij"></span><span class="DefaultLayout_jackpotN6__JenPd"></span><span class="DefaultLayout_jackpotD__CDqz2"></span><span class="DefaultLayout_jackpotN9__oG2ij"></span><span class="DefaultLayout_jackpotN3__zijlf"></span><span class="DefaultLayout_jackpotN1__NSEOu"></span><span class="DefaultLayout_jackpotP__wRz9n"></span><span class="DefaultLayout_jackpotN7__ejLjV"></span>
                  </div>
                </div>
              </div>
              <div
                class="DefaultLayout_btn_jackpot__+emlP"
                id="btn_jackpotBAC"
                ng-if="ctrl.model.SuperRewardSetting.IsShowBaccarat &amp;&amp; ctrl.model.SuperRewardSetting.IsShowBaccaratMarquee"
                open-window="/Event/SuperReward?inPage=01"
                op-title="Ưu Đãi"
                op-height="600"
                op-scroll="true"
                op-width="800"
                style="display: none">
                Danh sách
              </div>
              <div
                class="DefaultLayout_btn_jackpot__+emlP"
                id="btn_jackpotCD"
                ng-if="ctrl.model.SuperRewardSetting.IsShowColorPlate &amp;&amp; ctrl.model.SuperRewardSetting.IsShowColorPlateMarquee"
                open-window="/Event/SuperReward?inPage=02"
                op-title="Ưu Đãi"
                op-height="600"
                op-scroll="true"
                op-width="800"
                ng-style="{'display': ctrl.jackpotOne ? 'flex' : 'none'}"
                style="display: flex">
                Danh sách
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="mainArea">
        <div id="indexMenu">
          <div
            class="DefaultLayout_mainArea__nhTpc"
            ng-controller="HomeIndexCtrl as ctrl">
            <div class="Animation_gameType__Jf-hm">
              <div
                class="Animation_gameTypeList__cv8Jm Animation_liveGame__hDHwZ"
                target="_blank">
                <div class="Animation_exterior__fHRtN">
                  <div class="Animation_icon_liveGame__mnoj5"></div>
                  <h5>Quay thưởng tuần trăm triệu</h5>
                </div>
                <div class="Animation_in__e9CWZ">
                  <div class="Animation_liveGame_in__QjAeU">
                    <div class="Animation_LG01_people__WeW-6"></div>
                    <span class="Animation_LG_week01__NWCLp"></span><span class="Animation_LG_week02__JAC3f"></span>
                    <div class="Animation_btn_LGweek__6LtMf"></div>
                  </div>
                </div>
              </div>
              <div
                class="Animation_gameTypeList__cv8Jm Animation_sportsLive__+9l29">
                <div
                  target="SM"
                  checkblacklist="SM"
                  is-game-maintain="false"
                  maintain-msg="COOL-IN LIVE đang bảo trì."
                  checkblacklist-by-func="ctrl.CheckBlackList($event, 'SM')"
                  style="text-decoration: none">
                  <div class="Animation_exterior__fHRtN">
                    <div class="Animation_icon_sportsLive__0bDdT"></div>
                    <h5>COOL-IN LIVE</h5>
                  </div>
                  <div class="Animation_in__e9CWZ">
                    <div class="Animation_sportsLive_in__descd">
                      <div class="Animation_SL01__BC8id">
                        <div class="SL_bg"></div>
                      </div>
                      <span class="Animation_SL_text01__2K2Cy">Sự kiện</span><span class="Animation_SL_text02__Zf-Fw">thể thao đặc sắc</span><span class="Animation_SL_text03__ktaZ0">MC nữ gợi cảm</span>
                      <div class="Animation_btn_SL_playGame__-744v">
                        Vào xem
                      </div>
                    </div>
                  </div>
                  <div
                    class="DefaultLayout_txt_maintain__JXkR5 game_maintain">
                    <p class="DefaultLayout_icon_arrowB__-2KBP">
                      Bạn không có quyền hạn vào《COOL-IN LIVE》!
                    </p>
                  </div>
                </div>
              </div>
              <div
                class="Animation_gameTypeList__cv8Jm Animation_liveGame__hDHwZ">
                <div class="Animation_exterior__fHRtN">
                  <div class="Animation_icon_CAO__dFJvZ"></div>
                  <h5>Đối tác LaLiga</h5>
                </div>
                <div class="Animation_in__e9CWZ">
                  <div class="Animation_liveGame_in__QjAeU">
                    <div class="Animation_LG01_CAO__tDGZ4"></div>
                    <span class="Animation_LG_text01__77f7l">SPAIN PRIMERA LALIGA</span><span class="Animation_LG_text02__BnZZS">TOP 5 GIẢI ĐẤU HÀNG ĐẦU CHÂU ÂU<br />ĐỐI TÁC CHÍNH THỨC
                      DUY NHẤT TẠI CHÂU Á</span>
                    <div class="Animation_btn_LG_playGame__wiJK7">
                      Vào xem
                    </div>
                  </div>
                </div>
              </div>
              <div
                class="Animation_gameTypeList__cv8Jm Animation_freeMovie__Rr65C">
                <a
                  widow-open-with-check-registered-status="/CheckVideoForum/0"
                  balance-check="Sau khi nạp tiền mới có thể xem, cảm ơn."
                  check-mem-stat-zero="true"
                  target="_blank"
                  style="text-decoration: none">
                  <div class="Animation_exterior__fHRtN">
                    <div class="Animation_icon_freeMovie__vRkyj"></div>
                    <h5>Phim Ảnh</h5>
                  </div>
                  <div class="Animation_in__e9CWZ">
                    <div class="Animation_freeMovie_in__5MAev">
                      <div class="Animation_FM02_blurry__oAuON"></div>
                      <span class="Animation_FM_text01__wVO6d">Phim Ảnh</span><span class="Animation_FM_text02__zIWJa">Xem mọi lúc
                      </span>
                      <div class="Animation_btn_FM_playGame__Yb-Xs">
                        Vào xem
                      </div>
                    </div>
                  </div>
                  <div
                    class="DefaultLayout_txt_maintain__JXkR5 game_maintain">
                    <p class="DefaultLayout_icon_arrowB__-2KBP">
                      Bạn không có quyền hạn vào, vui lòng chọn hạng mục khác,
                      cám ơn !
                    </p>
                  </div>
                </a>
              </div>
              <div
                class="Animation_gameTypeList__cv8Jm Animation_outtake__RqR6H">
                <div
                  open-window="/Home/OutTake"
                  target-name="Hậu trường hoạt động"
                  op-width="800"
                  op-height="600"
                  op-scroll="true"
                  target="_blank"
                  style="text-decoration: none">
                  <div class="Animation_exterior__fHRtN">
                    <div class="Animation_icon_outtake__ROoHb"></div>
                    <h5>Hậu trường hoạt động</h5>
                  </div>
                  <div class="Animation_in__e9CWZ">
                    <div class="Animation_outtake_in__c-JPb">
                      <div class="Animation_outtake_people__v86Ez"></div>
                      <span class="Animation_outtake_text__wWFgy">Hậu trường hoạt động</span>
                      <div class="Animation_btn_outtake__2E+ic">Vào xem</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="DefaultLayout_btmMenu__uab-k">
        <div class="DefaultLayout_btmMenuM__WZrr1">
          <ul>
            <li><a>Giới thiệu</a></li>
            <li>|</li>
            <li>
              <a>Trợ giúp</a>
            </li>
            <li>|</li>
            <li><a open-window="/Home/GameTerms">Điều khoản</a></li>
            <li>|</li>
            <li>
              <a

                target="_blank"
                style="color: rgb(255, 222, 0)">Hỗ trợ</a>
            </li>
            <li>|</li>
            <li>
              <a

                style="color: rgb(255, 222, 0)">Link dự bị</a>
            </li>
            <li>|</li>
            <li class="DefaultLayout_phone_t__dx4eu">
              Gọi điện hỗ trợ：<span>+63279082890</span>
            </li>
          </ul>
          <div
            class="DefaultLayout_rightSwitch__+MOuU DefaultLayout_off__M6xWG">
            <div>Sơ đồ trang mạng<span>|</span></div>
            <div class="DefaultLayout_rightArrow__B6xC3"></div>
          </div>
        </div>
      </div>
      <div
        class="DefaultLayout_btmGuild__HAeTl"
        style="display: block; overflow: hidden; height: 296px">
        <div class="DefaultLayout_guildM__HLrM1">
          <div
            class="DefaultLayout_leftGuidList__9H9qV"
            ng-controller="MainMenuCtrl as ctrl">
            <div class="DefaultLayout_guilList__KONja">
              <div class="DefaultLayout_guilListT__yeGn5">
                THỂ THAO
                <div class="DefaultLayout_guilListImg__QQ4lM">
                  <div class="DefaultLayout_icon_btmSports__8ABbA"></div>
                </div>
              </div>
              <ul>
                <li><a>KU Thể Thao</a></li>
                <li><a>BBIN</a></li>
                <li><a>SABA</a></li>
                <li><a>CMD</a></li>
                <li><a>UG</a></li>
                <li><a>BTI</a></li>
                <li><a>IM Thể Thao</a></li>
              </ul>
            </div>
            <div class="DefaultLayout_guilList__KONja">
              <div class="DefaultLayout_guilListT__yeGn5">
                CASINO
                <div class="DefaultLayout_guilListImg__QQ4lM">
                  <div class="DefaultLayout_icon_btmReal__vFW6g"></div>
                </div>
              </div>
              <ul>
                <li><a>EVO</a></li>
                <li><a>KU CASINO</a></li>
                <li><a>DG</a></li>
                <li><a>AES</a></li>
                <li><a>WM</a></li>
                <li><a>SA</a></li>
                <li><a>AG</a></li>
                <li><a>GPI</a></li>
                <li><a>DG</a></li>
                <li><a>PP</a></li>
              </ul>
            </div>
            <div class="DefaultLayout_guilList__KONja">
              <div class="DefaultLayout_guilListT__yeGn5">
                GAMES
                <div class="DefaultLayout_guilListImg__QQ4lM">
                  <div class="DefaultLayout_icon_btmElect__lBaE8"></div>
                </div>
              </div>
              <ul>
                <li><a>PP</a></li>
                <li><a>JDB</a></li>
                <li><a>3D</a></li>
                <li><a>PG</a></li>
                <li><a>FC</a></li>
                <li><a>KA</a></li>
                <li><a>PTU</a></li>
                <li><a>CQ9</a></li>
                <li><a>JILI</a></li>
                <li><a>BBIN</a></li>
              </ul>
            </div>
            <div class="DefaultLayout_guilList__KONja">
              <div class="DefaultLayout_guilListT__yeGn5">
                XỔ SỐ
                <div class="DefaultLayout_guilListImg__QQ4lM">
                  <div class="DefaultLayout_icon_btmLotto__VbRih"></div>
                </div>
              </div>
              <ul>
                <li><a>GPI</a></li>
                <li><a>KU XỔ SỐ</a></li>
                <li><a>Xổ Số TCG</a></li>
              </ul>
            </div>
            <div class="DefaultLayout_guilList__KONja">
              <div class="DefaultLayout_guilListT__yeGn5">
                E-SPORTS
                <div class="DefaultLayout_guilListImg__QQ4lM">
                  <div class="DefaultLayout_icon_btmEsports__btop8"></div>
                </div>
              </div>
              <ul>
                <li><a>SABA</a></li>
                <li><a>IMES</a></li>
                <li><a>CMD</a></li>
              </ul>
            </div>
            <div class="DefaultLayout_guilList__KONja">
              <div class="DefaultLayout_guilListT__yeGn5">
                BẮN CÁ
                <div class="DefaultLayout_guilListImg__QQ4lM">
                  <div class="DefaultLayout_icon_btmFish__DaYZ+"></div>
                </div>
              </div>
              <ul>
                <li><a>JILI</a></li>
                <li><a>PTU</a></li>
                <li><a>3D</a></li>
                <li><a>JDB</a></li>
                <li><a>FC</a></li>
                <li><a>KA</a></li>
                <li><a>CQ9</a></li>
              </ul>
            </div>
            <div class="DefaultLayout_guilList__KONja">
              <div class="DefaultLayout_guilListT__yeGn5">
                ĐỐI KHÁNG
                <div class="DefaultLayout_guilListImg__QQ4lM">
                  <div class="DefaultLayout_icon_btmBBO__6Ordw"></div>
                </div>
              </div>
              <ul>
                <li><a>V8</a></li>
                <li><a>3D</a></li>
              </ul>
            </div>
            <div class="DefaultLayout_guilList__KONja">
              <div class="DefaultLayout_guilListT__yeGn5">
                Giới thiệu
                <div class="DefaultLayout_guilListImg__QQ4lM">
                  <div class="DefaultLayout_icon_btmHelp__nm2Jq"></div>
                </div>
              </div>
              <ul>
                <li>
                  <a
                    href="https://secure.livechatinc.com/licence/15466194/v2/open_chat.cgi?groups=5"
                    target="_blank">Trợ giúp</a>
                </li>
                <li>
                  <a
                    class="fancybox"
                    href="https://secure.livechatinc.com/licence/15466194/v2/open_chat.cgi?groups=5"
                    target="_blank">Khiếu nại</a>
                </li>
                <li>
                  <a
                    href="https://secure.livechatinc.com/licence/15466194/v2/open_chat.cgi?groups=5"
                    target="_blank"
                    op-title="Hỗ trợ"
                    op-height="600"
                    op-width="800">Hỗ trợ</a>
                </li>
                <li>
                  <a
                    open-window="/Announcement/Announcement"
                    op-title="Thông báo"
                    op-height="600"
                    op-scroll="true"
                    op-width="800">Thông báo</a>
                </li>
                <li>
                  <a
                    open-window="/Home/AboutUS"
                    op-title="Giới thiệu"
                    op-height="600"
                    op-scroll="true"
                    op-width="800">Giới thiệu</a>
                </li>
                <li>
                  <a
                    open-window="/Home/AboutUS?route=Spirit"
                    op-title="Tinh thần doanh nghiệp"
                    op-height="600"
                    op-scroll="true"
                    op-width="800">Tinh thần doanh nghiệp</a>
                </li>
                <li>
                  <a
                    open-window="/Home/AboutUS?route=VenueInfo"
                    op-title="Giới thiệu sảnh KU"
                    op-height="600"
                    op-scroll="true"
                    op-width="800">Giới thiệu sảnh KU</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="DefaultLayout_rightMobile__BP8Fb">
            <canvas
              id="react-qrcode-logo"
              height="130"
              width="130"
              style="height: 130px; width: 130px; border-radius: 10px"></canvas>
            <div
              class="DefaultLayout_guilListT__yeGn5 DefaultLayout_leftPhoneT__f+LQx">
              <!-- <div class="DefaultLayout_icon_btmMobile__xfVFR"></div> -->

            </div>
            <span></span>
          </div>
        </div>
      </div>
      <footer class="Footer_footer__g7rx0">
        <div class="Footer_brandImg__PezrR"></div>
      </footer>
      <div class="DefaultLayout_rightBtn__MQI4f">
        <div class="DefaultLayout_customerServ__jcDEZ">
          <ul>
            <li class="DefaultLayout_Sevli__l6-k5">
              <div class="DefaultLayout_icon_rLiveService__959Z8"></div>
              <span>Hỗ Trợ</span>
            </li>
            <li class="DefaultLayout_Sevli__l6-k5">
              <div class="DefaultLayout_icon_rTG__fb8P5"></div>
              <span>Telegram</span>
              <div
                class="DefaultLayout_customerServDiv__IflUd"
                style="display: none; opacity: 1">
                <div class="DefaultLayout_servDivT__Dj2Fr">
                  Telegram
                  <div class="DefaultLayout_rightCsArrow__nS0lc"></div>
                </div>
                <div class="DefaultLayout_qrImg__TyNyc">
                  <span>ID:Vui lòng quét mã</span>
                </div>
              </div>
            </li>
            <li class="DefaultLayout_Sevli__l6-k5">
              <div class="DefaultLayout_icon_rViber__g1aXM"></div>
              <span>Viber</span>
              <div
                class="DefaultLayout_customerServDiv__IflUd"
                style="display: none; opacity: 1">
                <div class="DefaultLayout_servDivT__Dj2Fr">
                  Viber
                  <div class="DefaultLayout_rightCsArrow__nS0lc"></div>
                </div>
                <div class="DefaultLayout_qrImg__TyNyc">
                  <span>ID:+639064061820</span>
                </div>
              </div>
            </li>
            <li class="DefaultLayout_Sevli__l6-k5">
              <div class="DefaultLayout_icon_rCallBack__SZNui"></div>
              <span>Điện thoại</span>
              <div class="DefaultLayout_rBtmLine__YLJ0o"></div>
              <div class="DefaultLayout_txt_maintain__JXkR5">
                <p class="DefaultLayout_icon_arrowR__4yQXN"></p>
              </div>
            </li>
            <li class="DefaultLayout_Sevli__l6-k5">
              <div class="DefaultLayout_icon_rComputerHelp__oEpdN"></div>
              <span style="text-align: center">Hỗ trợ xa</span>
            </li>
            <li class="DefaultLayout_Sevli__l6-k5">
              <div class="DefaultLayout_icon_rComplaint__kp70F"></div>
              <span>Khiếu nại</span>
            </li>
          </ul>
        </div>
        <div class="DefaultLayout_CF_Gift__DE1Fg">
          <a
            href="/Home/SponRecord"
            target="_blank"
            class="DefaultLayout_btn_CAO__1SIQ6"><img
              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHMAAABoCAYAAADCUs++AAAPS0lEQVR4nO2dC3BU1RnHsa2tFSRESngEAoS3vIQgEkJIYPN+g0YpFmTaGeoTtDqDFiGoY2WGqgiFGZTXQgVNETRopd0atFYdWx6KQcExQgeRIhioGnTK4+v33b1n+fbk3nP3cfdxlz0z/2H33HO+853vd8/r7o22A4B2dsvVsX1SQcqOuNsOMk5g/hCVh1qIakAdQLWgQFeLntegl8nT6yRhxhHM/qjlqOMMXKA6rtftn4QZW5gZqOdQ50OAKOu8bisjCTO6MC9DzUWdsQGirG9125clYUZeKahXIgBR1na9rSTMCKk76sMogBTah+qWhGm/eri8O9FogRT6WL+JkjAdDlLoQKSAXmowYw0yokAvJZjxAjJiQC8VmPEGMiJALwWY8QrSdqCJDjPeQdoKNJFhOgWkbUATFabTQNoCNBFhEsiDcQAm6kATDabTQYYFNJFghg2y8uoU+E/BRGgtyoPWkkmGOl9RAE3Zo6E4pYPS1uGJ2dBaNtnUTmtxPpwrnQzNKLuAJgpMW0bkO9ljAEryASoKAcoL2grhQE0ZzO7ZXWnnr8KOkQ2hSmwDb5rfpHe1bYQmAkxbQC4ZMtAaQFUhLOvfW2nnsb4ZWK5IbaeMbBXDs8MGBzrl9rgUYHa3A+RNXToDlE7CILtMgo/5lUWwe8JYpZ0bOncCcOWYj2yfXPBJjtqWAVDLn8+cDJN+7N0XLkjSoUkTvDBNR2SRto6WWqyTn5ZM1kCZ3hS6Lkwtg6mdU4L1c5/L4gdup8Kk1zBseUNg86gRAMV56pFUXQL3ZfRQ2nluYKb3hlCNSrqGU+zD6eo1V6EGl+IVFKfCvNcOkHP79PSuk2YjqcI7Kp8fkKm0c1dvtHNDOcKcrFgnXdpN8dq4UeH6PTeRYNIbb612wDyNU6cpAAo+jqRDONqs7HyF65/lpgfX3C8njAvbZ73vhm/9ORHmZjtA7rh+tHr3SnAK8+EW3NSo7DTm56g3T2J6nVICs7qk2gGT9FwiwKSXi8N+r3V+vz5qkAQGNynLB6un10d79fBOxRWKEUkgsS338ICOIYHqvMvgRWunwVwZbiBqcKSdpam1TLG+IYB/Zo1U2rkprbPXhsXOlR4OfDR+jJ0ghZY5GeblqK/CDcK+idnqYwiC/K58MpRYHUPyx6tHpD7CL1QUaTdQBGCe1GPiSJj54QZg1dBB6umV4JRMgnt7pyvtPH/NIO9xxurhAK6TdbhjjgBIoTynwnw4nI7P6t7FYqNSqE2JL1zTX2nn1+ld8RhSFtD0+tq1wyIJEvSYOBLmy+F0/EhBrnqdxGuHC9XHkALUyZzrtGOG1THkC9eESIMEPSaOhLk/1E4vo6cz5YqRRHAqC2CGxdGhMXec98hiNSqriuGXOBNEAeZ+p8I8HWqnP588wXx9w/wLuLt9IEO9Tj7et5f6CY84hiDsdX0zogES9Jg4EmbI58sLFgAOThgL036WCrfhenhbD1Ia3IGf6xDggxk9YHZ6N1wnq9S7YH2q/qgoP1ogSecuOZjfFqshfEcjTnsc5z99HsN19pF+veFI3riANjxnCydCTWrHJMxITrOvjRmhBiHpNEJ5ZuhA7/Q6INO6DoGuKYEFA/pGE6Sjp9mQN0BT6KkP7WQtzoVHXbmwYnA/KNIfGMzscrV648TOp6+OHBJtkOBy8AYorKPJg7jBodHTBiiC+BJH4h8QYoFU5zTCVcIs8665J0pdsQBJesmpMMN6aEByD+qnPUD3PhwvhM8R1spBmYZv2jVmZ2nHFat1kqbY23EExwjmQqfCzLMjAHvGjIRWBLBysPmTnsdxRwsVLvW0TOvklFJYO3xQrECSJjoV5o9c3ofLYQWARmHN1ebv30yjdZJGr9U6WVUMTaPVv6xEWCdc0n9EykkwSU9HOkiH6Z3X6mJLmOdurIDK6B5DZC2V4+M0mPSD7LlIBWj1kAHWr39oPzZPhocsXoSOsM6iMp0Ok7QhEgGa0jnF+4zW6jfK6hLYHptjCNcGo9g4EWY66hu7A7R8CO50yy1+n8Sz6r9yro81yG/0GCQETNJddgdp26hhAT0d2jl2FKwaOhA2Dh/sp22jhsIb14+GDfh5mn0vbhnpDrO4OBUmvQj8kp1BWknrZSCP+7RpWH6Q4D3G7M8ZC4v69oKyTldFCuQWVVycCpNEr+q/b1egtL8TKc4P6hmu9vMZaiuOypsjOxpJe10J+ucJQl1cYTyzlfVs1nDvbrbU+nnsWVTDyKEwM61zpCGSmvS+KuPhdJikrnYC3TP+OvO3CXCKvYD607VDtYcLUYAoQKYFEotEgNlO76wtQOkJ0Vf0vhA9lGdAtZF47TCYkRbV57ABg0wkmLYCnUl/r0mbmspCOI9At2gjMeJrYlggEw2mrUCfyOwNr2dnwS2x+UUkaJCJCNNWoDFSSCATFaaTgYYMMpFhOhFoWCCdBjMLVaCrzS8GDgcaNkinwLzVZfy/qTiKqkoAoAE9EHA8zEIEgTqDAhMdDbCjSqAF5vZ9kutYlZdfDos0yLiHWdKxfR0KSHdPnAAPVlVomjViGIh8VE64QIsv2vK1QboxI92XL8MX+eQLryPyi6MMMu5hlqe096CAtHdnI4i0rm4BiHzUvCA6bAiU2QKe5ldX+PILJfgin3zhiduKJsi4h1md0sGDAtL7DKYbAyjyUaYw8do1qDmoelSzXv5weUqHU3zkMFt+YBZWV/ryi1j5UlbHLcHktkT5Eg1+B6jy6hxe24Gq0/snRN/TmO85rEyLbnMXaimqwnEwb+jUwYMC0gcM5sZFC0DkowxhYv4yVsZQU1GlOIJ4Hk8P11T68ovZSCtmdagM+SMk8qtRZZLtAHQMlYtqCqAslcl1DMxpCBMFpH0M5iYMmsifZgAT815h14MST48hKJFfymDSKLWyQyMpRB++D7JsriNgzkCYKCA1MZgvIEyRP0OCid+ns2uw9p674b1tW+H4oUNaXfq3cd1aWJCfy234xNNihCnyyxjMSvzM7ZNvpO1PPWlok+yQD9+eOqWJ2qc8UY8k17mtT0+tn3SN6lA6tHeP1gZdY2WbHAHzV6kdPCgg7X/jIswt2EmRj/KDid/fEtf+vPRJX51WDMhhDAb//sikXG5HE09PYMBFfgWDORU/i3zyRSTyUbbnRthG6Uv95hJJrsd9pbK8PF27u29PXj4n7mHejjBRQPqYwdyGART5t0swWb5fsB5HcJS3jQV/90tbuZ02dZ5GmCK/ksGsxc8in9sjH7mt+zDgrfqoovTW+rWaH7yOSLwetSvSCYRIdiif/FXFIK5hzkGYKCAdYDAbsCMifw6DiZ9TRf4DGIAVGBQhkb+CBYoCzexo4onXq2Iwb8bPIr+BgSEfua3n2ag8iVD4tbcRLE/82sOjhvn8XoLwjdrai2BZnfq4h3k/wkQB6RMG81XslMi/XxqZ+L2JXYNVGJBGnG6pPrchEi97vwST6op8nFqbXd6/dTkzPaX9/0T+qyzAZJ/b4tfeRXj82hZp+pX9EGWoHtk9wqZdg7Y8cQ/zt6ntPSggfcpA7MAgiXzUPEm+a28ufaINPDnx8iSe1tRUWLazgwEjH7kthc+abTM/Hu2b7lfXKEltxT/MRegkCkjNrHMeDIzIN9MGFqwv8K6un/WLNvmU5Ho8UVmrdjwMJvlodm3X+jV+17ZLI9Os3n6cTldNmmDVVvzD/F3qlR4UkA4xmI2LHgKRb6Z32ajk5bciVJ7kejxtqim3bIdsi0Q+8mu8rVOHPvO7thfhmvlxjE2p3AfeJ6mt+IZJWtLpSg8KSIfZOZM+v4lBNJIo/8G6i8E6sO1FXz595knkC/FENoza+Ms9d/nKv8lgkl+yvdMIkfvRgIB5HSM/eB3Rp+V9evjlS2157Ip5xGAu7fRTDwpI/975epsAGCVR/m/33OmXT4EQweBBEeWFAknkiyj/DwaG5wttyh8P37PjiUjHpQ0Nr/PhujVtypIN7rfUVvzDXJFyhQcFpCMBwhTlSe/UzfcL5H8xGDtune5ni5cnBZKoPm/DKJ9r48ghsOep32vXP8XRuXPunfBydZmp36t7d4P961a3abM+L9usrfiHuarjT+pQEK5enJgNm0cMDttOsKI231s4X9Pf59zhd42+i3Ri725TG69UlcL6jG5WbdXFPcw1V/04DXUMBU5U/fBBfqOrcebP4Y+9umr/fs2mzA+eXMLrNQXZDsUnLe5hktZ3uDwNVYd6CwUBiMpNR5WiGlBn2LWjKLdkS5SfHmQbdQZ1RP5RkXdw7bOgSif37IZNPdO47QrUDANfmkzasg1kxGHaIfcVP8hCZUaxvRkoENo9/wGEtssP4tefNcPB1c/A5m6dgZVtkuxcgSpApUbL95jDike5f9zubRQEoe9RubH2O+aBi1chnI0BgmyKB5BJmNZAc1BLUbskgM0oN2pGrH1MwkxQxdyBpGIIE6eWWn2qse3JRVKxg+lJgoxPBQsyE9Wiy5azH9rJitVIZ20329Ufm/xK1WNMG6+Az6l82pRFhmqlRiivXh+du6R8qpNlkGemWr1cfbBOSz7V6v5wv2eza8B9leqKtpUgrewE0edm/d/FFnYWh3KDqWAKzQ4xyAHBDPMOnqewPy9QCAHeMFGDGapMHdXvWs0B/XumNAI84s4xGpkmnaxleamSPb9OSqCaDWYJMRVp4Fi+sNnC+ybZm8dGAOh99dliQd+l91tpJ4g+i/YWG/iZyuymSjHg/mWZxUZ517FOZTFj8p2WGiLMegN7pALWaa4WN5uK8fNs0VEDyLv067WsrqqdepMy4qZV2gkBpmynJQiY8gDw1W9n0oFUySEB1WMwquaFAlNRZh5zvEC/tkpcMwiManTwJUTYambtGMGslwLZYmUnBJhiEGQxu/xzG5j69xa3IjZWI1NeA7hjYmR4QoWpt82nHGAdaFatD0HC5Ju1ercapgiSCG6LlZ1QplmWx6dP1cjks5VhbAKdZj0GjoUFk91R5GSmFORAYPrdtQZ+zzbqWwAws+IQpoiz7ygVFEwW7GbmhC3TrPvi+tCig8x0+09/LVJ54csqZjOTddRyA+QwmAWSjXqD8m1iE9DRxH3xYYF8LZwNkNmGgwdZVoFkN+ijSZzDFDe0rHoDG21io4LpkRzJctt7NKl1++/QhB/yBkTcNIbnXf1m42u78qFBnMPkQKm+GHXyjt0wNqZrUlLOU8wdSCoJM6kkzMRWzB1Iyj79H1EVu+tbI/UEAAAAAElFTkSuQmCC" /></a>
        </div>
      </div>
      <div></div>
    </div>
  </div>
  <div id="authModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5);">
    <div style="background:#fff; margin:10% auto; padding:20px; width:400px; position:relative;">
      <button style="font-size: 24px;" onclick="$('#authModal').hide()">X</button>

      <div id="loginForm">
        <h3 style="">Đăng nhập hội viên</h3>
        <form id="login-form" action="{{ route('login') }}" method="POST">
          @csrf
          <div class="label">
            <label for="">Tài khoản</label>
            <input type="text" name="name" placeholder="Tài khoản"><br>
          </div>
          <div class="label">
            <label for="">Mật khẩu</label>
            <input type="password" name="password" placeholder="6 ~ 10 ký tự chữ và số">
          </div>

          <span class="toggle-password" onclick="togglePassword()" id="toggleIcon"></span>

          <!-- Google reCAPTCHA -->
          <div class="container-fluid">
            <div class="row justify-content-center">
              <div class="col-md-4 mb-5">
                <div class="slidercaptcha card">
                  <div class="card-header">
                    <span></span>
                  </div>
                  <div class="card-body">
                    <div id="captcha"></div>
                  </div>
                </div>
              </div>

            </div>
          </div>
          <input type="hidden" class="recap-success" name="recap-success">
          <!-- g-recaptcha -->

          <br>
          <p onclick="toggleForm('forgot')" style="cursor:pointer;">Quên mật khẩu</p>
          <button id="login-button" type="submit" disabled style="background-color: #aaa;">Đăng nhập</button>

        </form>
        <p onclick="toggleForm('register')" style="cursor:pointer;">Chưa có tài khoản? Đăng ký</p>
        <p id="message"></p>
      </div>

      <div id="registerForm" style="display:none; padding: 20px;">
        <h3 style="color: #5aaaf3; text-align: center; margin-bottom: 20px;">ĐĂNG KÝ HỘI VIÊN</h3>
        <form id="register-form" style="display: flex; flex-direction: column; gap: 16px;">

          <div class="label">
            <label for="" style="">Tài khoản</label>
            <input type="text" name="name" placeholder="4 ~ 10 ký tự chữ và số" style="padding: 10px; border: 1px solid #ccc; border-radius: 6px;" required>
          </div>

          <div class="label">
            <label for="" style="">Biệt danh</label>
            <input type="text" name="nickname" placeholder="Nhập tối đa 8 ký tự" pattern="^.{1,8}$" style="padding: 10px; border: 1px solid #ccc; border-radius: 6px;" required>
          </div>
          <div class="label">
            <label for="" style="">Số điện thoại</label>
            <input type="string" name="phone" pattern="^0\d{8,9}$" placeholder="SĐT" style="padding: 10px; border: 1px solid #ccc; border-radius: 6px;" required>
          </div>
          <div class="label">
            <label for="" style="">Mật khẩu</label>
            <input type="password" name="password" placeholder="6 ~ 10 ký tự chữ và số" style="padding: 10px; border: 1px solid #ccc; border-radius: 6px;" required>
          </div>

          <!-- Checkboxes -->
          <div style="display: flex; flex-direction: column; gap: 10px; margin-top: 10px; font-size: 14px; color: #333;">
            <label style="display: flex; align-items: flex-start; gap: 8px;">
              <input type="checkbox" name="promotion_sms" value="1" style="margin-top: 3px;" checked>
              <span>Nhận thông tin khuyến mãi qua tin nhắn điện thoại</span>
            </label>

            <label style="display: flex; align-items: flex-start; gap: 8px;">
              <input type="checkbox" name="agree_terms" id="agree_terms" required style="margin-top: 3px;" checked>
              <span>
                Tôi đã 18 tuổi, đồng thời đã đọc và đồng ý quy tắc cá cược
                <a href="https://ku8338.net/Home/GameTerms" target="_blank" style="color: #5aaaf3; text-decoration: underline;">Điều khoản</a>
              </span>
            </label>
          </div>

          <button type="submit" style="padding: 10px; background-color: #5aaaf3; border: none; color: white; border-radius: 6px; cursor: pointer;">
            Đăng ký
          </button>
        </form>

        <p onclick="toggleForm('login')" style="cursor:pointer; text-align: center; margin-top: 15px; color: #5aaaf3;">
          Đã có tài khoản? Đăng nhập
        </p>
      </div>
      <div id="forgotForm">
        <h3>Quên mật khẩu</h3>
        <hr>
        <div>
          <!-- <img src="{{asset('media/icon_indexImg.png')}}" alt=""> -->
          <span>Hãy nhập dữ liệu và nhận mã xác nhận！</span>
        </div>
        <form id="forgotPassword">
          <select name="PWType" id="PWType">
            <option label="Vui lòng chọn loại mật khẩu" value="0" selected="selected">Vui lòng chọn loại mật khẩu</option>
            <option label="Mật khẩu đăng nhập" value="1">Mật khẩu đăng nhập</option>
            <option label="Mật khẩu bảo mật" value="2">Mật khẩu bảo mật</option>
            <option label="Mật khẩu đăng nhập và bảo mật" value="3">Mật khẩu đăng nhập và bảo mật</option>
          </select>
          <div>
            <input type="text" placeholder="Tài khoản">
          </div>
          <div class="input-code-wrapper">
            <input type="text" placeholder="SĐT đã đăng ký">
            <button type="button" class="send-code-btn">Gửi mã</button>
          </div>
          <div>
            <input type="text" placeholder="Nhập 4 con số">
          </div>
        </form>
      </div>
      <div id="message" style="margin-top:10px; color:green;"></div>
    </div>
  </div>

  <div id="popup" class="popup">
    <div class="popup-content">
      <h2 class="tn"> Tin nhắn</h2>
      <p class="tn"></p>
      <p>Chuyển hết về tài khoản chính thành công</p>
      <button id="closePopup" class="close-popup">Xác nhận</button>
    </div>
  </div>
  @if(Auth::check())
  <input style="display: none;" class="check_link" type="text" value="{{route('link301')}}">
  @else
  <input style="display: none;" class="check_link" type="text" value="abc">
  @endif
  @if(Auth::check())
  <input style="display: none;" class="check_link_topup" type="text" value="{{route('linkTopup')}}">
  @else
  <input style="display: none;" class="check_link_topup" type="text" value="abc">
  @endif

  <script
    defer=""
    src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015"
    integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ=="
    data-cf-beacon='{"rayId":"92a1aef909415fb3","serverTiming":{"name":{"cfExtPri":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"version":"2025.3.0","token":"1cfe299bd5f94561bdc9c3e1b34606e6"}'
    crossorigin="anonymous"></script>

  @if(session('show_phone_prompt'))
  <script>
    $(document).ready(function() {
      showPhonePrompt(); // Gọi hàm hiện modal
    });

    function showPhonePrompt() {
      const html = `
            <div id="phonePromptModal" style="position: fixed; top: 30%; left: 35%; background: #fff; border: 1px solid #ccc; padding: 20px; z-index: 9999;">
              <h4>Vui lòng xác nhận lại số điện thoại</h4>
              <input type="text" id="user-phone" placeholder="Nhập số điện thoại (tùy chọn)">
              <br><br>
              <button onclick="submitPhone()">Lưu</button>
              <button onclick="dismissPhonePrompt()">Bỏ qua</button>
              <p id="phone-message"></p>
            </div>`;
      $('body').append(html);
    }

    function submitPhone() {
      const phone = $('#user-phone').val().trim();

      $.post('/update-phone', {
          phone: phone,
          _token: '{{ csrf_token() }}'
        })
        .done(function() {
          $('#phone-message').css('color', 'green').text('Cập nhật thành công!');
          setTimeout(() => location.reload(), 1000);
        })
        .fail(function() {
          $('#phone-message').css('color', 'red').text('Cập nhật thất bại');
        });
    }

    function dismissPhonePrompt() {
      $.post('/dismiss-phone-prompt', {
        _token: '{{ csrf_token() }}'
      }).always(() => location.reload());
    }
  </script>
  @endif


</body>
<chatgpt-sidebar data-gpts-theme="light"></chatgpt-sidebar>
<script>
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });

  function toggleForm(type) {
    if (type === 'login') {
      $('#loginForm').show();
      $('#registerForm').hide();
      $('#forgotForm').hide();

    } else if (type === 'register') {
      $('#registerForm').show();
      $('#loginForm').hide();
      $('#forgotForm').hide();
    } else if (type == 'forgot') {
      $('#registerForm').hide();
      $('#loginForm').hide();
      $('#forgotForm').show();
    }
  }


  // MainMenu
  $('#MainMenu ul li ,#indexMenu, .slider_dev , .btn_personalMsg, .btn_member').click(function() {
    if ($('.check_link').val() === 'abc') {
      toggleForm('login');
      $('#authModal').show();
    } else {
      window.location.href = $('.check_link').val(); // Đổi thành URL bạn muốn chuyển tới
    }

  });
  $('.topup').click(function() {
    if ($('.check_link').val() === 'abc') {
      toggleForm('login');
      $('#authModal').show();
    } else {
      window.location.href = $('.check_link_topup').val(); // Đổi thành URL bạn muốn chuyển tới
    }

  });
  // check_link_topup
  // topup

  $('#open-login').click(function() {
    toggleForm('login');
    $('#authModal').show();
  });

  $('#open-register').click(function() {
    toggleForm('register');
    $('#authModal').show();
  });

  // Đăng nhập


  // Bật reCAPTCHA khi checkbox được tick
  //   $('#show-captcha').change(function () {
  //   if ($(this).is(':checked')) {
  //     $('#captcha').show(); 
  //   } else {
  //     $('#captcha').hide();
  //     // Không cần reset như grecaptcha.reset(), vì GeeTest không hỗ trợ kiểu này
  //   }
  // });

  $('#login-form').submit(function(e) {
    const name = $('#login-form input[name="name"]').val().trim();
    const password = $('#login-form input[name="password"]').val().trim();
    const recapSuccess = $('#login-form input[name="recap-success"]').val().trim();
    // recap-success

    let errors = [];

    if (!name) errors.push('Vui lòng nhập tài khoản.');
    if (!password) errors.push('Vui lòng nhập mật khẩu.');
    if (!recapSuccess) errors.push('Vui lòng nhập recapcha.');

    if (errors.length > 0) {
      e.preventDefault(); // chặn submit
      $('#message').css('color', 'red').html(errors.join('<br>'));
      return;
    }

    // Nếu mọi thứ ok, để form submit bình thường
  });

  $('#register-form').submit(function(e) {
    e.preventDefault();

    const formData = $(this).serialize();

    $.post('/register', formData)
      .done(function(data) {
        $('#message').css('color', 'green').text(data.message);
        setTimeout(() => location.reload(), 1000);
      })
      .fail(function(err) {
        $('#message').css('color', 'red').text(err.responseJSON?.message || 'Đăng ký thất bại');
      });
  });
</script>
<script>
  $(document).ready(function() {
    const returnMainP = document.querySelector('.returnMainP');
    const popup = document.getElementById('popup');
    const closePopup = document.getElementById('closePopup');

    // Hiển thị popup khi nhấn vào returnMainP
    returnMainP.addEventListener('click', function() {
      popup.style.display = 'flex';
      $('.memberPMenuT').css('z-index', '0');
      $('.memberPMenuB').css('z-index', '0');
    });

    // Ẩn popup khi nhấn nút xác nhận
    closePopup.addEventListener('click', function() {
      popup.style.display = 'none';
      $('.memberPMenuT').removeAttr('style');
      $('.memberPMenuB').removeAttr('style');

    });
    let currentIndex = 0;
    const slides = $('.slider_dev li');
    const totalSlides = slides.length;

    // Hiển thị slide đầu tiên
    function showSlide(index) {
      slides.hide();
      slides.eq(index).fadeIn();
    }

    // Chuyển tới slide tiếp theo
    function nextSlide() {
      currentIndex = (currentIndex + 1) % totalSlides;
      showSlide(currentIndex);
    }

    // Chuyển về slide trước
    function prevSlide() {
      currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
      showSlide(currentIndex);
    }

    // Chạy slider tự động
    setInterval(nextSlide, 3000); // Mỗi 3 giây chuyển ảnh

    // Hiển thị slide đầu tiên
    showSlide(currentIndex);

    // Sự kiện khi nhấn nút "Tiếp theo"
    $('#next').click(function() {
      nextSlide();
    });

    // Sự kiện khi nhấn nút "Trước"
    $('#prev').click(function() {
      prevSlide();
    });

    const timeElement = document.getElementById("current-time");
    const now = new Date();

    // Định dạng ngày giờ theo chuẩn ISO cho thuộc tính datetime
    timeElement.dateTime = now.toISOString();

    // Hiển thị dạng dễ đọc cho người dùng (ví dụ: 08/04/2025, 14:30)
    timeElement.textContent = now.toLocaleString('vi-VN');
  });
</script>


<script>
  function checkLoginFormStatus() {
    const name = $('#login-form input[name="name"]').val().trim();
    const password = $('#login-form input[name="password"]').val().trim();
    const recapSuccess = $('#login-form input[name="recap-success"]').val().trim();
    const isValid = name && password && recapSuccess;

    if (isValid) {
      $('#login-button').prop('disabled', false).css('background-color', '#32abff');
    } else {
      $('#login-button').prop('disabled', true).css('background-color', '#aaa');
    }
  }

  // Kiểm tra lại mỗi khi người dùng nhập
  $('#login-form input[name="name"], #login-form input[name="password"]').on('input', checkLoginFormStatus);

  // Gọi khi reCAPTCHA hoàn thành
  function onCaptchaCompleted() {
    checkLoginFormStatus();
  }

  // Gọi lại khi reset captcha (ví dụ bỏ tick)
  function onCaptchaExpired() {
    checkLoginFormStatus();
  }
</script>



</html>